 /* flowchart turbo C         EJN

	ENFILE   (flow.h)
	VIDEO    (flow.h)
   Options : char signed
	 word byte
	compile large
 */

#include "stdio.h"
#include "stdlib.h"
#include "conio.h"
#include "alloc.h"
#include "string.h"
#include "process.h"
#include "dos.h"
#include "flow.h"
#include "bios.h"
#include "dir.h"

void main(int argc,char *argv[]);
void prntest(void);
void beep(unsigned freq, unsigned duration);
void mallocdata(void);
void freemallocdata(void);

unsigned _stklen=8192;                   /* vergroot de stack */
unsigned long MAX_ROW=500L;
unsigned long MAX_COL=50L;

float  **data;            /* DATA BLOK*/
int    *index;
/*float  *sorty;*/
char   **label;
char   **labelrow;
int    *SCHERMPTR;
float  **temp;

int  autopic=FALSE,autodump=FALSE,plaatje=0;
int  actie;
int  show,lost,print,num,spearm;
char outfile[40];
int  maindisk;
int  geladen=0;
int  lijn =1,conf=1;
char curdir[40];
char dir[40];
char fileload[40];
char maindir[40];
float maxttest;
float upx,upy,lowx,lowy;

extern int columns,rows;

/************************  MAIN  ************************/

void main(int argc,char *argv[])
{
   unsigned disk;
   int wis=1,m,n;
   char drawdir[60];
   float fnop;
   char cnop[20];
   lost=FALSE;
/* strcpy(file,"Geen");*/
   print=FALSE;
   show=FALSE;
   num=FALSE;
   spearm=FALSE;
   upx=upy=999999L;
   lowx=lowy=0;
   maxttest=1.0;
   clrscr();

   if (argc==4)  show=TRUE;
   if (argc>=3)
       {
		MAX_COL=atol(argv[1]);
		MAX_ROW=atol(argv[2]);
       }

   initdisplay();
   mallocdata();

   cursoroff();
   mode(3);
   palette(0);

   strcpy(curdir,"?:\\");
   curdir[0]='A'+getdisk();
   maindisk=getdisk();
   getcurdir(0,curdir+3);
   if(curdir[(int)strlen(curdir)-1] != 92) strcat(curdir,"\\");
   strcpy(maindir,(char *)curdir);

   if(check_drive("a:")) setdisk(0);
   strcpy(curdir,"?:\\");
   curdir[0]='A'+getdisk();
   getcurdir(0,curdir+3);
   if(curdir[(int)strlen(curdir)-1] != 92) strcat(curdir,"\\");

  while(1)
   {
   wis=1;
   actie=display_menu(wis);
   if (actie==-1) actie=QUIT;

      switch (actie)

      {
      case LOAD:
	  veeg(0,0,25,80);
	  strcpy(fileload,(char *)filedir("*.wk?"));
	  if (strlen(fileload) < 2) break;
	  geladen=1;
	  clrscr();
	  read_wks(fileload);
	  break;

      case LOOKALL:
	  if(!geladen) break;
	  clrscr();
	   for(n=2;n<columns;n++)
		{
		   autopic=TRUE;
		   plaatje=n;
                   teken_graph();
		   autopic=FALSE;
                   if(!kbhit())  drawpic(outfile);
		   else if(getch()==27) n=9999;
                 }
          break;

      case CHADIR:
	    veeg(24,0,1,80);
	    swrite(13,24,"RETURN or New directory: \0",0x1300);
	    cursor(38,24);
            gets(dir);
	    if (strlen(dir) >1) changedir();
	    strcpy(curdir,"?:\\");
	    curdir[0]='A'+getdisk();
	    getcurdir(0,curdir+3);
	    if(curdir[strlen(curdir)-1] != 92) strcat(curdir,"\\");
	    veeg(23,0,1,80);
          break;

       case VIEW:
	  strcpy(drawdir,maindir);
          strcat(drawdir,"DRAWPIC.EXE");
          if(spawnlp(P_WAIT,drawdir,drawdir,NULL)==-1)
			 {
			   clrscr();
			   puts("TOO LESS MEMORY FOR DRAWPIC \n");
			   delay(3000);
			 }
          break;

       case PRINT:
	  if(!geladen) break;
          clrscr();
          display_labels();
	  display_data();
          break;

       case AUTO:
          if(!geladen) break;
          clrscr();
          autopic=TRUE;
	  gotoxy(0,5);
	  m=-1;
	  while (m<0)
	     {
	       m=-1;
	       clrscr();
	       print_labels();
	       gotoxy(1,1);
	       printf("\nVanaf welk plaatje beginnen?  ");
	       scanf("%d",&m);
	       fflush(stdin);
	     }

	   for(n=m;n<columns;n++)
	       {
		plaatje=n;
		teken_graph();
		if(kbhit())
		 {getch(); break;}
		drawpic(outfile);
	       }
	  autopic=FALSE;
	  break;

       case DUMP:
	  if(!geladen) break;
	 clrscr();
	 num=TRUE;
	 autopic=TRUE;
	 autodump=TRUE;
	 gotoxy(0,5);
	 m=-1;
	       while (m<0)
		     {
		       m=-1;
		       clrscr();
		       print_labels();
		       gotoxy(1,1);
		       cprintf("\nVanaf welk plaatje beginnen?  ");
		       scanf("%d",&m);
		       fflush(stdin);
		     }
	 for(n=m;n<columns;n++)
	   {
	    plaatje=n;
	    teken_graph();
	    drawpic(outfile);
	    if(kbhit())
	     {getch(); break;}
	   }
	  autopic=FALSE;
	  autodump=FALSE;
	 break;

       case PRNONOF:
	  if(print) print=FALSE;
	     else {prntest();  print=TRUE;}
	  break;

       case LIJN:
	  if(lijn) lijn=FALSE;
	     else   lijn=TRUE;
	  break;

      case YLIMIT:
	  clrscr();
	  gotoxy(0,5);
	  printf("Lower Y_as?  ");
	  gets(cnop);
	  if(cnop[0]==0)
	    {lowy=0; upy=999999; break; }
	    lowy=atof(cnop);
	  printf("Upper Y_as?  ");
	  gets(cnop);
	  if(cnop[0]==0)
	    {lowy=0; upy=999999; break; }
	    upy=atof(cnop);

	   break;

       case XLIMIT:
	  clrscr();
	  gotoxy(0,5);
	  printf("Lower X_as?  ");
	  gets(cnop);
	  if(cnop[0]==0)
	    {lowx=0; upx=999999; break; }
	    lowx=atof(cnop);
	  printf("Upper X_as?  ");
	  gets(cnop);
	  if(cnop[0]==0)
	    {lowx=0; upx=999999; break; }
	    upx=atof(cnop);
	   break;

       case PLAATJE:
	  if(!geladen) break;
	  num=FALSE;
	  teken_graph();
	  if(stricmp(outfile,"0")==0) break;

	  drawpic(outfile);
	  break;

       case NPLAATJE:
	  if(!geladen) break;
	  num=TRUE;
	  teken_graph();
	  if(stricmp(outfile,"0")==0) break;
	  drawpic(outfile);
	  break;

       case QUIT:
       default:
	  clrscr();
	  maindir[strlen(maindir)-1] =0;
	  setdisk(maindisk);
	  chdir(maindir);
	  printf("%s\n",maindir);
	  freemallocdata();
	  exit(-1);
	  break;

      }
     }

  }



/* PRINTER TEST   EJN 040388


Dit programma test of de printer op printen staat en blijft dit
testen totdat negen pogingen zijn ondernomen
*/


void prntest(void)
{

int i,j,n,count;

count=0;

while(count<9)
 {
  count++;
  n= biosprint(2,0,0);

  if( n == 0x90) break;
	  nosound();
	  sound(9000);
/*  beep(200,10);*/
  clrscr();
  if (count>3)
     {
       printf("\n**********************************\n"
			  "*       It does not work        *\n"
			  "*        CALL FOR HELP          *\n"
	      "*********************************\n");
	  nosound();
	  }

       printf("\n\n\n\nERROR %x ",n);
       if ((n & 0x01) ==0x01)
		 puts("\n         Printer Device time out error");
       if ((n & 0x08) ==0x08)
		 puts("\n         Printer I/O error");
       if ((n & 0x10) == 0x10)
				 puts("\n         Printer not ONLINE");
       if ((n & 0x20) == 0x20)
		 puts("\n         Printer Out of paper");
       if ((n & 0x40) == 0x40)
				 puts("\n         Printer is OFF");
       if ((n & 0x80) == 0x80)
		 puts("\n         Printer NOT BUSY");
	   puts("Press a key after solving the error");
	 while(bioskey(1)==0);
	 getch();
	  nosound();
  }
 }


void beep(unsigned freq, unsigned duration)
 {
    sound(freq);
    delay(duration);
    nosound();


 }
void mallocdata(void)
 {
   int n;

   label = (char  **)malloc((MAX_COL)  * sizeof(char  *) );
   for (n=0;n < MAX_COL;n++)
   {
	label[n] = (char *) malloc((MAX_LEN) * sizeof(char));
	  if (label[n]==0)
	   {
		 printf("%u coreleft\n\n",coreleft());
		 puts("TOO LESS MEMORY\n");
		 exit(-1);
		}
	}

   labelrow = (char  **)malloc((MAX_ROW)  * sizeof(char  *) );
   for (n=0;n < MAX_ROW;n++)
   {
	labelrow[n] = (char *) malloc((12) * sizeof(char));
	  if (labelrow[n]==0)
	   {
		 printf("%u coreleft\n\n",coreleft());
		 puts("TOO LESS MEMORY\n");
		 exit(-1);
		}
	}

   temp = (float **)malloc( 2 * sizeof(float  *) );
   for (n=0;n < 2;n++)
   {
	temp[n] = (float  *) malloc((MAX_ROW) * sizeof(float));
	  if (temp[n]==0)
	   {
		 printf("%u coreleft\n\n",coreleft());
		 puts("TOO LESS MEMORY\n");
		 exit(-1);
		}
	}

   index = (int  *) malloc((MAX_ROW) * sizeof(int));

   data = (float  **)malloc((MAX_ROW)  * sizeof(float  *) );
   for (n=0;n < MAX_ROW;n++)
   {
	data[n] = (float  *) malloc((MAX_COL) * sizeof(float));
	  if (data[n]==0)
	   {
		 printf("%u coreleft\n\n",coreleft());
		 puts("TOO LESS MEMORY\n");
		 exit(-1);
		}
	}

}

void freemallocdata(void)
{
  int n;

		 for (n=MAX_ROW-1; n >= 0;n--)	free(data[n]);
		 free(data);

		 for (n=1; n >= 0;n--)	free(temp[n]);
		 free(temp);

		 free(index);

		 for (n=MAX_COL-1; n >= 0;n--)	free(label[n]);
		 free(label);

}
