/* corr.H   EJN */

#include <stdio.h>


#define CHBIN 0xF000    // Blink Invers
#define CHBHI 0x8F00	// Blink Highligted
#define CHHIG 0x0F00    // Highligted
#define CHINV 0x7000    // Invers
#define CHNOR 0x0700    // Normaal
#define CHLBD 201	// Grafische characters
#define CHLBE 218
#define CHRBD 187
#define CHRBE 191
#define CHLOD 200
#define CHLOE 192
#define CHROD 188
#define CHROE 217
#define CHHD  205
#define CHHE  196
#define CHVD  186
#define CHVE  179
#define CHSP  32        /* spatie */
#define CHRY  84	/* chr[CHRY][] */
#define CHRX  81        /* chr[][CHRX] */
#define MAXCOL 80

#define MOVE 160
#define DRAW 162
#define FILL 48
#define FILLO 208
#define COLOR0 176
#define COLOR1 177
#define COLOR2 178
#define COLOR3 179
#define COLOR4 180
#define COLOR5 181
#define COLOR6 182
#define COLOR7 183
#define COLOR8 184
#define COLOR9 185
#define COLOR10 186
#define COLOR11 187
#define COLOR12 188
#define COLOR13 189
#define COLOR14 190
#define COLOR15 191
#define TEXT 168
#define FONT 167
#define SIZE 172
#define END 6
#define UP 72
#define DOWN 80
#define HOME 71
#define ENDT 79
#define LEFT 75
#define UP 72
#define EXEC 13
#define ESC 0X1b
#define RIGHT 77
#define PgUp 73
#define PgDn 81
#define SPACE 32
#define RETURN 13
#define TAB 9
#define MAXLEN 80


#define TRUE	1
#define FALSE	0
#define ON	1
#define OFF	0

#define LOAD     0
#define CHADIR   1
#define VIEW     2
#define PRINT    3
#define AUTO     4
#define PRNONOF  5
#define XLIMIT   6
#define LOOKALL  7
#define PLAATJE  8
#define NPLAATJE 9
#define DUMP    10
#define LIJN    11
#define YLIMIT  12
#define QUIT    13

#define LX 3300              /* Lengte papier 11' in dots */
/*
#define SPECIAL_KEY 0
#define UP 72
#define DOWN 80
#define HOME 71
#define ENDT 79
#define LEFT 75
#define UP 72
#define EXEC 13
#define ESC 27
#define RIGHT 77
#define PgUp 73
#define PgDn 81
#define SPACE 32
#define RETURN 13
#define TAB 9
*/
#define LOTUS1 0X0404
#define LOTUS2 0X0405

//flowcomm
#define PICXF 3000/4000       /* correctie factor naar LOTUS.PIC file */
#define PICYF 2200/3000
#define SBOX 10               /* grootte viekant meetpunt in plaatje */
#define CENTER 0
#define CENTERLEFT 1
#define CENTERTOP 2
#define CENTERRIGHT 3
#define CENTERBOTTOM 4
#define TOPLEFT 5
#define TOPRIGHT 6
#define BOTTOMLEFT 7
#define BOTTOMRIGHT 8
#define H_SCREEN 4000/320     /* screen unit per pixel */
#define V_SCREEN 3000/200
#define H_OFFSET 700          /* offset linker onderhoek box plaatje */
#define V_OFFSET 450
#define H_FONT 8
#define V_FONT 8
#define H_SCALE 0.99           /* factor lengte en breedte box t.o.v. */
#define V_SCALE 0.8           /* overgebleven ruimte na offset */
#define H_WIDTH 4000          /* lengte en breedte lotus graphics screen */
#define V_WIDTH 3000
#define MAX_LEN 40
#define MISSING -999999.0


//flow.h
extern void main(int ,char **);
extern void prntest(void);
extern void beep(unsigned, unsigned);
extern void mallocdata(void);
extern void freemallocdata(void);

//fdrawpic.c
void drawpic(char*);
extern void Initialize(void);
extern char *filedir(char *);
extern void screendump(void);
extern void Initialize(void);
extern void initdisplay(void);
extern void screendump(void);
extern void prnonoff(void);

//enfile.c
extern int      check_drive(char *);
extern char     *filedir(char *);
extern void     changedir(void);
extern unsigned parse (char *);

//flowcalc.c
extern void fill_temp(int);
extern void reken(int);
extern int  comp(float* , float* );
extern void teken_graph(void);
extern void print_labels(void);

//FLOWCOMM
extern double getd(FILE *);
extern void display_labels(void);
extern void teken(double xp, double yp);
extern void teken(double xp,double yp);
extern void moef(double xp, double yp);
extern void point(double xp,double yp);
extern void numm(double xp, double yp,int number);
extern void prnt(double xpos,double ypos,int size,int richting,char *tekst);
extern void prntc(double xpos,double ypos,int size,int richting, char *tekst);
extern void picopen(void);
extern void picmove(int x,int y);
extern void picfont(char font);
extern void piccolor(int color);
extern void picsize(int x,int y);
extern void picdraw(int x,int y);
extern void pictext(int direction,int position,char *s);
extern void picend(void);
extern void picxy(int x,int y);
extern void picbox(int ox,int oy,int lx,int ly);
extern void display_data(void);
extern void read_wks(char *);
extern void skip(FILE *, long );

//FLOWMENU
extern int display_menu(int);
extern int display_size_menu(void);
extern int menuver(char menu[90][40],int,int,int,int);
//int menuver(menu[][],int,int,int,int);
extern int load_dir(void);

//video.c
//void void box(topy,topx,lang,breed,type,kleur);
//void void box1(topy,topx,lang,breed,type,kleur);
extern void swrite(int,int,char *,int);
extern void initdisplay(void);
extern void cursoroff(void);
extern void cursoron(void);
extern void cursor(int,int);
extern void mode(int);
extern void palette(int);
extern void veeg (int, int, int, int);
