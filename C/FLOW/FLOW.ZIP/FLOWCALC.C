 /*     corrcalc  */

#include "flow.h"
#include "stdlib.h"
#include "dos.h"
#include "time.h"
#include "alloc.h"
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "conio.h"

#define MISSING -999999.0
#define LAMBDA 1
#define AS_AANTAL 23   /*aantal aslabelingen */

void fill_temp(int j);
void reken(int j);
int  comp(float* , float* );
void teken_graph(void);
void print_labels(void);

//extern menuver(char** menu,int num, int topy,int topx,int breed);
//extern void picopen(void);

extern int   lijn,conf,autopic,plaatje;
extern int   print, show, num,spearm,lost;
extern float upx,upy,lowx,lowy;
extern float maxttest;
extern char  outfile[40];
extern char  fileload[40];
extern char  file[20];
extern unsigned long MAX_ROW;
extern unsigned long MAX_COL;
extern float **data;
extern int   *SCHERMPTR;
extern char  **label;
extern char  **labelrow;
extern float **temp;
extern int   *index;

int    rows, columns;
int    labels,xx,yy,aa,rows_temp;
float  aantal,ijkgetal,afwijking;
float  somx,somy;
double varx,vary,Sres;



/****************  fill temp  ****************/

void fill_temp(int j)

{
 int k;
 float vx=0,vy=0;

   rows_temp=0;
   ijkgetal=data[1][j];
   afwijking=data[2][j];
    for(k=3;k<rows;k++) /* 1e is label; 2e is ijkgetal 3e is afwijking*/
      {
	 vx = rows_temp+1;
	 vy = data[k][j];
     if (k-2 >= lowx && vy >= lowy)
      {
	  if (k-2<=upx && vy<=upy)
       {
         temp[0][rows_temp] = vx;
         temp[1][rows_temp] = vy;
	 index[rows_temp]   = k;
 if (show) printf("x=%0.3f  y=%0.3f\n",vx,vy);
	++rows_temp;
        }
       }
      }

}

/***************  rekenen ***************/

void reken(int j)
 {
 register int k;
 double somxx,somxy,somyy,sx,sy,sxy,nop;
 register float vx,vy;
 int a,b,c,d,l,s,t,m,n;


   printf("Processing (%d)  ",j+1);

    fill_temp(j);

/*    somx=0;*/
    somy=0;
/*    somxx=0;*/
    somyy=0;
/*    somxy=0;*/
    aantal=0;

    for(k=0;k<rows_temp;k++)
    {
/*    vx=temp[0][k];*/
    vy=temp[1][k];
/*      somx+= vx;*/
      somy+= vy;
/*      somxx+=vx*vx;*/
      somyy+=vy*vy;
/*      somxy+=vx*vy;*/
      aantal++;
    }
   if(aantal<3) return;

/*    sxy=(somxy-((somx*somy)/ aantal));
    sx= (somxx-((somx*somx)/ aantal));  */
    sy= (somyy-((somy*somy)/ aantal));
/*    varx = sx/(aantal - 1);*/
    vary = sy/(aantal - 1);

 }

/******************* compare *********************/

int comp( float *na,  float *nb)
{
if (*na != *nb ) return ((*na > *nb) ? 1: -1);
return (0);
}


/*************** teken plaatje ***************/

void teken_graph(void)
 {
 int x_as,y_as,toggle,n;
 long secs_now;
 float laagste_waarde,hoogste_waarde;
 char nop[25];
 char text[MAX_LEN];
 int i,j,asymin;
 float maxx,maxy,as_unit;
 float minx,miny;
 float vx,vy,asx,asy,mxx;
 double offpixx,offpixy;
 double lx,ly,mx,my,a,b;
 double facx,facy;

float as[AS_AANTAL];
as[0]=0.01;
as[1]=0.02;
as[2]=0.05;
as[3]=0.1;
as[4]=0.2;
as[5]=0.5;
as[6]=1;
as[7]=2;
as[8]=5;
as[9]=10;
as[10]=20;
as[11]=50;
as[12]=100;
as[13]=250;
as[14]=500;
as[15]=1000;
as[16]=2500;
as[17]=5000;
as[18]=10000;
as[19]=20000;
as[20]=100000;
as[21]=500000;
as[22]=1000000;

  clrscr();
  while(kbhit()) getch();
  xx=yy=0;
  strcpy(outfile,"0");
  print_labels();

  if(!autopic)
  {
   printf("Welke rij op de Y-as? ");
   gets(nop);
   yy=atoi(nop);
  }
  else yy=plaatje;

   if (yy>columns || yy<2) return;
   strcpy(nop,&label[yy-1][1]);
   nop[9]='\0';
  for(n=0;n<9;n++)
  {
    if(nop[n]==0)   break;
    if(nop[n]==' ') continue;
    if(nop[n]<'0')               nop[n]='_';
    if(nop[n]>'9' && nop[n]<'@') nop[n]='_';
    if(nop[n]>'Z' && nop[n]<'a') nop[n]='_';
    if(nop[n]>'z')               nop[n]='_';
  }
  if(nop[0]==0) strcpy(nop,"Q");
  strcat(nop,".PIC");
  strcpy(outfile,nop);
/*  x_as=xx;*/
  y_as=yy;
  maxx=maxy=0.01;
  miny=999999;
  y_as--;
  reken((int)y_as);
  laagste_waarde=ijkgetal-ijkgetal*0.15;
  hoogste_waarde=ijkgetal+ijkgetal*0.15;
  maxy=hoogste_waarde;
  miny=laagste_waarde;
  if(aantal<3) {printf("Aantal is < 3, Graph gestopt\n");
		 delay(2000); return; }
  picopen();

  for (i=0;i<rows_temp;i++)            /*vind as vermenigvuldigingsfactor*/
  {
   vx=temp[0][i];
   vy=temp[1][i];

     if (vx>maxx)
       maxx=vx;

     if (vy>maxy)
       maxy=vy;

     if (vy<miny)
       miny=vy;
   }
     maxx*=1.05;
     maxy*=1.05;
     miny*=0.95;

     for (i=0;i<=AS_AANTAL;i++)
     {
      asx=as[i];
      if (20*asx > maxx)       break;
     }

     for (i=0;i<=AS_AANTAL;i++)
     {
      asy=as[i];
      if (20*asy> maxy)        break;
      }

     for(i=0;i<100;i++)
      if( (float)(i*asy) > miny ) break;

       miny=(float)(--i*asy);

     offpixx=H_OFFSET;
     offpixy=V_OFFSET;

     lx=(H_WIDTH-H_OFFSET)*H_SCALE;               /*lengte assen*/
     ly=(V_WIDTH-V_OFFSET)*V_SCALE;

     facx=lx/maxx; /*factor data*/
     facy=ly/(maxy-miny);

     moef(offpixx,offpixy);                      /*draw box*/
     teken(lx+offpixx,offpixy);
     teken(lx+offpixx,ly+offpixy);
     teken(offpixx,ly+offpixy);
     teken(offpixx,offpixy);

    mxx=50;
    for (i=1;i<=(int)(maxx/asx);i++)
       {
	mx=(double)((float)i*facx*asx+offpixx);
	my=(double)(offpixy);
	moef(mx,my);
	teken(mx,my+100.0);
	strcpy(text,labelrow[(int)(i*asx)]+1);
	prnt(mx-50,my-200.0+mxx,1,0,text);
	mxx=-mxx;
       }

   for (i=0;i<=(int)((maxy-miny)/asy);i++)
       {
	mx=offpixx;
        my=(double)((float)(i*asy)*facy+offpixy);
        moef(mx,my);
        teken(mx+100.0,my);
        gcvt((float)i*asy+miny,3,text);
        prnt(mx-400.0,my-50,1,0,text);
       }

/*        prntc(offpixx+200,20.0,1,0 ,&label[(int)x_as][1]);
	prntc(100.0,offpixy,1,90,&label[(int)y_as][1]);  /* print assen */
*/
	piccolor(2);
	sprintf(text,"Mean= %5.3f",somy/aantal);
	prnt(810.0,2550.0,1,0,text);

        sprintf(text,"Sdev= %5.2f",sqrt(vary));
	prnt(1710.0,2550.0,1,0,text);

	sprintf(text,"VC= %3.1f %",(sqrt(vary)/(somy/aantal))*100);
	prnt(2500.0,2550.0,1,0,text);

	sprintf(text,"N= %3.0f",aantal);
	prnt(3200.0,2550.0,1,0,text);

        piccolor(YELLOW);

	sprintf(text,"Inputmean= %5.3f   Deviation= %3.2f %",ijkgetal,((somy/aantal-ijkgetal)/ijkgetal)*100);                       /* print regressie data */
	prnt(810.0,2650.0,1,0,text);

        piccolor(3);
	prnt(2500.0,2750.0,1,0,&label[(int)y_as][1]);
        piccolor(1);

        time(&secs_now);
	strcpy(nop,ctime(&secs_now));
        nop[24]='\0';
        prnt(810.0,2750.0,1,0,nop);

        piccolor(LIGHTRED);
	sprintf(text,"Afwijking +/- %3.0f %",afwijking);
        prnt(1500.0,2350.0,1,0,text);

        piccolor(0);
	sprintf(text,"file: %s",fileload);
        prnt(50.0,50.0,1,0,text);



   if (lijn)
   {
   piccolor(LIGHTRED);
   /* teken +/- lijn */

   my=ijkgetal*(1+afwijking/100)-miny;
   mx=0;
   moef(mx*facx+offpixx,(my)*facy+offpixy);

   toggle = 1;
   for(mx = 0; mx < maxx; mx += maxx/50)
        {
	   if (toggle)   teken(mx*facx+offpixx,my*facy+offpixy);
		  else    moef(mx*facx+offpixx,my*facy+offpixy);
	   toggle=1-toggle;
	}
   my=ijkgetal*(1-afwijking/100)-miny;
   mx=0;
   moef(mx*facx+offpixx,(my)*facy+offpixy);

   toggle = 1;
   for(mx = 0; mx < maxx; mx += maxx/50)
        {
	   if (toggle)   teken(mx*facx+offpixx,my*facy+offpixy);
		  else    moef(mx*facx+offpixx,my*facy+offpixy);
	   toggle=1-toggle;
	}
  piccolor(LIGHTGREEN);
  my=ijkgetal-miny;
   mx=0;
   moef(mx*facx+offpixx,my*facy+offpixy);

   toggle = 0;
   for(mx = 0; mx < maxx; mx += maxx/100)
	{
	   if (!toggle)   teken(mx*facx+offpixx,my*facy+offpixy);
			 else    moef(mx*facx+offpixx,my*facy+offpixy);
	   if(++toggle==5) toggle=0;
	}
    }
   piccolor(0);

  for (i=0;i<rows_temp;i++)
  {
   vx=temp[0][i];
   vy=temp[1][i];

    if (num)
       numm((double)vx*facx+offpixx,(double)(vy-miny)*facy+offpixy,i);
    else
       point((double)vx*facx+offpixx,(double)(vy-miny)*facy+offpixy);
    }


 picend();
}



void print_labels(void)
{
 int n,colx=0,rowy=5;
 char text[MAX_LEN];
 for(n=0;n<labels;n++)
   {
	itoa(n+1,text,10);
	strcat(text,"    ");
	text[3]=0;
	strcat(text,&label[n][1]);
	text[15]=0;
	swrite(colx,rowy,text,0x1700);
	if(++rowy > 24)  { colx +=16; rowy=5;}
	if(colx>66) break;
   }
}