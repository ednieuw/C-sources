 /* dispmenu.c Ed Nieuwenhuys*/

#include "alloc.h"
#include "stdlib.h"
#include "string.h"
#include "stdio.h"
#include "process.h"
#include "dir.h"
#include "time.h"
#include "dos.h"
#include "flow.h"
#include "graphics.h"
#include "bios.h"
#include "conio.h"

#define breedte_item 35
#define breedte_size_menu 15
#define lang 10

#define ROMAX 25
#define COMAX 80
#define MENMAX 10

int display_menu(int);
int display_size_menu(void);
int menuver(char menu[90][40],int num, int topy,int topx,int breed);
int load_dir(void);


extern int *SCHERMPTR;
//extern swrite(int ,int ,char * ,int);
extern int print;
extern int spearm;
extern int lost;
extern int lijn,conf;
extern char curdir[40];
extern long MAX_ROW,MAX_COL;
extern int geladen;
extern char fileload[40];
extern float upx,upy,lowx,lowy,maxttest;
char titel[90][40];
char sizep[5][40];

int display_menu(int wis)
{
   int num,breed,keuze;
   char nop[10];
   char text[80];
   long memsize;
   struct dfree free;
   long avail;
   int drive;

   num=load_dir();                   /* laad tekst menu */
   if(wis) clrscr();
   swrite(13,0,"FLOWCHART EJN 10/08/1991\0",0x0E00);
   cursor(13,1);
   printf("%ld Cols  %ld Rows",MAX_COL,MAX_ROW);
   if (lost) swrite(13,24,"Rows or columns lost !",0xF400);

   memsize=(long) farcoreleft();
   ltoa(memsize,nop,10);
   swrite(0,0,nop,0x0300);

   if (geladen)
      {
       swrite (50,6,"File \0",0x0300);
       swrite (55,6,fileload,0x0300);
      }
   cursor(50,12);
   printf("X limits: %0.0f - %0.0f",lowx,upx);
   cursor(50,13);
   printf("Y limits: %0.0f - %0.0f",lowy,upy);

   drive = getdisk();
   getdfree(drive+1, &free);
   if (free.df_sclus == 0xFFFF)
   {
      printf("Error in getdfree() call\n");
      exit(1);
   }

   avail =  (long) free.df_avail *
            (long) free.df_bsec *
            (long) free.df_sclus;
   sprintf(text,"Drive %c: has %ld Kbytes free\0", 'A' + drive, avail/1000);
   swrite(13,22,text,0x0600);

   swrite(13,23,"Directory =                                 \0",0x0600);
   swrite(25,23,(char *)curdir,0x0600);

   cursor(0,0);
   breed=breedte_item;
   keuze = menuver(titel,num,5,15,breed);
   if (keuze==QUIT || keuze==-1) clrscr();

   return((int) keuze);
}

int display_size_menu(void)
{
   int num,nr,breed,keuze;
   char naam[40];
   num=load_dir();                   /* laad tekst menu */
   veeg(4,58,10,20);
   breed=breedte_size_menu;
   keuze = menuver(sizep,num,5,60,breed)+1;
   if (keuze==0) keuze=1;
   veeg(4,58,10,20);
   return(keuze);
}

				/* verticaal menu */
int menuver(char menu[90][40],int num,int ltopy,int ltopx,int breed)
{
   long secs_now;
   char *str_now;
   int x, y, code, code1, oke, yy, xx, keer,leave,keus;
   int keuze;
   char ch;

   yy = ltopy;
   xx = ltopx;
   oke = 0;
   keuze = 0;
   box(yy-1,xx-2,num+2,breed,2,0);

   while (1)
      {
	 yy=ltopy;
	 for (y=0; y<num; y++)
	    {
	      yy++;
	      xx=ltopx+1;
	       for (x=0; x<strlen(menu[y]); x++)
		  {
		     xx++;
		     ch = menu[y][x];
		     if (y==keuze)
			  *(SCHERMPTR + yy*COMAX + xx) = ch | 0x2400;
                     else
                        if (x==0)
			       *(SCHERMPTR + yy*COMAX + xx) = ch | 0x4E00;
                        else
			       *(SCHERMPTR + yy*COMAX + xx) = ch | 0x7C00;
		  }
            }
         if(oke == 1)
            return(keuze);

         while(bioskey(1)==0)
	 {
	   time(&secs_now);
           str_now=ctime(&secs_now);
           xx=55;
           str_now[24]='\0';
	   swrite(xx,0,str_now,0x1300);
          }

         code = getch();
         code1=0;
         if(code==32) {code1=32; code=0;}
         if(code == 0)
            {
            if(code1 !=32)  code1 = getch();
            switch (code1)
               {
               case 32:
                  ++keuze; break;
               case 72:
                  --keuze; break;
               case 75:
                  --keuze; break;
               case 80:
                  ++keuze; break;
               case 77:
                  ++keuze; break;
               case 71:
		  keuze = 0; break;
               case 79:
                  keuze = num-1; break;
               }

               if(keuze < 0)
		  keuze = num-1;
	       if(keuze > num-1)
                  keuze = 0;
            }
         else
            {
            ch = code;
            keus=keuze;
            leave=0;
            keer=-1;
            while(keer<2)
           {
           keer++;
           if(keer==1) { keus=-1;}
            for(y=keus+1; y<num; y++)
               {
               if(strnicmp(&menu[y][0],&ch,1) == 0)
                  {
                  keuze = y;
                  oke = 0;
                  leave=1;
                  keer=2;
                  }
     if(leave) break;
               }
          }

/*            if(ch == 13)*/
	       oke = 1;
	    if(ch == 27)
	       {
	       keuze = -1;
	       oke = 1;
	       }
	    }
      }

}


int load_dir(void)
{
   int nr=14;  /*aantal items*/

      strcpy(titel[0],"Retrieve LOTUS file       \0");
      strcpy(titel[1],"Other drive / directory   \0");
      strcpy(titel[2],"View PIC file             \0");
      strcpy(titel[3],"Flowdata printen          \0");
      strcpy(titel[4],"All graphs to PIC file    \0");
     if(print)
      strcpy(titel[5],"Printer ON/off            \0");
 else strcpy(titel[5],"Printer on/OFF            \0");
      strcpy(titel[6],"X limits                  \0");
      strcpy(titel[7],"Look at all graphs        \0");
      strcpy(titel[8],"Graph                     \0");
      strcpy(titel[9],"Numbered graph            \0");
      strcpy(titel[10],"Draw all numbered graphs  \0");
    if (lijn)
      strcpy(titel[11],"Line ON/off               \0");
 else strcpy(titel[11],"Line on/OFF               \0");
      strcpy(titel[12],"Y limits                  \0");
      strcpy(titel[13],"Quit                      \0");

  return(nr);
 }

