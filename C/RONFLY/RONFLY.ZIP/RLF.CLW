; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CRlfView
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "rlf.h"
VbxHeaderFile=rlf.h
VbxImplementationFile=rlf.cpp

ClassCount=6
Class1=CRlfApp
Class2=CRlfDoc
Class3=CRlfView
Class4=CMainFrame
Class5=CAboutDlg

ResourceCount=4
Resource1=IDD_ABOUTBOX
Resource2=IDD_DIALOG1
Class6=CFlashWrdDlg
Resource3=IDR_MAINFRAME
Resource4=IDD_VUURVLIEG_WAARDEN

[CLS:CRlfApp]
Type=0
HeaderFile=rlf.h
ImplementationFile=rlf.cpp
Filter=N
LastObject=ID_VUURVLIEG_WIPJE

[CLS:CRlfDoc]
Type=0
HeaderFile=rlfdoc.h
ImplementationFile=rlfdoc.cpp
Filter=N
LastObject=ID_VUURVLIEG_WAARDEN

[CLS:CRlfView]
Type=0
HeaderFile=rlfview.h
ImplementationFile=rlfview.cpp
Filter=C
LastObject=CRlfView

[CLS:CMainFrame]
Type=0
HeaderFile=mainfrm.h
ImplementationFile=mainfrm.cpp
Filter=T
LastObject=CMainFrame

[CLS:CAboutDlg]
Type=0
HeaderFile=rlf.cpp
ImplementationFile=rlf.cpp
Filter=D

[ACL:IDR_MAINFRAME]
Type=1
Command1=ID_EDIT_COPY
Command2=ID_FILE_NEW
Command3=ID_FILE_OPEN
Command4=ID_FILE_PRINT
Command5=ID_FILE_SAVE
Command6=ID_EDIT_PASTE
Command7=ID_EDIT_UNDO
Command8=ID_EDIT_CUT
Command9=ID_NEXT_PANE
Command10=ID_PREV_PANE
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_EDIT_CUT
Command14=ID_EDIT_UNDO
CommandCount=14
Class=CRlfView

[CLS:CFlashWrdDlg]
Type=0
HeaderFile=flashdlg.h
ImplementationFile=flashdlg.cpp
Filter=D
LastObject=IDC_MAX_WAARDE

[DLG:IDD_DIALOG1]
Type=1
ControlCount=2
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816

[MNU:IDR_MAINFRAME]
Type=1
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_SAVE_AS
Command5=ID_FILE_PRINT
Command6=ID_FILE_PRINT_PREVIEW
Command7=ID_FILE_PRINT_SETUP
Command8=ID_FILE_MRU_FILE1
Command9=ID_APP_EXIT
Command10=ID_EDIT_UNDO
Command11=ID_EDIT_CUT
Command12=ID_EDIT_COPY
Command13=ID_EDIT_PASTE
Command14=ID_VIEW_TOOLBAR
Command15=ID_VIEW_STATUS_BAR
Command16=ID_APP_ABOUT
Command17=ID_VUURVLIEG_VLIEGEN
Command18=ID_VUURVLIEG_RUSTEN
Command19=ID_VUURVLIEG_WIPJE
Command20=ID_VUURVLIEG_WAARDEN
CommandCount=20
Class=CRlfView

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg

[DLG:IDD_VUURVLIEG_WAARDEN]
Type=1
ControlCount=29
Control1=IDC_STATIC,static,1342308352
Control2=IDC_YAS_BLOK,edit,1350631552
Control3=IDC_STATIC,static,1342177280
Control4=IDC_XAS_BLOK,edit,1350631552
Control5=IDC_STATIC,static,1342177280
Control6=IDC_START_FLASH,edit,1350631552
Control7=IDC_STATIC,static,1342177280
Control8=IDC_MAX_WAARDE,edit,1350631552
Control9=IDC_STATIC,static,1342177280
Control10=IDC_INVLOED,edit,1350631552
Control11=IDC_STATIC,static,1342177280
Control12=IDC_MOEHEID,edit,1350631552
Control13=IDC_STATIC,static,1342177280
Control14=IDC_ENERGIE,edit,1350631552
Control15=IDC_STATIC,static,1342177280
Control16=IDC_PER_ERBIJ,edit,1350631552
Control17=IDC_STATIC,button,1342177287
Control18=IDC_HOEFLASH_0,button,1342308361
Control19=IDC_HOEFLASH_1,button,1342177289
Control20=IDC_HOEFLASH_2,button,1342177289
Control21=IDC_STATIC,button,1342177287
Control22=IDC_HOEERBIJ_0,button,1342308361
Control23=IDC_HOEERBIJ_1,button,1342177289
Control24=IDC_HOEERBIJ_2,button,1342177289
Control25=IDOK,button,1342373889
Control26=IDDOORGAAN,button,1342242816
Control27=IDRESET,button,1342242816
Control28=IDCANCEL,button,1342242816
Control29=IDC_STATIC,static,1342177283
Class=CFlashWrdDlg

