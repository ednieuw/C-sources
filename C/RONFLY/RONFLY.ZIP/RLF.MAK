# Microsoft Visual C++ generated build script - Do not modify

PROJ = RLF
DEBUG = 0
PROGTYPE = 0
CALLER = 
ARGS = 
DLLS = 
D_RCDEFINES = /d_DEBUG
R_RCDEFINES = /dNDEBUG
ORIGIN = MSVC
ORIGIN_VER = 1.00
PROJPATH = C:\C\PRIVE\FIREFLY\RLF\
USEMFC = 1
CC = cl
CPP = cl
CXX = cl
CCREATEPCHFLAG = 
CPPCREATEPCHFLAG = /YcSTDAFX.H
CUSEPCHFLAG = 
CPPUSEPCHFLAG = /YuSTDAFX.H
FIRSTC =             
FIRSTCPP = STDAFX.CPP  
RC = rc
CFLAGS_D_WEXE = /nologo /G2 /W3 /Zi /AL /Od /D "_DEBUG" /FR /GA /Fd"RLF.PDB" 
CFLAGS_R_WEXE = /nologo /Gs /G2 /W3 /AL /O1 /D "NDEBUG" /FR /GA 
LFLAGS_D_WEXE = /NOLOGO /NOD /PACKC:61440 /STACK:10240 /ALIGN:16 /ONERROR:NOEXE /CO
LFLAGS_R_WEXE = /NOLOGO /NOD /PACKC:61440 /STACK:10240 /ALIGN:16 /ONERROR:NOEXE
LIBS_D_WEXE = lafxcwd oldnames libw llibcew commdlg olesvr olecli shell 
LIBS_R_WEXE = lafxcw oldnames libw llibcew commdlg olesvr olecli shell 
RCFLAGS = /nologo /z
RESFLAGS = /nologo /t
RUNFLAGS = 
DEFFILE = RLF.DEF
OBJS_EXT = 
LIBS_EXT = 
!if "$(DEBUG)" == "1"
CFLAGS = $(CFLAGS_D_WEXE)
LFLAGS = $(LFLAGS_D_WEXE)
LIBS = $(LIBS_D_WEXE)
MAPFILE = nul
RCDEFINES = $(D_RCDEFINES)
!else
CFLAGS = $(CFLAGS_R_WEXE)
LFLAGS = $(LFLAGS_R_WEXE)
LIBS = $(LIBS_R_WEXE)
MAPFILE = nul
RCDEFINES = $(R_RCDEFINES)
!endif
!if [if exist MSVC.BND del MSVC.BND]
!endif
SBRS = STDAFX.SBR \
		RLF.SBR \
		MAINFRM.SBR \
		RLFDOC.SBR \
		RLFVIEW.SBR \
		FLASHDLG.SBR


RLF_RCDEP = c:\c\prive\firefly\rlf\res\rlf.ico \
	c:\c\prive\firefly\rlf\res\rlf.rc2


STDAFX_DEP = c:\c\prive\firefly\rlf\stdafx.h


RLF_DEP = c:\c\prive\firefly\rlf\stdafx.h \
	c:\c\prive\firefly\rlf\rlf.h \
	c:\c\prive\firefly\rlf\mainfrm.h \
	c:\c\prive\firefly\rlf\rlfdoc.h \
	c:\c\prive\firefly\rlf\rlfview.h


MAINFRM_DEP = c:\c\prive\firefly\rlf\stdafx.h \
	c:\c\prive\firefly\rlf\rlf.h \
	c:\c\prive\firefly\rlf\mainfrm.h


RLFDOC_DEP = c:\c\prive\firefly\rlf\stdafx.h \
	c:\c\prive\firefly\rlf\rlf.h \
	c:\c\prive\firefly\rlf\rlfdoc.h


RLFVIEW_DEP = c:\c\prive\firefly\rlf\stdafx.h \
	c:\c\prive\firefly\rlf\rlf.h \
	c:\c\prive\firefly\rlf\rlfdoc.h \
	c:\c\prive\firefly\rlf\rlfview.h


FLASHDLG_DEP = c:\c\prive\firefly\rlf\stdafx.h \
	c:\c\prive\firefly\rlf\rlf.h \
	c:\c\prive\firefly\rlf\flashdlg.h


all:	$(PROJ).EXE $(PROJ).BSC

RLF.RES:	RLF.RC $(RLF_RCDEP)
	$(RC) $(RCFLAGS) $(RCDEFINES) -r RLF.RC

STDAFX.OBJ:	STDAFX.CPP $(STDAFX_DEP)
	$(CPP) $(CFLAGS) $(CPPCREATEPCHFLAG) /c STDAFX.CPP

RLF.OBJ:	RLF.CPP $(RLF_DEP)
	$(CPP) $(CFLAGS) $(CPPUSEPCHFLAG) /c RLF.CPP

MAINFRM.OBJ:	MAINFRM.CPP $(MAINFRM_DEP)
	$(CPP) $(CFLAGS) $(CPPUSEPCHFLAG) /c MAINFRM.CPP

RLFDOC.OBJ:	RLFDOC.CPP $(RLFDOC_DEP)
	$(CPP) $(CFLAGS) $(CPPUSEPCHFLAG) /c RLFDOC.CPP

RLFVIEW.OBJ:	RLFVIEW.CPP $(RLFVIEW_DEP)
	$(CPP) $(CFLAGS) $(CPPUSEPCHFLAG) /c RLFVIEW.CPP

FLASHDLG.OBJ:	FLASHDLG.CPP $(FLASHDLG_DEP)
	$(CPP) $(CFLAGS) $(CPPUSEPCHFLAG) /c FLASHDLG.CPP


$(PROJ).EXE::	RLF.RES

$(PROJ).EXE::	STDAFX.OBJ RLF.OBJ MAINFRM.OBJ RLFDOC.OBJ RLFVIEW.OBJ FLASHDLG.OBJ $(OBJS_EXT) $(DEFFILE)
	echo >NUL @<<$(PROJ).CRF
STDAFX.OBJ +
RLF.OBJ +
MAINFRM.OBJ +
RLFDOC.OBJ +
RLFVIEW.OBJ +
FLASHDLG.OBJ +
$(OBJS_EXT)
$(PROJ).EXE
$(MAPFILE)
c:\msvc\lib\+
c:\msvc\mfc\lib\+
c:\c\sao\lib\+
c:\c\sao\prrl\+
$(LIBS)
$(DEFFILE);
<<
	link $(LFLAGS) @$(PROJ).CRF
	$(RC) $(RESFLAGS) RLF.RES $@
	@copy $(PROJ).CRF MSVC.BND

$(PROJ).EXE::	RLF.RES
	if not exist MSVC.BND 	$(RC) $(RESFLAGS) RLF.RES $@

run: $(PROJ).EXE
	$(PROJ) $(RUNFLAGS)


$(PROJ).BSC: $(SBRS)
	bscmake @<<
/o$@ $(SBRS)
<<
