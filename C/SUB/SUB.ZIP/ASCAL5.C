/* test-programma voor lin/log_calibratie 050488 */
/*
if exist error del error
rem -C: nested comments
rem -v: debug
rem -N: stack overflow
rem -w: all warnings
tcc -mh -w -v -N -C ascal5 >error
if exist ascal5.exe del ascal5.obj
type error
*/

#include "stdio.h"
#include "stdlib.h"
#include "conio.h"
#include "math.h"

#define FALSE 0
#define TRUE 1
#define LARGE  0
#define MEDIUM 1
#define SMALL  2
#define LINEAR 3
#define MAXNOOFCALIBRATORS 8
#define MISSING_CALIBRATOR -999
#define MAKELOG(data) if (logflag) data=log10((double)(data)/1000)*1000

FILE *tracefile;
int Trace=1;
char    calibratorstring[MAXNOOFCALIBRATORS][16];
double  value_of_calibrator[MAXNOOFCALIBRATORS];
int exponent[MAXNOOFCALIBRATORS];

int calbase[4][4]={  10,0,0,0,
                     10,30,0,0,
                     10,20,50,0,
                     10,20,25,50,
                  };
void open_tracefile(char *s);
int ascal(int *noofcalibrators, float *min, float *max, int logflag, int calcflag, int expflag);
double scientific2(double d, double *base, int *exp);
int round(double d);
double val(double mantissa, int exponent);
double pow10d(double exponent);

int main() {
    int n, noofcalibrators=MAXNOOFCALIBRATORS, logflag, calcflag=1;
    int pos, cal, mantissa, lowest_exponent, highest_exponent;
    double calibrator_value;
    float min, max, min2, max2;
    open_tracefile("C:trace");
    for (;;) {
		printf("\ngeef minimum en maximum_waarde: ");
        scanf("%f %f",&min,&max);
        fprintf(tracefile, "min=%.3f max=%.3f",min,max);
        if (min>max) break;
        logflag=0;
        min2=min;
        max2=max;
        logflag = ascal(&noofcalibrators, &min, &max, logflag, calcflag,FALSE);
        printf("\nlineair: min=%.4lf max=%.4lf\n", min, max);
        for ( n=0 ; n<noofcalibrators ; n++ ) printf("\n%s",calibratorstring[n]);
        logflag=1;
        min=min2;
        max=max2;
        logflag = ascal(&noofcalibrators, &min, &max, logflag, calcflag,FALSE);
        printf("\nlogaritmisch: min=%.4lf max=%.4lf\n", min, max);
        if (logflag) {
           for ( n=0 ; n<noofcalibrators ; n++ ) printf("\n%s",calibratorstring[n]);
           highest_exponent=(int)(max/log(10)+0.001);
           lowest_exponent=(int)(min/log(10)-0.001);
           fprintf(tracefile,"\nhighest exponent:%d lowest exponent:%d",
              highest_exponent, lowest_exponent);
           for (cal=lowest_exponent; cal<=highest_exponent; cal++) {
              for (mantissa=1;mantissa<10;mantissa++) {
                 calibrator_value= log(val((double)mantissa,cal));
                 if (calibrator_value > min && calibrator_value < max) {
                    pos= 10000 * (calibrator_value-min)/(max-min);
                    printf("\ncalibrator_value=%.4lf pos=%d", exp(calibrator_value), pos);
                    fprintf(tracefile,"\ncalibrator_value=%.4lf pos=%d",
                       exp(calibrator_value), pos);
                 }
              }
           }
        } else printf("\ndata niet geschikt voor logaritmische calibratie\n");
        min=min2;
        max=max2;
        logflag = ascal(&noofcalibrators, &min, &max, logflag, calcflag,TRUE);
        printf("\nlogaritmisch (exponent-mode): min=%.4lf max=%.4lf\n", min, max);
        if (logflag) for ( n=0 ; n<noofcalibrators ; n++ ) printf("\n10^%s",calibratorstring[n]);
        else printf("\ndata niet geschikt voor logaritmische calibratie\n");
    }
    return 0;
}
        
int ascal(int *noofcalibrators, float *min, float *max, int logflag, int calcflag, int expflag) {
    int n, range, exp, exp0, t, t0, found, negative, precision, extra_decimal=0;
    double unit, value, tempmin, tempmax, ratio, base, lowest_calibrator;
    int exponent[MAXNOOFCALIBRATORS];
    if (logflag) round(scientific2(*min, &base, &exp));
    else round(scientific2(*max, &base, &exp));
    tempmin=*min * 10 +  fabs(*min)/10000;
    tempmax=*max * 10 -  fabs(*max)/10000;
    lowest_calibrator=val(10,exp);
    for (n=0;n<MAXNOOFCALIBRATORS;n++) {
        *calibratorstring[n]='\0';
        value_of_calibrator[n]=MISSING_CALIBRATOR;
    }

    if (logflag && tempmax<=0) logflag=FALSE;
    if (logflag) {
        if (tempmin<=0) tempmin= lowest_calibrator;
        ratio= (double)(tempmax / tempmin);
        if (ratio < 51 )       range= SMALL;
        else if (ratio < 501 ) range= MEDIUM;
        else                   range= LARGE;
    } else range=LINEAR;
    t=t0=0;
    found=FALSE;
    do{
       exp0=--exp;
       unit=val(calbase[range][t],exp);
    } while (3*unit>=tempmax-tempmin);
    while (!found) {
       if (! logflag) {
          found= ( 6*unit >= tempmax - tempmin);
          if (!found) {
             t++;
             t%=range+1;
             if (t==0) exp++;
             unit=val(calbase[range][t],exp);
          }
          if (found && t==2) extra_decimal=1;
       } else {
           value=val((double)calbase[range][t],exp+1);
           found= (value >= tempmin);
           if (!found) {
             t0=t;
             exp0=exp;
             t++;
             t%=range+1;
             if (t==0) exp++;
           } else {
             t=t0;
             exp=exp0;
             value=val((double)calbase[range][t],exp+1);
          }
       }
    }

PHASE2: /* find corrected min and max and fill array */
    if (!logflag) {
       if ( tempmin/unit-(int)(tempmin/unit) != 0) {
          negative= ( tempmin < 0);
          tempmin=  unit * (int)(tempmin/unit);
          if (negative) tempmin -= unit;
       }
    } else tempmin=val((double)calbase[range][t],exp+1);
    for (n=0 ; n < MAXNOOFCALIBRATORS ; n++) {
        if ( ! logflag ) {
           value_of_calibrator[n]=(tempmin + n*unit)/10;
           exponent[n]=exp;
        } else {
           exponent[n]= exp;
           value_of_calibrator[n]= val((double)calbase[range][t],exp);
           t++;
           t%=range+1;
           if (t==0) exp++;
        }
        if (value_of_calibrator[n] >= tempmax/10) {
            tempmax= value_of_calibrator[n]*10;
            *noofcalibrators=n+1;
            break;
        }
    }
    *min=tempmin/10;
    *max=tempmax/10;
    if (!calcflag) return logflag;

/* phase 3: print results in minimal-length strings */
                                  
    for (n=0; n< *noofcalibrators ; n++) {
        if (value_of_calibrator[n]>(*max>0?1.0001* *max:0.9999* *max)) {
           fprintf(tracefile,"\ncal[%d]=%.4lf *max=%.4lf verschil:%lf",
              n, value_of_calibrator[n], *max, value_of_calibrator[n] - *max);
           break;
        }
        if (logflag && expflag) sprintf(calibratorstring[n],"%d",exponent[n]+1);
        else {
           precision= (range==LINEAR) ? (extra_decimal - exponent[n]): -1-exponent[n];
           if (precision<0) precision=0;
           sprintf(calibratorstring[n],"%.*lf", precision, value_of_calibrator[n]);
        }
        fprintf(tracefile, "\n%4d logflag=%d exponent[%d]=%d value_of_calibrator[%d]=%.3lf precision=%d \"%s\"",
           __LINE__, logflag, n, exponent[n], n, value_of_calibrator[n], precision, calibratorstring[n]);
    }

/* phase 4: if (logflag) transform data */

   if (logflag) for (n=0; n<*noofcalibrators; n++) value_of_calibrator[n]=log(value_of_calibrator[n]);

/* return logflag to indicate whether log-transformation was actually performed */

    return logflag;
}

double scientific2(double d, double *base, int *exp) {
   double logd;
   int neg=FALSE;
   if (d==0) {
      *base=0;
      *exp=-1;
      return *base;
   }
   if (d<0) {
      neg=1;
      d=-d;
   }
   logd=log10(d);
   *exp= (int)logd - (d<1)-1;
   *base= pow10d(logd-*exp);
   if (neg) *base=-*base;
/*
   fprintf(tracefile, "\n%4d: scientific2: d=%.4lf logd=%.4lf scientific2: %.4lf E%d",
      __LINE__ ,d, logd, *base, *exp);
*/
   return *base;
}

double val(double mantissa, int exponent) {
   double value;
   value= mantissa*pow10(exponent);
/*
   fprintf(tracefile,"\n%4d: val: mantissa=%.3lf exponent=%d value=%.3lf",
      __LINE__, mantissa, exponent, value);
*/
   return value;
}

int round(double d) {
    int i=(int)d, result;
    if (d-i<.5 ) result= (int)(d+.5);
    else result= (int)(d+1);
/*
    fprintf(tracefile,"\n%4d: round: d=%.3lf result=%d",
      __LINE__, d, result);
*/
    return result;

}

double pow10d(double exponent) {
   /* 10^exponent, exponent is double rather than int, as required for pow() */
   double result;
   result= exp(exponent*log(10));
/*
   fprintf(tracefile,"\n%4d: pow10d: exponent=%.3lf result=%.3lf",
      __LINE__, exponent, result);
*/
    return result;
}

void open_tracefile(char *s) {
   if ((tracefile=fopen(s,"wt"))==0) {
      printf("cannot open \"%s\"",s);
      exit(0);
   } else printf("%s open\n",s);
}

/*
   if (logyflag) {
      highest_exponent=(int)(max/log(10)+0.001);
      lowest_exponent=(int)(min/log(10)-0.001);
      if (Trace) fprintf(tracefile,"\n%4d: highest exponent:%d lowest exponent:%d",
         __LINE__, highest_exponent, lowest_exponent);
      for (cal=lowest_exponent; cal<=highest_exponent; cal++) {
         for (mantissa=1;mantissa<10;mantissa++) {
            calibrator_value= log(val((double)mantissa,cal));
            if (calibrator_value > min && calibrator_value < max) {
               pos= y_origin + scale_yfactor * (calibrator_value-min);
               if (pos<y_origin || pos>y_origin+ y_length) continue;
               for (n=0;n<Plotter;n++) {
                  picmove(x_origin,pos);
                  picdraw(x_origin+RIM/4,pos);
                  if (Ycal<2) {
                     picmove(x_origin+x_length+RIM,pos);
                     picdraw(x_origin+x_length+3*RIM/4,pos);
                  }
               }
            }
         }
      }
   }
   x_origin+=RIM;
   x_length-=RIM;
*/
