/* bar : teken horizontal bar-graph + error-bars vanuit PRN-file */
/* compile:
if exist error del error
tcc -mc hbar >error
type error
*/
/* compile t.b.v. debugger (dc3.bat)
if exist error del error
if exist hbar.exe del hbar.exe
tcc -mh -v -C t1 >error
if exist hbar.exe del hbar.obj
type error
echo doorgaan naar TD?
pause
copy hbar.c \td
copy hbar.exe \td
cd \td
td hbar
cd\c
pe hbar.c
*/

#define TRUE            1
#define FALSE 			0
#define TRACE           0
#define TEXTSIZE        15
#define VSIZE           (TEXTSIZE*9)
#define HSIZE           (TEXTSIZE*8)
#define X_ORIGIN        0
#define X_LENGTH        3000 /* at 3200, not enough room for rightmost number */
#define Y_ORIGIN        VSIZE
#define RIM             100 /* tick-mark size */
#define Y_LENGTH        (2299 - VSIZE-RIM)
#define PICTOP          2299
#define FILL            TRUE
#define GRID            TRUE
#define BOX             FALSE /* Draw box surrounding legends */
#define NN              FALSE   /* indicate number of observations per column */
#define LEGEND          1   /* number of lines for legends */
#define LEGENDPOS		1   /* legends to the right of the graph */
#define XSIZE			150	/* horizontal size of legend block */
#define LOGFLAG         FALSE
#define PIXELS_PER_LINE     2
#define PLOTTER			1

#define X_LEGEND        "units/ml"
#define PRNFILE			"a:bar.prn"
#define PICFILE			"a:bar.pic"
#define SHOW			TRUE


#define INTRA       0.3 /* space between bars in % of bar */
#define INTER		1.5	/* space between ranges in % of bar */
#define CAP			0.30	/* length of cap on error-bar in % of bar */
#define SYMBOL_SIZE     40
#define LEGEND_SYMBOL_SIZE 40
#define SYMBOL_TYPE		0
#define LINE			TRUE	/* connect points */


#define S1 printf("Programma \"HBAR.EXE\" dd %s",__DATE__)
#define S2 printf("Inlichtingen en fouten-melding: Rob Aalberse")
#define M0 printf("\nNo filename entered; press RETURN to re-try\n")
#define M1 printf("\nOutput-file: \"%s\" ready for PRINTGRAPH or DRAWPIC!\n",picfile)
#define M1_GETFILE printf("No files in directory %s\ntry again ... \n\n",s)
#define M2_GETFILE printf("Enter directory search mask ( press Esc to exit):\n%s ",mask)
#define M3_GETFILE printf("Mask: %s. Select file and press RETURN (press Esc to exit)",s)
#define E0 printf("\ncannot open input file %s; press RETURN to re-try\n",prnfile)
#define E2 printf("\nNon-printable character \" %c \" (ASCII %d): wrong input-file \"%s\"?\nprogramm aborted\n",c,c,prnfile)
#define E3 printf("\nError writing file to disc: Disc full?")
#define E1_CHECK_OUTPUT_FILE(s) printf("\n\noutput file %s allready exists\nenter new name or press RETURN to overwrite\noutput-PIC-file :",s)
#define E_OPENIN printf("\ncannot open \"%s\" for input\n",s)
#define E_OPENOUT printf("\ncannot open \"%s\" for output\n",s)

#define DATA_COLUMNS	4
#define MAXNOOFCALIBRATORS  10

#define MISSING_CALIBRATOR -999
#define MARGIN      50
#define COLUMNS		256
#define HEADERLINES 40
#define MAX_LEN		81
#define OFF ' '
#define ON  '#'
#define GROUP 8
#define HLON  printf("\033[7m")		/* inverse video */
#define ULON  printf("\033[4m")		/* underline */
#define BLON  printf("\033[5m")		/* blink */
#define NORM  printf("\033[0m")
#define CLS   printf("\033[2J")
#define CURSOR(a,b) printf("\033[%d;%dH",a,b)
#define MORE CURSOR(25,70);HLON;printf(" MORE --> ");NORM;getch();CLS
#define QUOTE 34
#define MAKELOG(data) if (logflag) data=(long)(log((data)/1000.0) * 1000)
#define RANGES COLUMNS
#define LARGE 0
#define MEDIUM 1
#define SMALL  2
#define LINEAR 3
#define MISSING		-999999.000

#define LENFILENAME 12
#define SCREENSTARTROW 4
#define NOOFLINES (25-SCREENSTARTROW)
#define SCREENCOLUMNS 80
#define TEXTCOLUMNS 4
#define MAXFILES (TEXTCOLUMNS*NOOFLINES)

/* pic.h: header for pic-files 280288 */

#define MOVE 160
#define DRAW 162
/*
#define FILL 48
#define FILLO 208
*/
#define COLOR 1		/* number of colors */
#define COLOR0 176
#define TEXT 168
#define FONT 167
#define SIZE 172
#define END 0X60
#define CENTER 0
#define CENTERLEFT 1
#define CENTERTOP 2
#define CENTERRIGHT 3
#define CENTERBOTTOM 4
#define TOPLEFT 5
#define TOPRIGHT 6
#define BOTTOMLEFT 7
#define BOTTOMRIGHT 8

/* keyboard.h 230288 */
#define QUOTE 34
#define SPECIAL_KEY 0
#define UP 328
#define DOWN 336
#define HOME 327
#define SHIFT_HOME 382
#define LEFT 331
#define RIGHT 333
#define PgUp 329
#define PgDn 337
#define EXEC 335
#define ESC 27
#define CANCEL 366
#define INSERT 338
#define DELETE 339
#define F1 315
#define F2 316
#define F3 317
#define F4 318
#define F5 319
#define F6 320
#define F7 321
#define F8 322
#define F9 323
#define F10 324
#define HELP 367 /* F1 toets */
#define SPACE 32
#define RETURN 13
#define BACKSPACE 8
#define CR 13
#define TAB 9
#define BACKTAB 271
#define CTRL_A 1
#define CTRL_B 2
#define CTRL_C 3
#define CTRL_Z 26

#define W_SPECIAL_KEY 31
#define W_UP 192
#define W_DOWN 194
#define W_HOME 196
#define W_ENDKEY 199
#define W_LEFT 195
#define W_RIGHT 193
#define W_PgUp 200
#define W_PgDn 201
#define W_EXEC 197
#define W_ESC 224		/* = annuleer = laat vervallen = cancel */
#define W_ESC2 205		/* = backtab links boven */
#define W_INSERT 198
#define W_DELETE 199
#define W_F1 128
#define W_F2 129
#define W_F3 130
#define W_F4 131
#define W_F5 132
#define W_F6 133
#define W_F7 134
#define W_F8 135
#define W_F9 136
#define W_F10 137
#define W_HELP 225

#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <alloc.h>
#include <process.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <fcntl.h>
#include <dos.h>
#include <dir.h>

void startup_message(void);
void read_environment(void);
int get_options(void);
void make_ranges(void);
int picbottomline(int n);
void printstring(char c,int n);
void frame(int hor,int vert);
void down(char c,int n);
int strmenu(int current_pos, int rows, int startrow,int nooflines);
char *strleft(char *target,char *source, char *mask);
char *keycopy(char *target,char *source,int maxlen);
char *getmask(char *default_mask);
int getdir(char *s,char filename[][]);
void legend_menu(void);
void minmax_menu(void);
void position_menu(void);
void range_menu(void);
void makedate(int *m,int *d,int *y,unsigned total);
void maketime(int *h,int *m,int *s,unsigned total);
char *getfile(char *mask);
int read_data(char *filename);
void openin(char *filename);
void openout(char *filename);
int  fgetline(char *line,int maxlen, FILE *fpin);		/* returns no of non_white chars */
int parse_line(char *buffer, int dataline);
int numbers_per_line(char *buffer);
char *stripwhites(char *s);
void picopen(char *filename);
int check_output_file(char *new_name, char *default_name, char *ext);
int check_dosname(char *s);
void piccorner(void);
void dotted_v_line(int x0, int y0, int y1);
void picfont(char font);
void piccolor(int color);
void picsize(int x,int y);
void picxy(int x,int y);
void picmove(int x,int y);
void picdraw(int x,int y);
void pictext(int direction,int position,char *s);
void picdot(int x,int y, int type, int size);
void picgrid(void);
void picend(void);
void picheaders(int headerlines);

int pictopline(int n);
void piclegend(int legends_per_line);
void legend_menu(void);
void column_menu(void);
void extra_text_menu(void);
void picextra_text(int x_origin, int y_origin, int lx, int ly);
int getkey(int flag);
void farewell(int exit_code);




int picx_cal(int logflag);
void picxlegend(int n, int lines, char array[][MAX_LEN+1]);
int ascal(int *noofcalibrators, float *min, float *max, int logflag, int calcflag);
double scientific2(double d, double *base, int *exp);
int round(double d);
double val(double mantissa, int exponent);
double pow10d(double exponent);
int pictextlines(int xpos, int ypos, char *text, int direction, int position);
int count_char(char *s, char c);
void picfill(int type, int x0, int y0, int lx, int ly, int flag);

void write_bar(int x, int y, int x0, int y_unit, float cap);
int isvoid(char *s);
int isdelimiter(char c);
int isdecimal(char c);
int isnumber(char *s);
float set_env_variable(char *env_string, float default_value);
int picsave(char *source, char *target, char *ext);
/*
int select_ranges(int restore_flag);
*/
int strmenu2(int current_pos, int *selected_test, int rows, int startrow,int nooflines);
void write_screen(int startrow, int rows, int nooflines);
char *makefilename(char *full_filename, char *default_path, char *default_ext, int forced_ext_flag);
char *strnleft2(char *buffer, char *s1, char c, int n);
int strpos(char *s,char c,int pos);
int strpos2(char *s,char c,int pos);
int getmaxlegend(void);
int count_char(char *s, char c);
int get_bottomlines(void);
int get_legendlines(void);
int get_rangenamelines(void);
char *ftoa(float f);

FILE *fpin, *fpout, *tracefile;
char prnfile[80];
char outfile[80];
char picfile[]		="C:BAR.PIC";
char Input_path[80]	="A:";
char Output_path[80]	="A:";
char extra_text[10][MAX_LEN+1];
char symbolstring[20]="01234567";
float Xmax=MISSING, Xmin=MISSING, xmin, xmax;
int result=0, ranges, headerlines, bottomlines;
int data_columns, Data_columns=0;
double scale_factor;
float Cap=CAP, Intra=INTRA, Inter=INTER;
char header_vector[] = {1,0,0,0,1,0,8,0,68,0,0,0,0,12,127,9,6};
#ifdef TRACE
   int Trace;
#endif
int Show=SHOW, Legend=LEGEND, Legendpos=LEGENDPOS, Box=BOX, Fill=FILL, Grid=GRID, Nn=NN, Logflag=LOGFLAG;
int Symbol_size=SYMBOL_SIZE, Symbol_type=SYMBOL_TYPE, Line=LINE, Group=GROUP;
int Color=COLOR, Plotter=PLOTTER;
int YSIZE, DX, DY, Vsize, Hsize;
int Textsize, Smallprint;
int maxlegend, legendblocksize, y_unit;
int logflag, fill;
int x_origin, x_length, X_length;
int y_origin, y_length, Y_length;
int xpos, xpos0, xpos1, xpos2, xpos3;
int ypos, ypos0, ypos1, ypos2, ypos3;
int lines, testnamelines;
char filename[MAXFILES][LENFILENAME+1];
char testname[COLUMNS][MAX_LEN+1];
char flag[COLUMNS];
char range_name[RANGES+1][MAX_LEN+1];
int range_size[RANGES+1];
int range_start[RANGES+1];
int range_startpos[RANGES+1];
int rpos[RANGES+1];
float lower_limit[COLUMNS];
float central_value[COLUMNS];
float upper_limit[COLUMNS];
float extra_point[COLUMNS];



float data, lodata, hidata, exdata;
int result;
int maxrange;
unsigned columns;
char calibratorstring[MAXNOOFCALIBRATORS][16];
double value_of_calibrator[MAXNOOFCALIBRATORS];
int noofcalibrators=MAXNOOFCALIBRATORS;
char text[81], *textfragment;
int calbase[4][4]=   {1 , 0, 0, 0,
                      1 , 3, 0, 0,
                      1 , 2, 5, 0,
                      10,20,25,50
                     };
int exponent[MAXNOOFCALIBRATORS];
int startup_drive;
char y_legend[MAX_LEN];
char x_legend[MAX_LEN]="";
char headerline[HEADERLINES][MAX_LEN];
char first_title[MAX_LEN+1], second_title[MAX_LEN+1];
char stringline[HEADERLINES+1][MAX_LEN];	/* extra line: y-legend */
char buffer[MAX_LEN];
char startchars[MAXFILES];

/************************ START OF MAIN ************************/

int main(int argc, char* argv[]) {
   int r, n, dx, x0, bar;
   int column;
   int changes_made, pendown;
   float number_of_units;
   long prnlength;
   read_environment();
   if (Show) startup_message();
   Vsize=Textsize*9;
   Hsize=Textsize*8;
   YSIZE=0.9*Vsize;   /* vertical size of legend block */
   DY=0.4*YSIZE;
   DX=0.4*Hsize;
   setdisk(0);
#ifdef TRACE
   if (Trace) {
      if ((tracefile=fopen("C:trace","wt"))==0) {
         printf("cannot open \"C:trace\"");
         farewell(-1);
      } else printf("C:trace open\n");
   }
#endif
   do {
      if (argc>2) {
         if (*argv[2] != '-') strcpy(outfile,argv[2]);
         else strcpy(outfile,argv[2]+1);
      }
      if (argc==1 || (argc>1 && *argv[1]=='-')) {
          strcpy(prnfile,"A:*.prn");
          makefilename(prnfile,Input_path,".PRN",1);
          while (getfile(prnfile)==NULL) {
                CLS;
                M0;
                if (getch()!=CR) farewell(-1);
                CLS;
                strcpy(prnfile,"A:*.prn");
                makefilename(prnfile,Input_path,".PRN",1);
          }
      } else if (argc>1 && *argv[1]!='-') strcpy(prnfile,argv[1]);
      makefilename(prnfile, Input_path, ".PRN", 0);
      if (argc>1 && *argv[1]=='-') {
         strcpy(outfile,argv[1]+1);
         makefilename(outfile, Output_path, ".PIC",1);
      }
      if (! *outfile) {
         strcpy(outfile,prnfile);
         makefilename(outfile,Output_path,".PIC",1);
      }
      while ((fpin=fopen(prnfile,"rb")) == NULL) {
          CLS;
          E0;
          if (getch()!=CR) farewell(-1);
      }
     if ((prnlength=filelength(fileno(fpin)))==0) {
         clrscr();
         printf("Selected file is empty\n"
         "Possible cause: file not closed when printing to file\n"
         "e.g. Lotus-123 command sequence:\n"
         "Print File Range Go Quit\n"
         "Forgetting \"Quit\"  results in empty (non-closed) file\n\n"
         "Press Esc to quit program\n"
         "Any other key to select other file");
         if (getch()==ESC) farewell(-1);
      }
   } while (!prnlength);
   clrscr();
   printf("reading file %s\n",prnfile);
   columns=read_data(prnfile);
   if (*first_title) {
      strcpy(headerline[0], first_title);
      if (headerlines<1) headerlines=1;
   }
   if (*second_title) {
      strcpy(headerline[1], second_title);
      if (headerlines<2) headerlines=2;
   }
   if (Show) {
      for (r = 0, column=0;r < ranges; r++) {
         if (ranges>1) printf("\nrange %d: %s", r+1, range_name[r]);
         for (bar=0; bar<range_size[r]; bar++) {
            printf("\ncolumn %3d:%14s %9.2lf %9.2lf %9.2lf",
              column+1, testname[column], lower_limit[column], central_value[column], upper_limit[column]);
            if (extra_point[column]>MISSING) printf(" %9.2lf",extra_point[column]);
            column++;
         }
      }
   }
   make_ranges();
   setdisk(startup_drive);
   do {
      if (Legend<2 && ranges==1) {
         Legend=0;
         symbolstring[1]='\0';
      }
      fill=Fill;
/**** find min/max values for graph */
   
      xmin=-MISSING;
      xmax=MISSING;
      for (column=0;column<columns;column++) {
         if (xmin >lower_limit[column] ) xmin = lower_limit[column] ;
         if (xmax <upper_limit[column] ) xmax = upper_limit[column] ;
         if (Nn==-1) {
             if (extra_point[column] != MISSING && xmax < extra_point[column] ) xmax = extra_point[column] ;
             if (extra_point[column] != MISSING && xmin > extra_point[column] ) xmin = extra_point[column] ;
          }
#ifdef TRACE
         if (Trace) fprintf(tracefile, "\n%4d min=%8.2lf max=%8.2lf", __LINE__, xmin, xmax);
#endif
      }
      if (Xmax != MISSING) xmax= Xmax;
      if (Xmin != MISSING) xmin= Xmin;
      if (xmin <=0 ) Logflag=0;
      if (Xmin==MISSING && !Logflag && xmin>0) xmin=0;
      if ( Logflag && xmax / xmin <6) {
         xmin=sqrt(xmax * xmin)/2.5;
         xmax=xmin*6;
      }
      for (column=0;column<columns;column++) {
         if (lower_limit[column]<xmin) lower_limit[column]=MISSING;
         if (central_value[column]<xmin || central_value[column]>xmax) central_value[column]=MISSING;
         if (upper_limit[column]  <xmin || upper_limit[column]>xmax)   upper_limit[column]  =MISSING;
         if (Nn==-1 && (extra_point[column]<xmin || extra_point[column]>xmax)) extra_point[column]=MISSING;
      }

      if (!Legend && Intra<-1) Intra=.5;
#ifdef TRACE
      if (Trace) fprintf(tracefile, "\n%4d min=%8.2lf max=%8.2lf logflag=%d\n",
         __LINE__, xmin, xmax, Logflag);
#endif
      if (ranges>1) {
         maxlegend = getmaxlegend();
         legendblocksize = maxlegend * Hsize/2 + XSIZE+3*DX;
      } else maxlegend=legendblocksize=0;
      xpos0= 1;
      x_origin= X_LENGTH-X_length;
      x_length=X_length;
      if (Legendpos==1 && ranges>1) x_length-= legendblocksize+LEGEND_SYMBOL_SIZE;
      if (x_length<100) x_length=100;
      xpos3= x_origin+x_length;
#ifdef TRACE
         if (Trace) fprintf(tracefile,"\n%4d xpos0=%d xpos1=%d x_origin=%d xpos3=%d x_length=%d",
            __LINE__, xpos0, xpos1, x_origin, xpos3, x_length);
#endif
      ypos0= pictopline(headerlines)-40;
      ypos1= ypos0 - 1.2*VSIZE;
      ypos2= ypos1 - 1.2*VSIZE;
      bottomlines=get_bottomlines();
      y_origin = ypos3= picbottomline(bottomlines);
      if (ypos2-ypos3<100) y_origin = ypos3=ypos2-100;
      y_length= ypos2-y_origin-2*RIM;
#ifdef TRACE
         if (Trace) fprintf(tracefile,"\n%4d ypos0=%d ypos1=%d ypos2=%d ypos3=%d y_length=%d",
            __LINE__, ypos0, ypos1, ypos2, ypos3, y_length);
#endif

/************ write histogram to PIC-file ************/

#ifdef TRACE
      if (Trace) for (column=0;column<columns;column++) {
         fprintf(tracefile,"\n%2d %12.2f %12.2f %12.2f  ",
            column,
            lower_limit[column],
            central_value[column],
            upper_limit[column]
        );
      }
#endif
      picopen(picfile);
      for (n=0;n<Plotter;n++){

         picmove(x_origin,ypos2);
         picdraw(x_origin,ypos3);
         picmove(xpos3,ypos2);
         picdraw(xpos3,ypos3);
         picmove(x_origin,ypos2);
         picdraw(x_origin-RIM/2,ypos2);
         picmove(x_origin,ypos3);
         picdraw(x_origin-RIM/2,ypos3);
      }
      logflag= picx_cal(Logflag);
      number_of_units=(float)(columns + (columns-1) * Intra + (ranges-1)*Inter);
      y_unit=(number_of_units>0)?y_length/number_of_units:y_length;
      x0=(xmin <= 0) ? x_origin - xmin * scale_factor: x_origin;
      picextra_text(x_origin, y_origin, x_length, y_length);
      for (n=0;n<Plotter;n++) picheaders(headerlines);
      ypos=ypos2 -y_unit -RIM;
      column=0;
     for (r = 0;r < ranges; r++) {
         range_startpos[r]=ypos;
         for (bar=0; bar<range_size[r]; bar++) {
            if (central_value[column]==MISSING) lodata=data=hidata=exdata=MISSING;
            else {
               if (logflag) {
                  lodata=(lower_limit[column]  >0)?log(lower_limit[column])  :MISSING;
                  data =(central_value[column]>0)?log(central_value[column]):MISSING;
                  hidata =(upper_limit[column]  >0)?log(upper_limit[column])  :MISSING;
                  if (Nn==-1) exdata =(extra_point[column]  >0)?log(extra_point[column])  :MISSING;
                  else exdata=extra_point[column];
               } else {
                  lodata= lower_limit[column];
                  data=   central_value[column];
                  hidata= upper_limit[column];
                  exdata= extra_point[column];
               }
               if (Color) piccolor(bar);
               if (ranges==1) {
                  for (n=0;n<Plotter;n++){
                     picmove(x_origin-40,ypos+y_unit/2);
                     pictext(0, CENTERRIGHT, testname[bar]);
                  }
               }
               for (n=0;n<Plotter;n++) write_bar(x_origin,ypos,x0,y_unit,Cap);
               if (Nn==-1 && Symbol_size >0) picdot(x_origin + scale_factor*(exdata-xmin), ypos+y_unit/2, Symbol_type, Symbol_size);
               xpos=( x0 > x_origin) ? x0 : x_origin;
               if (fill) picfill(bar, xpos, ypos, (int)(( data - xmin ) * scale_factor - (x0-x_origin)) ,y_unit, FALSE);
#ifdef TRACE                                             
               if (Trace) fprintf(tracefile,"\n %4d picfill: bar %d ypos=%d xpos=%d y_unit=%d value=%d",
                 __LINE__, bar, ypos, xpos, y_unit, (int)(( data  - xmin ) * scale_factor - (x0-y_origin)));
#endif
               if (Nn==1) { /**** print N next to each bar ****/
                  for (n=0;n<Plotter;n++){
                     sprintf(buffer,"%d",(int)exdata);
                     if (data!=MISSING) {
                        dx=data>=0?(hidata-xmin)* scale_factor + 64:
                                   (lodata-xmin)* scale_factor-Hsize;
                        picmove(x_origin + dx, ypos+y_unit/2);
                        pictext(0, CENTERLEFT, buffer);
                     }
                  }                            
               }
            }
            ypos -= y_unit + y_unit * Intra;
            column++;
         }
         ypos -= y_unit * Inter;
      }
      ypos += y_unit + y_unit * ( Intra + Inter);
    
   /************ draw base line *****************/
      if (Color) piccolor(0);
      for (n=0;n<Plotter;n++) {
         picmove(x0, ypos2 -RIM);
         picdraw(x0, ypos);
      }
      if (ranges>1) {
         for (n=0; n<Plotter; n++){
            for (r= 0; r< ranges-1; r++) {
               ypos= range_startpos[r] - y_unit*Intra*(range_size[r]-1) - y_unit*(range_size[r]-1) - y_unit*(Inter+Intra)/2;
               picmove(x_origin, ypos);     
               picdraw(x_origin-RIM/2, ypos);
            }
         }
      }
   /************ draw line though extra_points ****************/

      if (Nn==-1 && Symbol_size >=0 && Line) {
         for (n=0;n<Plotter;n++){
            column=0;
            for (r = 0;r < ranges; r++) {
               ypos=range_startpos[r]+y_unit/2;
               for (bar=0, pendown=0; bar<range_size[r]; bar++) {
                  if (central_value[column]==MISSING) exdata=MISSING;
                  else {
                     if (logflag) {exdata =(extra_point[column]  >0)?log(extra_point[column])  :MISSING;
                     } else exdata= extra_point[column];
                  }
                  if (exdata!=MISSING) {
                     if (!pendown) {
                        picmove(x_origin + scale_factor*(exdata-xmin), ypos);
                        pendown=TRUE;
                     } else picdraw(x_origin + scale_factor*(exdata-xmin), ypos);
                  }
                  ypos -= y_unit + y_unit * Intra;
                  column++;
               }
               ypos -= y_unit * Inter;
            }
         }
      }
      if (Grid) picgrid();

   /************ print range_names **************/
      if (ranges>1) {
         if (Smallprint) {
           Vsize/=2;
           Hsize/=2;
           picsize(Hsize,Vsize);
         }
         for (r=0;r<ranges;r++) range_startpos[r] -= y_unit * (float)( range_size[r] + (range_size[r] - 1) * Intra)/2 - y_unit;
         for (r=0;r<ranges;r++){
              ypos=range_startpos[r];
              picmove(x_origin-40,ypos);
              pictext(0, CENTERRIGHT, range_name[r]);
         }

         if (Smallprint) {
            Vsize*=2;
            Hsize*=2;
            picsize(Hsize,Vsize);
         }
      }
      if (Legend) for (n=0;n<Plotter;n++) piclegend( Legend);
      fputc(END,fpout);
      if (fclose(fpout)==EOF) {
        E3;
        farewell(-1);
      }
      if (Show) {
         if (spawnlp(P_WAIT,"drawpic.exe","drawpic.exe",picfile,NULL)==-1) {
            printf("\nspawn-error\n");
            farewell(-1);
         }
         changes_made=get_options();
      } else changes_made=0;
      if (changes_made== -1) farewell(0);
      if (changes_made== 0) {
         changes_made=picsave(picfile, outfile, ".PIC");
         if (changes_made) if(get_options()==-1) farewell(0);
      }
   } while (changes_made>0 && Show);
   farewell(0);
   return 1;
}
   
   /****************************************************************
   *								*
   *			END OF MAIN()				*
   *								*
   ****************************************************************/
   
void farewell(int exit_code) {
   setdisk(startup_drive);
   exit(exit_code);
}

int check_dosname(char *s) {
char c;
int i, namestart=0, extlen, len, dotpos=0;
   if (strpos2(s,'?',0) !=-1) return 0;
   if (strpos2(s,'*',0) !=-1) return 0;
   if (strpos2(s,'/',0) !=-1) return 0;
   if (s[1]==':' && (c=toupper(*s))>'@' && c<'F') namestart=2;
   if (strpos2(s,':',namestart) !=-1) return 0;
   if (strlen(s)-namestart>1 && strpos2(s,' ',namestart+1) !=-1) return 0;
   do {
      i=strpos2(s, '\\', namestart)+1;
      if (i) namestart=i;
   } while (i);
   i=strpos2(s,'.',namestart);
   if (i>-1) {
      dotpos=++i;
      if (i<strlen(s) && strpos2(s,'.',i)!=-1) {
         return 0;
      }
      extlen=strlen(s)-dotpos+1;
      if (extlen<2 || extlen>4) return 0;
   } else extlen=0;
   if ((len=strlen(s)-extlen-namestart)>8) return 0;
   return len;
}

int strpos2(char *s,char c,int pos) {
/* finds occurrence of c in s starting at pos */
int p;
     if (pos>strlen(s)) printf("\nerror: position %d in \"%s\" not found\n", pos, s);
     for (p=pos;s[p];p++) if (s[p]==c) return p;
     return -1;
}

int get_options(void) {
int n, option, changes=0;
float f;
   for (;;) {
      do {
         CLS;
         printf("0 - log-transformation: %s\n",(Logflag?"yes":"no"));
         printf("1 - first title: \"%s\"\n",  first_title);
         printf("2 - second title: \"%s\"\n", second_title);
         printf("3 - x-axis title: \"%s\"\n", x_legend);
/*
         printf("4 - y-axis title: \"%s\"\n", y_legend);
         printf("5 - number of data_columns: %d\n",data_columns);
*/
         printf("6 - cap on error-lines: %.2f\n", Cap);
         if (data_columns>3 && Nn==1)      printf("8 - first data-column: number of samples rather than extra point\n");
         else if (data_columns>3 && Nn==-1)       printf("8 - first data-column: extra point rather than number of samples\n");
         if (data_columns>3 && Nn==-1) printf("9 - lines connecting extra points: %s\n", (Line?"yes":"no"));
         printf( "\nC - %s\n", Color?"4-COLOR":"BLACK & WHITE");
         printf(   "F - modify Fill-types\n");
         printf(   "G - Grid-lines: currently %s\n",Grid?"ON":"OFF");
         if (ranges>1) printf("I - Intra-range %.2f; Inter-range: %.2f\n", Intra, Inter);
         else printf("I - Distance between bars (in bar-units) %.2f\n", Intra);
         printf(   "L - modify text of Legends\n");
         printf(   "M - MinMax: Xmin=%.2f Xmax=%.2lf\n",Xmin,Xmax);
         if (data_columns>3 && Nn!=-1)
            printf("N - number of samples printed in figure: %s\n",Nn==1?"YES":"NO");
         printf(   "P - modify Position of legends\n");
/*
         printf(   "R - modify division of columns into Ranges\n");
*/
         printf(   "T - change Text-size (default: %i)\n", Textsize);
         printf(   "X - modify length of X-axis\n");
         printf(   "Y - modify length of Y-axis\n");
         printf( "\nRETURN = accept options\n"
                  "Escape = quit\n"
                  "Select option:  \n");
         if ((option=getkey(0))==RETURN || option==EXEC) return changes;
         if (option==ESC || option==CANCEL)             return -1;
      } while (strpos("CFGILMNPTXY01236789",option,0)==-1);
      changes++;
      switch (option) {
         case 'C':
            Color=(Color)?0:3;
            break;
         case 'F':
            clrscr();
            printf("fill codes:\n"
                   "0  \/  \/\n"
                   "1  \\  \\\n"
                   "2  0+1\n"
                   "3  blank\n"
                   "4  filled\n"
                   "5  \/\/\/\n"
                   "6  \\\\\\\n"
                   "7  2+5\n\n");
            printf("\nsymbol-codes used \"%s\": ",symbolstring);
            keycopy(buffer, symbolstring, 19);
            strcpy(symbolstring, buffer);
            break;
         case 'G':
            Grid=(Grid)?0:1;
            break;
         case 'I':
         case '7':
            CLS;
            printf("\nIntra-range distance  (-1.00 / +5.00, default=%.2f)",Intra);
            gets(buffer);
            if (*buffer) {
               f=atof(buffer);
               if (f>=-1.0 && f<=5.0) Intra=f;
            }
            if (ranges>1) {
               printf("\nInter-range distance  (0.00 / +5.00, default=%.2f)",Inter);
               gets(buffer);
               if (*buffer) {
                  f=atof(buffer);
                  if (f>=0.0 && f<=5.0) Inter=f;
               }
            }
            break;
         case 'L':
            legend_menu();
            break;
         case 'M':
            minmax_menu();
            break;
         case 'N':
            Nn=(Nn)?0:1;
            break;
         case 'P':
            position_menu();
            break;
/*
         case 'R':
            ranges = select_ranges(FALSE);
            range_menu();
            break;
*/
         case 'T':
            clrscr();
            printf("Text-size: (max=%d,default=%d)", 3*TEXTSIZE, Textsize);
            gets(buffer);
            n=atoi(buffer);
            if (n>0 && n<=3*TEXTSIZE) {
               Textsize=n;
               Vsize=Textsize*9;
               Hsize=Textsize*8;
               YSIZE=0.9*Vsize;   /* vertical size of legend block */
               DY=0.4*YSIZE;
               DX=0.4*Hsize;
            }
            break;
         case 'X':
            printf("\nLength of x-axis (max=%d,default=%d)", X_LENGTH-100, X_length);
            gets(buffer);
            n=atoi(buffer);
            if (n>1 && n<=X_LENGTH-100) X_length=n;
            break;
         case 'Y':
            printf("\nLength of y-axis (max=%d,default=%d)",PICTOP, Y_length);
            gets(buffer);
            n=atoi(buffer);
            if (n>1 && n<=PICTOP) Y_length=n;
            break;
         case '0':
            Logflag=(Logflag)?0:1;
            break;
         case '1':
            CLS;
            printf("First title \"%s\": ",first_title);
            strcpy(first_title,keycopy(buffer, first_title, MAX_LEN));
            break;
         case '2':
            CLS;
            printf("\nSecond title \"%s\": ",second_title);
            strcpy(second_title,keycopy(buffer, second_title, MAX_LEN));
            break;
         case '3':
            CLS;
            printf("\nLegend x-axis \"%s\": ",x_legend);
            strcpy(x_legend, keycopy(buffer, x_legend, MAX_LEN));
            break;
         case '4':
            CLS;
            printf("\nLegend y-axis \"%s\": ",y_legend);
            strcpy(y_legend, keycopy(buffer, y_legend, MAX_LEN));
            break;
         case '5':
            CLS;
            printf("\nnumber of datacolumns (max=%d,default=%d)",DATA_COLUMNS, data_columns);
            gets(buffer);
            if (*buffer) {
               n=atoi(buffer);
               if (n>1 && n<=DATA_COLUMNS) Data_columns=n;
            }
            data_columns=Data_columns;
            break;
         case '6':
            CLS;
            printf("\n0        = no cap on error-bar in bar_graph picture\n"
                     "0 - 2.00 = length of cap-line (default:%.2f): ",Cap);
            gets(buffer);
            if (*buffer) Cap=atof(buffer);
            if (Cap>2) Cap/=100;
            if (Cap>2) Cap=CAP;
            break;
         case '8':
            Nn=(Nn==1) ? -1: 1;
            break;
         case '9':
            Line=(Line)? 0: 1;
            break;
      }
   }
}

void minmax_menu(void) {
   CLS;
   printf("M - MinMax: ");
   printf("Xmin=%s ",(Xmin==MISSING)?"AUTO":ftoa(Xmin));
   printf("Xmax=%s\n\n",(Xmax==MISSING)?"AUTO":ftoa(Xmax));
   printf("'?' = AUTOMATIC\n\n");
   printf("\nXmin=lowest value y-axis (%s) ",(Xmin==MISSING)?"AUTO":ftoa(Xmin));
   gets(buffer);
   if (*buffer=='?' || *buffer=='/' || *buffer=='A' || *buffer=='a') Xmin=MISSING;
   else if (*buffer) Xmin=atof(buffer);
   printf("\nXmax=highest value y-axis (%s) ",(Xmax==MISSING)?"AUTO":ftoa(Xmax));
   gets(buffer);
   if (*buffer=='?' || *buffer=='/' || *buffer=='A' || *buffer=='a') Xmax=MISSING;
   else if (*buffer) Xmax=atof(buffer);
}

void legend_menu(void) {
   int option;
   CLS;
   printf("0 - Show/modify legends of columns\n");
   printf("1 - Show/modify legends of ranges\n");
   printf("2 - Show/modify extra text\n");
   printf("\n\nEscape or RETURN = previous menu\n"
              "Choose 0 - 2:  \n");
   option=getkey(0);
   switch (option) {
      case '0':
         column_menu();
         break;
      case '1':
         range_menu();
         break;
      case '2':
         extra_text_menu();
         break;
   }
}

void column_menu() {
   int t;
   for (;;) {
      CLS;
      for (t=0; t<maxrange && t<columns; t++) {
         printf("\n%2d=%-16s",t+1,testname[t]);
      }
      printf("\n\nRETURN = accept\nModify which legend (1-%d) : ",maxrange);
      do {
         gets(buffer);
         t=atoi(buffer)-1;
      } while (*buffer && (t<0 || t>=columns));
      if (*buffer=='\0') break;
      printf("\n%s: ",testname[t]);
      keycopy(buffer,testname[t],MAX_LEN);
      strcpy(testname[t],buffer);
   }
}

void range_menu(void) {
   int t, response;
   for (;;) {
      CLS;
      ULON;
      printf("Current range-names:\n\n");
      NORM;
      for (t=0;t<ranges;t++) printf("\n%d=%-16s",t+1,range_name[t]);
      printf("\n\nRETURN = accept\nModify which legend (1-%d) : ",ranges);
      do {
         response=getkey(0);
         if (response==ESC || response==CANCEL) return;
         t=response-'1';
      } while (response!=RETURN && (t<0 || t>=ranges));
      if (response==RETURN) break;
      printf("%c\n%s: ",response,range_name[t]);
      keycopy(buffer,range_name[t],MAX_LEN);
      if (isvoid(buffer)) range_name[t][0]='\0';
      else strcpy(range_name[t],buffer);
   }
}

void position_menu(void) {
   int r;
   CLS;
   printf("Legend at the indicated position (%d):\n\n"
               "3\n"
               "  %c%c%c%c%c%c%c\n"
               "  %c    2%c1\n"
               "  %c     %c\n"
               "  %c     %c\n"
               "  %c%c%c%c%c%c%c\n"
               "  0\n\n",Legendpos,218,196,196,196,196,196,191,
                                 179,179,179,179,179,179,
                                 192,196,196,196,196,196,217);
   r=getkey(0);
   if (r>='0' && r<'4') Legendpos=r-'0';
   if (Legendpos==0 && Legend>=0) {
      printf("\n\nLegends printed over %d column(s) ",Legend);
      r=getkey(0);
      if (r>='0' && r<'9') Legend=r-'0';
   }
}


void make_ranges(void) {
   int r, column=0;
   maxrange=range_size[0];
   for (r=1; r<ranges; r++) {
     range_start[r] = range_start[r-1] + range_size[r-1];
     column += range_size[r-1];
     if (maxrange<range_size[r]) maxrange=range_size[r];
   }
   if (column<columns) range_size[ranges-1]= columns-column;
}

void extra_text_menu() {
   int t, response;
   char buffer[MAX_LEN+1];
   for (;;) {
      CLS;
      printf("\Extra text at the indicated positions:\n\n"
               "0         1\n"
               "  2  3  4\n\n"
               "  5  6  7\n"
               "8         9\n\n");
      for (t=0;t<10;t++) if (extra_text[t][0]) printf("\nextra text %d: %s",t,extra_text[t]);
      printf("\n\nRETURN = accept\nModify/add which text (0 - 9) : ");
      do {
         response=getkey(0);
         t=response-'0';
      } while (response!=RETURN && (t<0 || t>9));
      if (response==RETURN) break;
      printf("%c\n%s: ",response,extra_text[t]);
      keycopy(buffer,extra_text[t],MAX_LEN);
      if (isvoid(buffer)) extra_text[t][0]='\0';
      else strcpy(extra_text[t],buffer);
   }
#ifdef TRACE
   if (Trace) {
      fprintf(tracefile,"%4d extra text:\n",__LINE__);
      for (t=0;t<10;t++) fprintf(tracefile,"\n%d \"%s\"",t,extra_text[t]);
   }
#endif
}

int isvoid(char *s) {
   int i;
   for (i=0;s[i];i++) if (!isspace(s[i])) return 0;
   return 1;
}

void picextra_text(int x_origin, int y_origin, int lx, int ly) {
   int i, x, y, position;
   for (i=0; i<10; i++) {
      if (extra_text[i][0]) {
         switch (i) {
            case 0:
               position=TOPLEFT;
               x=X_ORIGIN;
               y=Y_length;
               break;
            case 1:
               position=TOPRIGHT;
               x=X_ORIGIN+X_length;
               y=Y_length;
               break;
            case 2:
               position=TOPLEFT;
               x=x_origin+12;
               y=y_origin+ly-12;
               break;
            case 3:
               position=CENTERTOP;
               x=x_origin + lx/2;
               y=y_origin+ly-12;
               break;
            case 4:
               position=TOPRIGHT;
               x=x_origin+lx-12;
               y=y_origin+ly-12;
               break;
            case 5:
               position=BOTTOMLEFT;
               x=x_origin+12;
               y=y_origin+12;
               break;
            case 6:
               position=CENTERBOTTOM;
               x=x_origin + lx/2;
               y=y_origin+12;
               break;
            case 7:
               position=BOTTOMRIGHT;
               x=x_origin+lx-12;
               y=y_origin+12;
               break;
            case 8:
               position=BOTTOMLEFT;
               x=X_ORIGIN;
               y=picbottomline(1);
               break;
            case 9:
               position=BOTTOMRIGHT;
               x=X_length;
               y=Y_ORIGIN;
               break;
         }
         picmove(x,y);
         pictext(0,position, extra_text[i]);
      }
   }
}

int getkey(int flag) {
int c;
   result=1;
   c=getch();
   if (c==SPECIAL_KEY) {
      c=256+getch();
      if (c>F5 && c<=F10) return c;
   } else {
      if (c==ESC) result=0;
      if (c==CTRL_C) farewell(-1);
      if (!flag) c=toupper(c);
   }
   return c;
}

int read_data(char *f) {
   int non_whites, line=0, column=0, n, r, maxlen=MAX_LEN;
   int rangeline, dataline=-1;
   int stringlines=0;
   ranges=0;
   headerlines=0;
   for (r=0;r<RANGES;r++) range_size[r]=0;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n\n%4d ++++++++++ reading from %s +++++++++++\n",__LINE__, f);
#endif
   openin(f);
   do {
      line ++;
      if ((non_whites=fgetline(buffer,maxlen,fpin))<1) continue;
      data_columns=parse_line(buffer, column);
      if (data_columns>0) {
         if (stringlines && dataline==-1) ranges=1;
         if (ranges) range_size[ranges-1]++;
         dataline=1;
         column++;
      }
      if (column>=COLUMNS) break;
      if (data_columns==0 && stringlines<HEADERLINES+1 && *buffer!='\0') {
         strcpy(stringline[stringlines],buffer);
         if (dataline==-1) headerlines++;
         if (dataline) stringlines++;
         if (dataline > 0) {
            dataline=0;
            range_size[ranges]=0;
            range_start[ranges]=column;
            ranges++;
         }
      }
      if (ranges>=RANGES){
         ranges=RANGES;
         break;
      }
      if (stringlines>=HEADERLINES+1){
         stringlines=HEADERLINES+1;
         headerlines--;
         break;
      }
   } while (non_whites!=EOF && column<COLUMNS && ranges<RANGES && stringlines<HEADERLINES+1);
   fclose(fpin);
   if (ranges>1) headerlines--;
   rangeline=headerlines;
   for (n=0;n<stringlines;n++) {
#ifdef TRACE
      if (Trace) fprintf(tracefile,"\n%4d stringline %d: \"%s\"",
         __LINE__,n,stringline[n]);
#endif
      stripwhites(stringline[n]);
   }
   if (headerlines) {
      headerlines --;
      if (!*x_legend) strcpy(x_legend,stringline[headerlines]);
   } else if (!*x_legend) strcpy(x_legend,X_LEGEND);
   if (ranges>1) for (r=0,n=rangeline;n<stringlines;r++,n++)  if (!*range_name[r]) strcpy(range_name[r],stringline[n]);
   if (headerlines) for (n=0;n<headerlines;n++) {
      strcpy(headerline[n],stringline[n]);
      if (n==0) if (!*first_title) strcpy (first_title,headerline[0]);
      if (n==1) if (!*second_title) strcpy (second_title,headerline[1]);
   }
#ifdef TRACE
   if (Trace) {
      for (n=0;n<stringlines;n++) fprintf(tracefile,"\n%4d line %d: \"%s\"",
      __LINE__,n,stringline[n]);
      for (n=0;n<column;     n++) fprintf(tracefile,"\n%4d column %4d: \"%-12s\"  %9.2lf %9.2lf %9.2lf",
            __LINE__, n, testname[n], lower_limit[n], central_value[n], upper_limit[n]); 
   }
#endif
   return column;
}

int parse_line(char *buffer, int dataline) {
   int data_columns=-1, textstring=0, digits=0, pos, pos1, pos2, p, n;
   char value[20];
   float digit[DATA_COLUMNS], tempdigit;
   char c;
   digits=0;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n\n%4d line to parse: %s",__LINE__, buffer);
#endif
   if (!Data_columns) {
      data_columns=numbers_per_line(buffer);
      if (data_columns>3 && *buffer!=QUOTE) data_columns=3;		/* extra_point/Nn must be SET by DATA_COLUMNS=4 */
   }
   else data_columns=Data_columns;
   if (data_columns>3 && *buffer==QUOTE) Nn=TRUE;
   if (data_columns>DATA_COLUMNS) data_columns=DATA_COLUMNS;
   if (!data_columns) return 0;
   for (n=data_columns-1,pos2=strlen(buffer)-1;n>=0 && !textstring;n--) {
      do {
         *value='\0';
         c=buffer[pos2];
         if ( !(isdelimiter(c) || isdigit(c))) textstring=TRUE;
         if (isdelimiter(c) ) pos2--;
      } while (!(textstring) && isspace(c) && pos2>-1 );
      if (textstring) return 0;
      pos1=pos2;
      while (pos1>0 && isdecimal(c=buffer[pos1])) pos1--;
      if (isdelimiter(c) || pos1==0) {
         digits ++;
         for (pos=pos1;!isdecimal(buffer[pos]) && pos<pos2+1;pos++)
            ;
         for (p=0;pos<pos2+1;p++,pos++)
            if (p<20) value[p]=buffer[pos];
            else {
               printf("\nERROR in line %s: number too long: %p\n",
                  buffer,p);
               farewell(-1);
            }
         value[p]='\0';
         if (!(isnumber(value))) textstring=TRUE;
         else digit[data_columns-digits]= (float)atof(value);
      } else textstring=TRUE;
      pos2=pos1;
      if (textstring) return 0;
   }
   if (data_columns<1) return 0;
   if (pos1>0) {
      strncpy(testname[dataline],buffer,pos1);
      if (*testname[dataline]) stripwhites(testname[dataline]);
#ifdef TRACE
      if (Trace) fprintf(tracefile,"\n%4d %s: testname[%d]=\"%s\"",
         __LINE__, __FILE__, dataline, testname[dataline]);
#endif
   }
   switch(data_columns) {
      case 1:
         lower_limit[dataline]    =digit[0];
         central_value[dataline]  =digit[0];
         upper_limit[dataline]    =digit[0];
         extra_point[dataline]    =MISSING;
         Symbol_size=-1;
         break;
      case 2:
         lower_limit[dataline]    =digit[0]-digit[1];
         central_value[dataline]  =digit[0];
         upper_limit[dataline]    =digit[0]+digit[1];
         extra_point[dataline]    =MISSING;
         Symbol_size=-1;
         break;
      case 3:
         if (digit[0]>digit[2]) {
            tempdigit=digit[0];
            digit[0]=digit[2];
            digit[2]=tempdigit;
         }
         lower_limit[dataline]    =digit[0];
         central_value[dataline]  =digit[1];
         upper_limit[dataline]    =digit[2];
         extra_point[dataline]    =MISSING;
         Symbol_size=-1;
         break;
      case 4:
         if (digit[1]>digit[3]) {
            tempdigit=digit[1];
            digit[1]=digit[3];
            digit[3]=tempdigit;
         }
         extra_point[dataline]    =digit[0];
         lower_limit[dataline]    =digit[1];
         central_value[dataline]  =digit[2];
         upper_limit[dataline]    =digit[3];
         break;
      default:
         Symbol_size=-1;
         return 0;
   }
   return data_columns;
}

int numbers_per_line(char *s) {
   int p, pos=0, len, n=0;
   char number[81];
   len=strlen(s);
   do {
      while (isdelimiter(s[pos]) && pos < len) pos++;
      if (pos >= strlen(s)) break;
      p=0;
      while (!isdelimiter(s[pos]) && pos<strlen(s)) number[p++]=s[pos++];
      number[p]='\0';
#ifdef TRACE
      if (Trace) fprintf(tracefile,"\n%4d isnumber(\"%s\")=%d",__LINE__,number,isnumber(number));
#endif
      if (isnumber(number)) n++;
      else n=0;
    } while (pos<strlen(s));
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d %d numbers found",__LINE__,n);
#endif
   return n;
}

int isdecimal(char c) {
   if (isdigit(c) ||
       c=='.'     ||
       c=='+'     ||
       c=='-') return 1;
   else return 0;
}

int isdelimiter(char c) {
   return (isspace(c) || c==',' || c==';');
}

int isnumber(char *s) {
int n, len=strlen(s);
   if (!len)                                        return 0;
   for (n=0; n<len ; n++)
      if (!(isdecimal(s[n])))                       return 0;
   if (s[len]=='.')                                 return 0;
   for (n=1;n<len;n++) if (s[n]=='+' || s[n]=='-')  return 0;
   for (n=0;n<len-1;n++) if (s[n]=='.')  
      for (n++;n<len-1;n++) if (s[n]=='.')          return 0;
   return 1;
}

char *stripwhites(char *s) {
   int p, len;
   char *s2;
   s2=s;
   for (p=0;isspace(s[p]) && p<strlen(s);s2++)
      ;
   for (p=strlen(s2)-1;isspace(s2[p]) && p;p--) s2[p]='\0';
   if (*s2==QUOTE){
      s2++;
      len=strlen(s2);
      if (s2[len-1]==QUOTE) s2[len-1]='\0';
   }
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d stripwhites \"%s\"=\"%s\"",__LINE__,s,s2);
#endif
   strcpy(s,s2);
   return s;
}

int fgetline(char *s,int i,FILE *fpin) {
   char c;
   int skip=FALSE, pos=0, non_whites=0;
   while((c=fgetc(fpin))!=EOF && c!='\r' && c!='\n' && pos<i ) {
      if (c==26) {
         c=EOF;
         break;
      }
      if (non_whites==0 && c=='\\') skip=TRUE;
      if (c!=' ' && c!='\t') {
         if (!isprint(c)) {
            E2;
            farewell(-1);
         }
         non_whites ++;
         s[pos]=c;
         pos++;
      } else if (pos) {
         s[pos]=c;
         pos++;
      }
   }
   while((c=fgetc(fpin))!=EOF && (c=='\r' || c=='\n'))
      ;
   ungetc(c,fpin);
   s[pos]='\0';
   if (non_whites==0 && c==EOF) return EOF;
   if (skip) return 0;
   else return non_whites;
}

void picdot(int x,int y, int type, int size) {
   int dx,dy,r=size/2, t;
   t=symbolstring[type%strlen(symbolstring)]-'0';
   switch(t) {
      case 0:
	 for (dy=r; dy > -r; dy -= PIXELS_PER_LINE) {
 	    dx = sqrt((long)r*r-(long)dy*dy);
   	    picmove(x-dx,y+dy);
   	    picdraw(x+dx,y+dy);
   	 }
   	 break;
      case 1:
         picmove(x,y+r);
	 for (dy=r; dy > -r; dy -= PIXELS_PER_LINE) {
 	    dx = sqrt((long)r*r-(long)dy*dy);
   	    picdraw(x+dx,y+dy);
   	 }
	 for ( ; dy <= r; dy += PIXELS_PER_LINE) {
 	    dx = sqrt((long)r*r-(long)dy*dy);
   	    picdraw(x-dx,y+dy);
   	 }
   	 break;
      case 2:						/* filled square */
	 for (dy=r; dy > -r; dy -= PIXELS_PER_LINE) {
   	    picmove(x-r,y+dy);
   	    picdraw(x+r,y+dy);
   	 }
   	 break;
      case 3:
         picmove(x-r,y+r);
   	 picdraw(x+r,y+r);
   	 picdraw(x+r,y-r);
   	 picdraw(x-r,y-r);
   	 picdraw(x-r,y+r);
   	 break;
      case 4:						/* triangle */
	 for (dx=0,dy=r; dx < r ; dx += PIXELS_PER_LINE/2, dy -= PIXELS_PER_LINE) {
   	    picmove(x-dx,y+dy);
   	    picdraw(x+dx,y+dy);
   	 }
   	 break;
      case 5:
         picmove(x  ,y+r);
   	 picdraw(x-r,y-r/2);
   	 picdraw(x+r,y-r/2);
   	 picdraw(x  ,y+r);
   	 break;
      case 6:					/* upside_down triangle */
	 for (dx=0,dy=-r; dx < r ; dx += PIXELS_PER_LINE/2, dy += PIXELS_PER_LINE) {
   	    picmove(x-dx,y+dy);
   	    picdraw(x+dx,y+dy);
   	 }
   	 break;
      case 7:
         picmove(x-r,y+r);
   	 picdraw(x+r,y+r);
   	 picdraw(x  ,y-r/2);
   	 picdraw(x-r,y+r);
   	 break;
      }
}

int picbottomline(int n) {
   return(Y_ORIGIN+n*Vsize);
}

int pictopline(int n) {
    return Y_length-n*Vsize;
}

void write_bar(
   int x,			/* lower left of graph */
   int y,			/* lower left of graph */
   int x0,          /* 0-value on axis */
   int y_unit,      /* column width */
   float cap)       /* bar width as fraction of column width */
{
   int dx, base, top;

/* draw mean/median bar in graph: */

   base = (x0>x) ? x0 : x;
   top  = (data-xmin)*scale_factor + x;
   picmove(base, y);
   picdraw(top, y);
   picdraw(top, y+ y_unit);
   picdraw(base, y+ y_unit);
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d central value: base=%d top=%d",__LINE__,base, top);
#endif

/* draw upper deviation line (MEAN+SD, MEAN+SEM or 75-percentile) in graph: */

   dx = (hidata!=MISSING)?(hidata-xmin)*scale_factor + x:xmax+x;
   if (hidata!=MISSING) {
      picmove(dx, y+ y_unit*(1-cap)/2);
      picdraw(dx, y+ y_unit*(1+cap)/2);
   }
   picmove(dx, y+ y_unit/2);
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d upper_deviation = %d", __LINE__, dx);
#endif

/* draw lower deviation line (MEAN-SD, MEAN-SEM or 25-percentile) in graph: */

   dx = (lodata!=MISSING)?(lodata-xmin)*scale_factor + x: x;
   picdraw(dx, y+ y_unit/2);
   if (lodata!=MISSING) {
      picmove(dx, y+ y_unit*(1-cap)/2);
      picdraw(dx, y+ y_unit*(1+cap)/2);
   }
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d lower_deviation = %d",__LINE__, dx);
#endif
}

void picgrid(void) {
   int column, bar, n, r, xpos, yposstart, yposend, cal;
   double calibrator_value;
   for (n=0;n<Plotter;n++){
      for (cal=0; cal<noofcalibrators; cal++) {
         calibrator_value=value_of_calibrator[cal];
	 xpos= x_origin + scale_factor * (calibrator_value-xmin);
	 yposstart=ypos2;
/*
	 picmove(xpos,ypos);
*/
	 for (r = 0, column=0; r < ranges; r++) {
	    yposend=range_startpos[r]+y_unit;
	    for (bar=0; bar<range_size[r]; bar++) {
	       dotted_v_line(xpos,yposend,yposstart);
	       yposstart=yposend;
	       yposend-=y_unit;
	       if (logflag) data =(central_value[column]  >0)?log(central_value[column])  :MISSING;
	       else data= central_value[column];
	       if (!(
		     data!=MISSING
		     &&
		     (
			(data>0 && calibrator_value>0 && calibrator_value<data)
			||
			(data<0 && calibrator_value<0 && calibrator_value>data)
		     )
		  ))
/*
		   {
#ifdef TRACE
                    if (Trace) fprintf(tracefile,"\n%4d data=%.3f calibrator_value=%.3lf",
                       __LINE__, data, calibrator_value);
#endif
		     picmove(xpos,ypos);
		  } else
*/
	       dotted_v_line(xpos,yposend, yposstart);
	       yposstart=yposend;
	       yposend-=y_unit * Intra;
/*
	       ypos -= y_unit * Intra;
*/
	       column++;
	    }
	 }
	 yposstart=yposend;
	 yposend=ypos3;
	 dotted_v_line(xpos, yposend, yposstart);
      }
   }
}

void dotted_v_line(int x0, int y0, int y1) {
   for (;y0+8<=y1;y0+=20) {
      picmove(x0,y0);
      picdraw(x0,y0+4);
   }
}

int picx_cal(int logflag) {
   int n, pos, cal, mantissa, lowest_exponent, highest_exponent;
   int oy, ly;
   double calibrator_value;
   logflag= ascal(&noofcalibrators, &xmin, &xmax, logflag, 1);
   xmin=(logflag)?log(xmin):xmin;
   xmax=(logflag)?log(xmax):xmax;
   oy=ypos3;
   ly=ypos2-ypos3;
   scale_factor=(double)x_length/(xmax - xmin);
   for (n=0;n<Plotter;n++) {
      picmove(x_origin+x_length/2,ypos1+50);
      pictext(0, CENTERBOTTOM, x_legend);
   }
   picmove(x_origin   , oy);
   picdraw(x_origin+x_length, oy);
   picmove(x_origin,    oy+ly);
   picdraw(x_origin+x_length, oy+ly);
   for (cal=0; cal<noofcalibrators; cal++) {
      calibrator_value=value_of_calibrator[cal];
      pos= (cal==noofcalibrators-1)?x_origin+x_length: x_origin + scale_factor * (calibrator_value-xmin);
      for (n=0;n<Plotter;n++) {
         picmove(pos,oy+RIM/2);
         picdraw(pos,oy);
         picmove(pos,oy+ly);
         picdraw(pos,oy+ly-RIM/2);
      }
      picmove(pos,oy+ly+RIM/2);
      pictext(0, CENTERBOTTOM, calibratorstring[cal]);
   }
   if (logflag) {
      highest_exponent=(int)(xmax/log(10)+0.001);
      lowest_exponent=(int)(xmin/log(10)-1.1);
      for (cal=lowest_exponent; cal<=highest_exponent; cal++) {
         for (mantissa=1;mantissa<10;mantissa++) {
            calibrator_value= log(val((double)mantissa,cal));
            if (calibrator_value > xmin && calibrator_value < xmax) {
               pos= x_origin + scale_factor * (calibrator_value-xmin);
               if (pos<x_origin || pos>x_origin+ x_length) continue;
               for (n=0;n<Plotter;n++) {
                     picmove(pos, oy);
                     picdraw(pos, oy+RIM/4);
                        picmove(pos, oy+ly);
                        picdraw(pos, oy+ly-RIM/4);
               }
            }
         }
      }
   }
   return logflag;
}

int ascal(int *noofcalibrators, float *min, float *max, int logflag, int calcflag) {
    int n, range, exp, exp0, t, t0, found, negative, precision, extra_decimal=0;
    double unit, value, tempmin, tempmax, ratio, base, lowest_calibrator;
    int exponent[MAXNOOFCALIBRATORS];
    if (logflag) round(scientific2(*min, &base, &exp));
    else round(scientific2(*max, &base, &exp));
    tempmin=*min * 10 +  fabs(*min)/10000;
    tempmax=*max * 10 -  fabs(*max)/10000;
    lowest_calibrator=val(10,exp);
    for (n=0;n<MAXNOOFCALIBRATORS;n++) {
        *calibratorstring[n]='\0';
        value_of_calibrator[n]=MISSING_CALIBRATOR;
    }

    if (logflag && tempmax<=0) logflag=FALSE;
    if (logflag) {
        if (tempmin<=0) tempmin= lowest_calibrator;
        ratio= (double)(tempmax / tempmin);
        if (ratio < 51 )       range= SMALL;
        else if (ratio < 301 ) range= MEDIUM;
        else                   range= LARGE;
    } else range=LINEAR;
    t=t0=0;
    found=FALSE;
    do{
       exp0=--exp;
       unit=val(calbase[range][t],exp);
    } while (3*unit>=tempmax-tempmin);
    while (!found) {
       if (! logflag) {
          found= ( 6*unit >= tempmax - tempmin);
          if (!found) {
             t++;
             t%=range+1;
             if (t==0) exp++;
             unit=val(calbase[range][t],exp);
          }
          if (found && t==2) extra_decimal=1;
       } else {
           value=val((double)calbase[range][t],exp+1);
           found= (value >= tempmin);
           if (!found) {
             t0=t;
             exp0=exp;
             t++;
             t%=range+1;
             if (t==0) exp++;
           } else {
             t=t0;
             exp=exp0;
             value=val((double)calbase[range][t],exp+1);
          }
       }
    }

PHASE2: /* find corrected min and max and fill array */
    if (!logflag) {
       if ( tempmin/unit-(int)(tempmin/unit) != 0) {
          negative= ( tempmin < 0);
          tempmin=  unit * (int)(tempmin/unit);
          if (negative) tempmin -= unit;
       }
    } else tempmin=val((double)calbase[range][t],exp+1);
    for (n=0 ; n < MAXNOOFCALIBRATORS ; n++) {
        if ( ! logflag ) {
           value_of_calibrator[n]=(tempmin + n*unit)/10;
           exponent[n]=exp;
        } else {
           exponent[n]= exp;
           value_of_calibrator[n]= val((double)calbase[range][t],exp);
           t++;
           t%=range+1;
           if (t==0) exp++;
        }
        if (value_of_calibrator[n] >= tempmax/10) {
            tempmax= value_of_calibrator[n]*10;
            *noofcalibrators=n+1;
            break;
        }
    }
    *min=tempmin/10;
    *max=tempmax/10;
    if (!calcflag) return logflag;

/* phase 3: print results in minimal-length strings */

    for (n=0; n< *noofcalibrators ; n++) {
        if (value_of_calibrator[n]>(*max>0?1.0001* *max:0.9999* *max)) {
#ifdef TRACE
           if (Trace) fprintf(tracefile,"\ncal[%d]=%.4lf *max=%.4lf verschil:%lf",
              n, value_of_calibrator[n], *max, value_of_calibrator[n] - *max);
#endif
           break;
        }
        precision= (range==LINEAR) ? (extra_decimal - exponent[n]): -exponent[n];
        if (precision<0) precision=0;
        sprintf(calibratorstring[n],"%.*lf", precision, value_of_calibrator[n]);
#ifdef TRACE
        if (Trace) fprintf(tracefile, "\n%4d : precision=%d exponent[%d]=%d range=%d extra_decimal=%d string %d: %s",__LINE__, precision, n, exponent[n], range, extra_decimal, n, calibratorstring[n]);
#endif
    }
                                                       
/* phase 4: if (logflag) transform data */

   if (logflag) for (n=0; n<*noofcalibrators; n++) value_of_calibrator[n]=log(value_of_calibrator[n]);

/* return logflag to indicate whether log-transformation was actually performed */

    return logflag;
}

double scientific2(double d, double *base, int *exp) {
   double logd;
   int neg=FALSE;
   if (d==0) {
      *base=0;
      *exp=-1;
      return *base;
   }
   if (d<0) {
      neg=1;
      d=-d;
   }
   logd=log10(d);
   *exp= (int)logd - (d<1)-1;
   *base= pow10d(logd-*exp);
   if (neg) *base=-*base;
   return *base;
}

double val(double mantissa, int exponent) {
   return mantissa*pow10(exponent);
}

int round(double d) {
    int i=(int)d;
    if (d-i<.5 ) return (int)(d+.5);
    return (int)(d+1);
}

double pow10d(double exponent) {
   /* 10^exponent, exponent is double rather than int, as required for pow() */
   return exp(exponent*log(10));
}



void picfill(int type, int x0, int y0, int lx, int ly, int flag) {
   int d, t, dd, direction, dx1, dy1, dx2, dy2;
   if (lx<0) {
      lx=-lx;
      x0-=lx;
   }
   if (ly<0) {
      ly=-ly;
      y0-=ly;
   }
   if (!flag) {
      type%=strlen(symbolstring);
      t=symbolstring[type]-'0';
   } else t=type;
   if (t<0 || t>7 || t==3) return;
   if (t==2) {
      picfill(0, x0, y0, lx, ly, TRUE);
      picfill(1, x0, y0, lx, ly, TRUE);
      return;
   }
   if (t==4) {
      for (d=4; d<ly; d+=4) {
         picmove(x0,y0+d);
         picdraw(x0+lx,y0+d);
      }
      return;
   }
   if (t==7) {
      picfill(2, x0, y0, lx, ly, TRUE);
      picfill(5, x0, y0, lx, ly, TRUE);
      return;
   }
   if (t==0) {
      dd=80;
      direction=1;
   }
   if (t==1) {
      dd=80;
      direction=-1;
      x0 += lx;
   }
   if (t==5) {
      dd=40;
      direction=1;
   }
   if (t==6) {
      dd=40;
      direction=-1;
      x0 += lx;
   }
   for (d=dd; d<lx + ly; d+=dd) {
      dx1 = (d<lx) ?  direction*d : direction*lx;
      dx2 = (d<ly) ?  0           : direction*(d-ly);
      dy1 = (d<lx) ?  ly          : ly-(d-lx);
      dy2 = (d<ly) ?  ly-d        : 0; 
      picmove(x0+dx1,y0+dy1);
      picdraw(x0+dx2,y0+dy2);
   }
}

int strpos(char *s,char c,int pos) {
/* finds next occurrence of c in s starting at pos */
int p;
     for (p=pos+1;s[p];p++) if (s[p]==c) return p;
     for (p=0;p<=pos;p++) if (s[p]==c) return p;
     return -1;
}

void read_environment(void) {
   char *s;
#ifdef TRACE
   Trace= (int)set_env_variable("TRACE", TRACE);
#endif
   startup_drive=getdisk();
   s=getenv("COLOR");
   if (!s) s=getenv("COLOUR");
   if (s) Color=atoi(s);
   else Color=COLOR;
   Color--;
   if (Color<0) Color=0;
   if (Color>5) Color=5;
   s=getenv("INPUT_PATH");
   if (!s) s=getenv("INPUT");
   if (s) strcpy(Input_path,s);
   s=getenv("OUTPUT_PATH");
   if (!s) s=getenv("OUTPUT");
   if (s) strcpy(Output_path,s);
   s=getenv("SYMBOLSTRING");
   if (s) strncpy(symbolstring,s,19);
   s=getenv("YTITLE");
   if (!s) s=getenv("YAS");
   if (s) strcpy(y_legend,s);
   else *y_legend='\0';
   s=getenv("TEXT0");
   if (s) strcpy(extra_text[0],s);
   s=getenv("TEXT1");
   if (s) strcpy(extra_text[1],s);
   s=getenv("TEXT2");
   if (s) strcpy(extra_text[2],s);
   s=getenv("TEXT3");
   if (s) strcpy(extra_text[3],s);
   s=getenv("TEXT4");
   if (s) strcpy(extra_text[4],s);
   s=getenv("TEXT5");
   if (s) strcpy(extra_text[5],s);
   s=getenv("TEXT6");
   if (s) strcpy(extra_text[6],s);
   s=getenv("TEXT7");
   if (s) strcpy(extra_text[7],s);
   s=getenv("TEXT8");
   if (s) strcpy(extra_text[8],s);
   s=getenv("TEXT9");
   if (s) strcpy(extra_text[9],s);
   s=getenv("INTRA");
   if (!s) s=getenv("INTER_BAR");
   if (!s) s=getenv("INTRA");
   if (s) Intra=((float)atof(s))/100;
   else   Intra=INTRA;
   s=getenv("INTER");
   if (!s) s=getenv("INTER_RANGE");
   if (s) Inter=((float)atof(s))/100;
   else   Inter=INTER;
   s=getenv("PLOTTER");
   if (s) Plotter=atoi(s);
   else Plotter=PLOTTER;
   X_length =set_env_variable("X_LENGTH", 2*X_LENGTH/3);
   if (X_length>X_LENGTH-100 || X_length<=0) X_length=X_LENGTH/2;
   Y_length =set_env_variable("Y_LENGTH", PICTOP);
   if (Y_length>PICTOP || Y_length<=0) Y_length=PICTOP;
   Show= (int)set_env_variable("SHOW", SHOW);
   Data_columns	=(int)set_env_variable("DATA_COLUMNS",	0);
   Legend= (int)set_env_variable("LEGEND", LEGEND);
   Legendpos= (int)set_env_variable("LEGENDPOS", LEGENDPOS);
   Fill= (int)set_env_variable("FILL", FILL);
   Grid= (int)set_env_variable("GRID", GRID);
   Box= (int)set_env_variable("Box", Box);
   Nn= (int)set_env_variable("NN", NN);
   Line= (int)set_env_variable("LINE", LINE);
   Textsize=(int)set_env_variable("TEXTSIZE",TEXTSIZE);
   Smallprint=(int)set_env_variable("SMALL",FALSE);
   Symbol_size= set_env_variable("SYMBOL_SIZE",   SYMBOL_SIZE);
   Symbol_type= set_env_variable("SYMBOL_TYPE",   SYMBOL_TYPE);
   s=getenv("LOG");
   if (!s) s=getenv("YLOG");
   if (s) Logflag=atoi(s);
   else Logflag=LOGFLAG;
   Cap= set_env_variable("CAP", CAP);
   Xmax= set_env_variable("YMAX", MISSING);
   Xmin= set_env_variable("XMIN", MISSING);
   if (Intra>2)  Intra=2;
   if (Intra<-1) Intra=-1;
   if (Inter>4)  Inter=4;
   if (Inter<1)  Inter=1;
   if (Cap<0) Cap=0;
   if (Cap>2) Cap/=100;
   if (Cap>2) Cap=2;
   if (Legend<0) Legend=0;
   if (Legend >8) Legend=8;
   if (Symbol_size<0) Symbol_size=-1;
   if (Symbol_size>400) Symbol_size=400;
   if (Data_columns>4) Data_columns=4;
   if (Data_columns<2) Data_columns=0;
   if (Nn) Data_columns=4; 
   if (Plotter>10 || Plotter <1) Plotter=PLOTTER;
}

float set_env_variable(char *env_string, float default_value) {
   char *s;
   s=getenv(env_string);
   if (s==0)			return default_value;
   if (!stricmp(s,"AUTO"))	return MISSING;
   if (!stricmp(s,"MISSING"))	return MISSING;
   if (!stricmp(s,"OFF"))	return 0;
   if (!stricmp(s,"FALSE"))	return 0;
   if (!stricmp(s,"ON"))	return 1;
   if (!stricmp(s,"TRUE"))	return 1;
   return atof(s);
}

char *keycopy(char *target,char *source,int maxlen) {
int t,tt,s,insert=0;
int c;
result=0;
for (t=0;t<maxlen;t++) target[t]='\0';
maxlen--;
c=0;
     for (t=0,s=0;t<maxlen && c!=RETURN;) {
          c=getkey(1);
          if (c>31 && c<127) {
               putch(c);
               target[t++]=c;
               if (insert==0 && (source[s+1])!='\0') s++;
          } else {
               switch (c) {
               case RETURN:
                    if (!target[0]) {
                       strcpy(target,source);
                       result=RETURN;
                    }
                    else target[t]='\0';
                    break;
               case EXEC:
               case W_EXEC:
               case ESC:
               case CANCEL:
               case BACKTAB:
                    target[0]=0;
                    c=RETURN;
                    break;
               case BACKSPACE:
                    insert=0;
                    if (t>0) {
                         printf("\b \b");
                         t--;
                    }
                    if (s>0) s--;
                    break;
               case RIGHT:
               case W_RIGHT:
                    insert=0;
                    if (t<maxlen && source[s]){
                         putch(source[s]);
                         target[t++]=source[s++];
                    }
                    break;
               case DELETE:
               case W_DELETE:
                    source++;
                    insert=0;
                    break;
               case INSERT:
               case W_INSERT:
                    insert=1;
                    break;
               case LEFT:
               case W_LEFT:
                    insert=0;
                    if (t>0) {
                         printf("\b \b");
                         t--;
                    }
                    if (s>0) s--;
                    break;
               case F3:
               case W_F3:
                    insert=0;
                    while (t<maxlen && source[s]) {
                         putch(source[s]);
                         target[t++]=source[s++];
                    }    
                    break;
               case F5:
               case W_F5:
                    insert=0;
                    for (tt=0;tt<t;tt++) source[tt]=target[tt];
                    for (t=0;t<maxlen;t++) target[t]='\0';
                    putch('@');
                    putch('\n');
                    s=t=0;
                    break;
               case CTRL_C:
                    farewell(0);
                    break;
               }
          }
     }
     return target;
}

void openin(char *s)
{
   if ((fpin=fopen(s,"rb")) == NULL) {
       E_OPENIN;
       farewell(-1);
   }
}

void openout(char *s)
{
   if ((fpout=fopen(s,"wb")) == NULL) {
       E_OPENOUT;
       farewell(-1);
   }
}

void picopen(char *s) {
int n;
unsigned char c;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n\n%4d $$$$$$$$$$$$$$$$ picopen \"%s\" $$$$$$$$$$$$$$$$\n",__LINE__,s);
#endif
   openout(s);
   for (n=0;n<17;n++){
      c=header_vector[n];
      fputc(c,fpout);
   }
   picsize(Hsize,Vsize);
   picfont(1);
   piccolor(0);
}

void piccorner() {
   picmove(X_ORIGIN,Y_ORIGIN+X_LENGTH);
   picdraw(X_ORIGIN,Y_ORIGIN);
   picdraw(X_ORIGIN+X_LENGTH,Y_ORIGIN);
   picmove(X_LENGTH,PICTOP-Y_LENGTH);
   picdraw(X_LENGTH,PICTOP);
   picdraw(X_LENGTH-Y_LENGTH,PICTOP);
}

void picxy(int x,int y) {
   fputc(x/256,fpout);
   fputc(x%256,fpout);
   fputc(y/256,fpout);
   fputc(y%256,fpout);
}

void picmove(int x,int y)
{
   fputc(MOVE,fpout);
   picxy(x,y);
}

void picfont(char font)
{
   fputc(FONT,fpout);
   fputc(font,fpout);
}

void piccolor(int color) {
   fputc(COLOR0+color%6,fpout);
}

void picsize(int x,int y)
{
   fputc(SIZE,fpout);
   picxy(x,y);
}

void picdraw(int x,int y)
{
   fputc(DRAW,fpout);
   picxy(x,y);
}

void pictext(int direction,int position, char *s)
{
   fputc(TEXT,fpout);
   fputc((unsigned char)direction*16+position,fpout);
   fputs(s,fpout);
   fputc('\0',fpout);
}

void picend(void)
{
   fputc(END,fpout);
   fclose(fpin);
   if (fclose(fpout)==EOF) {
     E3;
     farewell(-1);
   }
}

void picheaders(int headerlines) {
   int h;
   if (*first_title) {
      picmove(x_origin + x_length/2,pictopline(0));
      pictext(0,CENTERTOP,first_title);
   }
   if (*second_title) {
      picmove(x_origin + x_length/2,pictopline(1));
      pictext(0,CENTERTOP,second_title);
   }
   for (h=2;h<headerlines;h++) {
      picmove(x_origin + x_length/2,pictopline(h));
      pictext(0,CENTERTOP,headerline[h]);
   }
}

int pictextlines(int ypos, int xpos, char *text, int direction, int position) {
   int line, lines, n;
   char *textpointer;
   strncpy(buffer,text,MAX_LEN);
   lines=count_char(buffer,'\\')+1;
   textpointer=strtok(buffer,"\\");
   for (line=0; line<lines; line++) {
#ifdef TRACE
        if (Trace) fprintf(tracefile,"\n%4d ypos=%d xpos=%d text=%s textpointer=%s",
           __LINE__, ypos, xpos, buffer, textpointer);
#endif
        picmove(ypos, xpos);
        if (line==0) for (n=0;n<Plotter;n++) pictext(direction,position,buffer);
        else if (textpointer) for (n=0;n<Plotter;n++) pictext(direction,position,textpointer);
        textpointer=strtok(NULL,"\\");
        if (direction) ypos+= Hsize;
        else           xpos-= Vsize;
  }
  if (direction) return ypos;
  return xpos;
}

int strmenu(int current_pos, int rows, int startrow,int nooflines) {
     int pos, key;
     int n, result, row, col, maxnoofitems;
     maxnoofitems=TEXTCOLUMNS*nooflines;
     if (rows>maxnoofitems) rows=maxnoofitems;
     if (rows>MAXFILES) rows=MAXFILES;
     for (n=0;n<rows;n++) startchars[n]=toupper(*(filename[n]));
     startchars[rows]='\0';
     n = current_pos;
     do {
        row=startrow + n % nooflines;
        col=1+SCREENCOLUMNS/TEXTCOLUMNS*(n/nooflines);
        gotoxy(col, row);
        HLON;
        printf("%-8s",strnleft2(buffer,filename[n],'.',8));
        NORM;
        key=getkey(0);
        gotoxy(col, row);
        printf("%-8s",strnleft2(buffer,filename[n],'.',8));
        if (key<=SPACE || key>256) {
           switch (key) {
              case UP:
              case W_UP:
                   n--;
                   if (n<0) n=rows-1;
                 break;
              case DOWN:
              case W_DOWN:
              case SPACE:
                   n++;
                   if (n > rows-1) n=0;
                 break;
              case TAB:
              case RIGHT:
              case W_RIGHT:
                   if (n<rows-nooflines) n+=nooflines;
                 break;
              case BACKTAB:
              case LEFT:
              case W_LEFT:
                   if (n>nooflines-1) n-=nooflines;
                 break;
              case PgUp:
              case W_PgUp:
                   n=(n>nooflines-1 && rows>nooflines) ?
                        nooflines:
                        0;
                 break;
              case HOME:
              case W_HOME:
                   n=0;
                 break;
              case PgDn:
              case W_PgDn:
                   n=(n>nooflines-1 || nooflines>rows) ?
                        rows-1:
                        nooflines-1;
                   if (n>rows-1) n=rows-1;
                 break;
              case SHIFT_HOME:
                   n=rows-1;
                 break;
                case RETURN:
                case W_ENDKEY:
                case W_EXEC:
                case EXEC:
                   result = RETURN;
                 break;
                case ESC:
                case CANCEL:
                   n=-1;
                 break;
              case CTRL_C:
                  farewell(0);
              default:
                  break;
           }
       } else {
               pos=strpos(startchars,toupper(key),n);
               n=(pos<0) ? n : pos;
       }
     }  while (result!=RETURN && n>=0);
   return n;
}

/*
int select_ranges(int restore) {
   int t, column, ranges, group, columnno, startrow, nooflines, selected_column;
   int r;
   selected_column=-1;
   startrow=2;
   nooflines=18;
   for (t=0,r=1;t<columns;t++) {
      startchars[t]=toupper(testname[t][0]);
      if (range_start[r]==t+1) {
         flag[t]=ON;
         r++;
      }
      else flag[t]=OFF;
   }
   startchars[columns]='\0';
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d startchars: %s",__LINE__,startchars);
#endif
   if (!restore) {
      ranges=0;
      clrscr();
      write_screen(startrow, columns, nooflines);
      columnno=0;
      do {
         group=1;
         columnno = strmenu2(
            columnno,
            &selected_column,
            columns,
            startrow,
            nooflines);
         if ( selected_column == -1) break;
         if ( selected_column == -2) continue;
         if ( selected_column == -3) {
            group=Group;
            if (columnno+group>=columns) {
               group=columns-columnno;
               putch(7);
            }
         }
         if ( selected_column == -4) {
            group= columns - columnno;
         }
         for (t=columnno;t<columnno+group;t++) {
            if (flag[t]==OFF && ranges<RANGES && ranges<columns) {
               flag[t]=ON;
               ranges++;
            }
            else if (flag[t]==ON) {
               flag[t]=OFF;
               ranges--;
            }
            else {
               columnno--;
               putch(7);
            }
         }
         write_screen( startrow, columns, nooflines);
         columnno+=group-1;
         columnno = (++columnno) % columns;
      } while (selected_column != -1);
   }
   range_start[0]=0;
   maxrange=0;
   for (t=0,ranges=0, column=0; t<columns && ranges < RANGES; t++) {
      if (flag[t]==ON && ranges < RANGES) {
         ranges++;
         range_start[ranges]=t+1;
         range_size[ranges-1]=range_start[ranges]-range_start[ranges-1];
         column+=range_size[ranges-1];
         if (maxrange<range_size[ranges-1]) maxrange=range_size[ranges-1];
      }
   }
   if (ranges<RANGES && column<columns) {
      range_size[ranges]=columns-column;
      ranges++;
   }
   fill=Fill;
   return ranges;
}
*/

void write_screen(int startrow, int rows, int nooflines) {
int n, row, col, maxnoofitems;
  gotoxy(1,23);
  printf("\033[7mSelect range-separation with RETURN; press UITVOEREN to end range-division\033[0m");
  maxnoofitems=4*nooflines;
  if (rows>maxnoofitems) rows=maxnoofitems;
  if (rows>MAXFILES) rows=MAXFILES;
  for (n=0;n<rows;n++) {
     row=startrow + n % nooflines;
     col=SCREENCOLUMNS/TEXTCOLUMNS*(n/nooflines);
     gotoxy(1+col,1+row);
     if (flag[n]==ON) ULON;printf("%s",testname[n]);NORM;
  }
}

int strmenu2(int current_pos, int *selected_test, int rows, int startrow,int nooflines) {
     int pos, key;
     int n, result, row, col, maxnoofitems;
     maxnoofitems=TEXTCOLUMNS*nooflines;
     if (rows>maxnoofitems) rows=maxnoofitems;
     if (rows>MAXFILES) rows=MAXFILES;
     *selected_test=-2;
     startchars[rows-1]='\0';
     n = current_pos;
     row=startrow + n % nooflines;
     col=SCREENCOLUMNS/TEXTCOLUMNS*(n/nooflines);
     gotoxy(1+col,1+row);
     key=getkey(0);
     if (key<=SPACE || key>256) {
        switch (key) {
           case UP:
           case W_UP:
                n--;
                if (n<0) n=rows-2;
                result = n;
              break;
           case DOWN:
           case W_DOWN:
                n++;
                if (n > rows-2) n=0;
                result = n;
              break;
           case TAB:
           case RIGHT:
           case W_RIGHT:
                if (n<rows-nooflines) n+=nooflines;
                result = n;
              break;
           case BACKTAB:
           case LEFT:
           case W_LEFT:
                if (n>nooflines-1) n-=nooflines;
                result = n;
              break;
           case PgUp:
           case W_PgUp:
                n=(n>nooflines-1 && rows>nooflines) ?
                     nooflines:
                     0;
                result = n;
              break;
           case HOME:
           case W_HOME:
                n=0;
                result = n;
              break;
           case PgDn:
           case W_PgDn:
                n=(n>nooflines-1 || nooflines>rows) ?
                     rows-2:
                     nooflines-1;
                if (n>rows-1) n=rows-2;
                result = n;
              break;
           case SHIFT_HOME:
                n=rows-2;
                result = n;
              break;
             case CTRL_A:
                *selected_test= -4;
                result = n;
              break;
             case CTRL_B:
             case CTRL_Z:
                *selected_test= -3;
                result = n;
              break;
             case RETURN:
             case SPACE:
                *selected_test=n;
                result = n;
                break;
             case EXEC:
             case ESC:
             case CANCEL:
                *selected_test= -1;
                result = n;
              break;
           case CTRL_C:
               farewell(0);
           default:
               result = n;
               break;
        }
    } else {
            pos=strpos(startchars,toupper(key),n);
            n=(pos<0) ? n : pos;
            result =  n;
    }
    return result;
}

char *strleft(char *s1,char *s2,char *s3) {
     int i,ii;
     if (strlen(s2)==0 || strlen(s3)==0 ) {
          *s1='\0';
          return s1;
     }
     strcpy(s2,s1);
     for (i=1;i<=strlen(s3);i++) {
          for (ii=strlen(s2);ii>0;ii--) {
               if (s3[i-1]==s2[ii-1]) {
                    s1[ii]='\0';
                    return s1;
               }
          }
     }
     *s1='\0';
     return s1;
}

/* $getfile: GET FILE FROM DISC as a subroutine; first Eco-C version: 081187 */
/* modified 040288,060288,270288,040388: quit with Esc */
/* Turbo-C version 220388 */
/* latest modification: 230388 */

char *getfile(char *s) {
   char drive[MAXDRIVE];
   char dir[MAXDIR];
   char shortname[MAXFILE];
   char ext[MAXEXT];
    char path[120];
    int nooffiles,selected_file;
	do {
		strcpy(path,getmask(s));
		if (!(*path)) return NULL;
		makefilename(path,path,".PRN",0);
		fnsplit(path, drive, dir, shortname, ext);
		fnmerge(Input_path, drive, dir, "*", ext);
		nooffiles=getdir(path,filename);
		if (!nooffiles) {
			CLS;
			M1_GETFILE;
		}
	} while (!nooffiles);
        selected_file = strmenu(
           0,
           nooffiles,
           SCREENSTARTROW,
           NOOFLINES
        );
	if (selected_file==-1) return NULL;
	strcpy(s,filename[selected_file]);
	fnmerge(path,drive,dir,filename[selected_file],ext);
	return path;
}

char *strnleft2(char *buffer, char *s1, char stop, int n) {
   int i=0;
   do buffer[i]=s1[i++];
   while  (i && i<n && s1[i]!=stop);
   buffer[i]='\0';
   return buffer;
}

char *getmask(char *mask) {
	char buffer[80];
    M2_GETFILE;
	keycopy(buffer,mask,80);
	strcpy(mask,buffer);
	return mask;
}

int getdir(char *s, char filename[][LENFILENAME+1]) {
	int done,n,row,col,month,day,year,hour,minute,second;
	struct ffblk ffblk;
	CLS;
	M3_GETFILE;
	for (col=0; col<TEXTCOLUMNS; col++) {
	   gotoxy(1+col*SCREENCOLUMNS/TEXTCOLUMNS, SCREENSTARTROW-1);
           printf("Filename YY/MM/DD");
        }
	done=findfirst(s,&ffblk,0);
        if (done) return 0;
	for(n=0,done=0;!done && n<MAXFILES;n++) {
		row=SCREENSTARTROW + n%NOOFLINES;
                col=1+SCREENCOLUMNS/TEXTCOLUMNS*(n/NOOFLINES);
		gotoxy(col, row);
		strcpy(filename[n],ffblk.ff_name);
		maketime(&hour,&minute,&second,ffblk.ff_ftime);
		makedate(&month,&day,&year,ffblk.ff_fdate);
		printf("%-8s %2.2d/%2.2d/%2.2d\n",strnleft2(buffer, filename[n],'.',8), year, month, day);
                done=findnext(&ffblk);
	}
	return(n);
}

void makedate(int *m,int *d,int *y,unsigned total) {
	*m=(total>>5)&0XF;
	*d=total & 0X1F;
	*y=(total>>9)&0X3F;
	*y+=80;
}

void maketime(int *h,int *m,int *s,unsigned total) {
	*h=(total>>11) & 0X1F;
	*m=(total>>5) & 0X3F;
	*s=total & 0X1F;
}

void startup_message() {
   clrscr();
   frame(50,4);
   gotoxy(3,2);
   S1;
   gotoxy(3,3);
   S2;
   gotoxy(1,5);
}

void frame(int hor,int vert) {
   int x,y;
   x=wherex();
   y=wherey();
   putch(201);
   printstring(205,hor-2);
   putch(187);
   down(186,vert-2);
   putch(188);
   gotoxy(x,y);
   down(186,vert-2);
   putch(200);
   printstring(205,hor-2);
   gotoxy(x,y+vert+1);
}   

void printstring(char c,int n) {
   int i;
   for (i=0;i<n;i++) putch(c);
}

void down(char c,int n) {
   int i;
   for (i=0;i<n;i++) {
      putch('\n');
      putch('\b');
      putch(c);
   }
   putch('\n');
   putch('\b');
}

int picsave(char *source, char *target, char *ext) {
   char s[20], cli[MAX_LEN+1];
   int i, files_written, ok;
   if (Show) {
      clrscr();
      printf("RETURN = save as %s_file\n"
             "SPACE  = do NOT save, go back to options menu\n"
             "Esc    = do NOT save, quit program\n", ext);
      i=getkey(0);
   } else i=RETURN;
   switch (i) {
      default:
      case SPACE:
      case TAB:
         return 1;
      case ESC:
      case CANCEL:
      case CTRL_C:
         farewell(0);
         break;
      case RETURN:
      case EXEC:
      case W_EXEC:
         setdisk(0);
         if (Show) {
            do {
               printf("default file-name: %s ",target);
               keycopy(buffer,target,MAX_LEN);
               if (!result) {
                  strcpy(buffer, target);
                  return 1;
               }
               if (!(check_dosname(buffer))) {
                  ok=FALSE;
                  clrscr();
                  printf("\"%s\" is not a valid filename\n"
                  "re-enter filename: ", buffer);
               } else ok=TRUE;
            } while (!ok);
            if (!check_output_file(target,buffer,ext)) return 1;
         }
         sprintf(cli,"copy %s %s > c:bar.log",source, target);
         do {
            *s=0;
            system(cli);
            fpin=fopen("c:bar.log","rt");
            fscanf(fpin,"%s",s);
            fclose(fpin);
            files_written=atoi(s);
            if (!files_written) {
               printf("\nerror executing DOS-command: \"%s\"\n",cli);
               sprintf(cli,"TYPE %s","c:bar.log");
               system(cli);
               printf("\n\nRETURN = re-try\n"
                     "SPACE  = do NOT save, go to options menu\n"
                     "Esc    = do NOT save, quit program\n");
               i=getkey(0);
               switch (i) {
                  default:
                     case SPACE:
                     setdisk(startup_drive);
                     return 1;
                  case RETURN:
                  case EXEC:
                    setdisk(startup_drive);
                    break;
                  case ESC:
                  case CANCEL:
                     farewell(0);
               }
            }
         } while (!files_written);
         setdisk(startup_drive);
         if (!Show) return 1;
         else return 0;
      /* end case RETURN */
   }
   return 0;
}

int check_output_file(char *new_name, char *default_name, char *ext) {
   result=0;
   strcpy(new_name,default_name);
   makefilename(new_name,Output_path,ext,1);
   while ((fpin=fopen(new_name,"rb"))!=NULL && result!=RETURN) {
     fclose(fpin);
     printf("\n\noutput file %s already exists\nenter new name or press RETURN to overwrite\noutput-PIC-file :",new_name);
     if (keycopy(new_name, default_name, 80)==NULL) return 0;
     strcpy(default_name, new_name);
     if (*new_name==NULL) return 0;
     makefilename(new_name,Output_path,ext,1);
   }
   return 1;
}

char *makefilename(char *fullname, char *default_path, char *default_ext, int forced_ext_flag) {
   int flag;
   char drive[MAXDRIVE];
   char default_drive[MAXDRIVE];
   char dir[MAXDIR];
   char default_dir[MAXDIR];
   char shortname[MAXFILE];
   char ext[MAXEXT];
   flag = fnsplit(default_path, default_drive, default_dir, shortname, ext);
   flag = fnsplit(fullname, drive, dir, shortname, ext);
   if (!(flag & DRIVE))      strcpy( drive, default_drive);
   if (!(flag & DIRECTORY))  strcpy( dir, default_dir);
   if (!(flag & EXTENSION) || forced_ext_flag)  strcpy( ext, default_ext);
   fnmerge(fullname,drive,dir,shortname,ext);
   fnmerge(default_path,drive,dir,"*",ext);
   return fullname;
}

int getmaxlegend(void) {
   int i, len, maxlen=0;
   for (i=0; i<maxrange; i++) {
         len=strcspn(testname[i],"\\");
         if ( maxlen < len) maxlen=len;
   }
   return maxlen;
}

int get_bottomlines(void) {
   int bottomlines;
   bottomlines= (Legendpos==0 && Legend>0 && maxrange>1)?ceil((double)get_legendlines()/Legend):0;
   return bottomlines;
}

int get_legendlines(void) {
   int i, n;
   for (i=0, n=0; i<maxrange; i++)  n+=count_char(testname[i],'\\')+1;
   return n;
}

int get_rangenamelines(void) {
   int i, n, nmax;
   if (ranges>1) {
      for (i=0, nmax=1; i<ranges; i++)  {
         n=count_char(range_name[i],'\\')+1;
         if (nmax<n) nmax=n;
      }
   } else {
      for (i=0, nmax=1; i<columns; i++)  {
         n=count_char(testname[i],'\\')+1;
         if (nmax<n) nmax=n;
      }
   }
   return nmax;
}

int count_char(char *s, char c) {
   int n=0, result=0;
   while(s[n]) if (s[n++]==c) result++;
   return result;
}

void piclegend(int legends_per_line) {
   int i, x, y, y2, lines, legendlines;
   char *textfragment, text[81];
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d piclegend",__LINE__);
#endif
   if (!legends_per_line) return;
   if (Legendpos==0) {
      lines=ceil((double)maxrange/legends_per_line);
      for (i=0; i<maxrange; i++) {
         if (Color) piccolor(i);
         if ( ranges<2 ) x= x_origin;
         else x = x_origin + (x_length*((i/lines)%legends_per_line))/legends_per_line;
         y= picbottomline(lines-(i%lines)-1)-DY+20;
#ifdef TRACE
         if (Trace) fprintf(tracefile,"\n%4d x=%d y=%d",
            __LINE__, x, y);
#endif
         picmove(x       , y+20);
         picdraw(x       , y + YSIZE );
         picdraw(x+XSIZE , y + YSIZE );
         picdraw(x+XSIZE , y+20);
         picdraw(x       , y+20);
         picfill(i,x,y+20,XSIZE,YSIZE-20, FALSE);
         x+=XSIZE+DX;
         y+=DY;
         picmove(x , y+20 );
         pictext(0, CENTERLEFT, testname[i]);
#ifdef TRACE
         if (Trace) fprintf(tracefile,"\n%4d legend %d: \"%s\"",__LINE__,i,range_name[i]);
#endif
      }
   } else {
      legendlines=get_legendlines();
      if (Legendpos==1) x = x_origin + x_length + 40;
      if (Legendpos==2) x = x_origin + x_length - legendblocksize;
      if (Legendpos==3) x = 1;
      y = (Legendpos==3)?PICTOP:ypos2-YSIZE+RIM/2;
      y2= y - maxrange*1.4*YSIZE - (legendlines-maxrange)*YSIZE - 2*DY;
      if (Box) {
          picmove(x, y);
          picdraw(x,y2);
          picdraw(x+legendblocksize, y2);
          picdraw(x+legendblocksize, y);
          picdraw(x, y);
          y -= YSIZE;
      }
      x += DX;
      for (i=0; i<maxrange; i++) {
         strncpy(text,testname[i],80);
         if (Color) piccolor(i);
         y-=DY;
#ifdef TRACE
         if (Trace) fprintf(tracefile,"\n%4d x=%d y=%d i=%d maxrange=%d, YSIZE=%d",
            __LINE__, x, y, i, maxrange, YSIZE);
#endif
          picmove(x    , y      );
          picdraw(x    , y + YSIZE );
          picdraw(x+XSIZE , y + YSIZE );
          picdraw(x+XSIZE , y      );
          picdraw(x    , y      );
          picfill(i,x,y,XSIZE,YSIZE,FALSE);
          y+=DY;
          textfragment=strtok(text,"\\");
          do {
             picmove(x + XSIZE+ DX, y);
             if (textfragment) pictext(0, CENTERLEFT, textfragment);
             textfragment=strtok(NULL,"\\");
             if (textfragment) y -= YSIZE;
             else y -= 1.4*YSIZE;
          }  while (textfragment);
#ifdef TRACE
         if (Trace) fprintf(tracefile,"\n%4d legend %d: \"%s\"",__LINE__,i,testname[i]);
#endif
      }
   }
}

char *ftoa(float f) {
   sprintf(buffer,"%.3f",f);
   return buffer;
}
