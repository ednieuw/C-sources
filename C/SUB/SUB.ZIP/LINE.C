/* teken line-graph + error-bar vanuit PRN-file */
/* compile:
if exist error del error
tcc -mc t4 >error
type error
*/
/* compile t.b.v. debugger (dc4.bat)
if exist error del error
if exist t4.exe del t4.exe
tcc -mh -v -C t1 >error
if exist t4.exe del t4.obj
type error
echo doorgaan naar TD?
pause
copy t4.c \td
copy t4.exe \td
cd \td
td t4
cd\c
pe t4.c
*/


#define TRACE           FALSE

#define TRUE            1
#define FALSE 			0
#define TEXTSIZE        15
#define VSIZE           (TEXTSIZE*9)
#define HSIZE           (TEXTSIZE*8)
#define X_ORIGIN        (HSIZE/2)
#define X_LENGTH		(3200-HSIZE)
#define LOG0            240 /* 0-position on logarithmic abscissa */
#define Y_ORIGIN        VSIZE
#define Y_LENGTH        (2300 - VSIZE)
#define PICTOP          Y_LENGTH
#define RIM             100 /* tick-mark size */
#define FILL            TRUE
#define HGRID           FALSE
#define VGRID           FALSE
#define BOX             FALSE /* Draw box surrounding legends */
#define NN              FALSE   /* indicate number of observations per column */
#define LEGEND          1   /* number of lines for legends */
#define LEGENDPOS		1   /* legends to the right of the graph */
#define XSIZE           160 /* horizontal size of connecting line in legend block */
#define LOGFLAG         FALSE
#define PIXELS_PER_LINE 2
#define PLOTTER			1
#define X_LEGEND        "units/ml"
#define Y_LEGEND        "% radioactivity bound"
#define PRNFILE			"a:line.prn"
#define PICFILE			"a:line.pic"
#define SHOW			TRUE
#define XFORMAT         0
#define YFORMAT         0




#define LOGXFLAG        TRUE
#define LOGYFLAG		FALSE
#define XY			FALSE	/* draw x=y line  */
#define Y1LINE      TRUE
#define CAP			50
#define SYMBOL_SIZE     40
#define LEGEND_SYMBOL_SIZE 64
#define LINE            TRUE    /* connect points */
#define S1 printf("Programma \"LINE.EXE\" dd %s",__DATE__)
#define S2 printf("Inlichtingen en fouten-melding: Rob Aalberse")
#define M0 printf("\nNo filename entered; press RETURN to re-try\n")
#define M1 printf("\nOutput-file: \"%s\" ready for PRINTGRAPH or DRAWPIC!\n",picfile)
#define M1_GETFILE printf("No files in directory %s\ntry again ... \n\n",s)
#define M2_GETFILE printf("Enter directory search mask ( press Esc to exit):\n%s ",mask)
#define M3_GETFILE printf("Mask: %s. Select file and press RETURN (press Esc to exit)",s)
#define E0 printf("\ncannot open input file %s; press RETURN to re-try\n",prnfile)
#define E2 printf("\nNon-printable character \" %c \" (ASCII %d): wrong input-file \"%s\"?\nprogramm aborted\n",c,c,prnfile)
#define E3 printf("\nError writing file to disc: Disc full?")
#define E1_CHECK_OUTPUT_FILE(s) printf("\n\noutput file %s allready exists\nenter new name or press RETURN to overwrite\noutput-PIC-file :",s)
#define E_OPENIN printf("\ncannot open \"%s\" for input\n",s)
#define E_OPENOUT printf("\ncannot open \"%s\" for output\n",s)

#define DATA_COLUMNS	6
#define MAXNOOFCALIBRATORS  10
#define XCAL                 3 /* type of axes drawn 0-3 */
#define YCAL                 3 /* type of axes drawn 0-3 */
#define MISSING_CALIBRATOR -999
#define MARGIN      50
#define COLUMNS     512
#define HEADERLINES	20
#define MAX_LEN		81
#define OFF ' '
#define ON  '#'
#define GROUP 8
#define HLON  printf("\033[7m")		/* inverse video */
#define ULON  printf("\033[4m")		/* underline */
#define BLON  printf("\033[5m")		/* blink */
#define NORM  printf("\033[0m")
#define CLS   printf("\033[2J")
#define CURSOR(a,b) printf("\033[%d;%dH",a,b)
#define MORE CURSOR(25,70);HLON;printf(" MORE --> ");NORM;getch();CLS
#define QUOTE 34

#define RANGES COLUMNS
#define LARGE 0
#define MEDIUM 1
#define SMALL  2
#define LINEAR 3
#define MISSING		-999999.000

#define LENFILENAME 12
#define SCREENSTARTROW 4
#define NOOFLINES (25-SCREENSTARTROW)
#define SCREENCOLUMNS 80
#define TEXTCOLUMNS 4
#define MAXFILES (TEXTCOLUMNS*NOOFLINES)

/* pic.h: header for pic-files 280288 */

#define MOVE 160
#define DRAW 162
/*
#define FILL 48
#define FILLO 208
*/
#define COLOR 1		/* number of colors */
#define COLOR0 176
#define TEXT 168
#define FONT 167
#define SIZE 172
#define END 0X60
#define CENTER 0
#define CENTERLEFT 1
#define CENTERTOP 2
#define CENTERRIGHT 3
#define CENTERBOTTOM 4
#define TOPLEFT 5
#define TOPRIGHT 6
#define BOTTOMLEFT 7
#define BOTTOMRIGHT 8

/* keyboard.h 230288 */
#define QUOTE 34
#define SPECIAL_KEY 0
#define UP 328
#define DOWN 336
#define HOME 327
#define SHIFT_HOME 382
#define LEFT 331
#define RIGHT 333
#define PgUp 329
#define PgDn 337
#define EXEC 335
#define ESC 27
#define CANCEL 366
#define INSERT 338
#define DELETE 339
#define F1 315
#define F2 316
#define F3 317
#define F4 318
#define F5 319
#define F6 320
#define F7 321
#define F8 322
#define F9 323
#define F10 324
#define HELP 367 /* F1 toets */
#define SPACE 32
#define RETURN 13
#define BACKSPACE 8
#define CR 13
#define TAB 9
#define BACKTAB 271
#define CTRL_A 1
#define CTRL_B 2
#define CTRL_C 3
#define CTRL_Z 26

#define W_SPECIAL_KEY 31
#define W_UP 192
#define W_DOWN 194
#define W_HOME 196
#define W_ENDKEY 199
#define W_LEFT 195
#define W_RIGHT 193
#define W_PgUp 200
#define W_PgDn 201
#define W_EXEC 197
#define W_ESC 224       /*= annuleer= laat vervallen= cancel */
#define W_ESC2 205      /*= backtab links boven */
#define W_INSERT 198
#define W_DELETE 199
#define W_F1 128
#define W_F2 129
#define W_F3 130
#define W_F4 131
#define W_F5 132
#define W_F6 133
#define W_F7 134
#define W_F8 135
#define W_F9 136
#define W_F10 137
#define W_HELP 225

#include <stdio.h>
#include <stdlib.h>
#include <alloc.h>
#include <process.h>
#include <math.h>
#include <io.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include <fcntl.h>
#include <dos.h>
#include <dir.h>

void startup_message(void);
void read_environment(void);
void allocate(void);
void print_environment(FILE *outfile);
int picbottomline(int n);
void dotted_h_line(int x0, int x1, int y0);
void dotted_v_line(int x0, int y0, int y1);
int get_options(void);
void no_room(void);
void minmax_menu(void);
void legend_menu(void);
void position_menu(void);
void format_menu(void);
void range_menu(void);
void extra_text_menu(void);
int isdecimal(char c);
int isdelimiter(char c);
int isnumber(char *s);
int isvoid(char *s);
void printstring(char c,int n);
void frame(int hor,int vert);
void down(char c,int n);
int strmenu(int current_pos, int rows, int startrow,int nooflines);
char *strleft(char *target,char *source, char *mask);
char *keycopy(char *target,char *source,int maxlen);
char *getmask(char *default_mask);
int getdir(char *s,char filename[][]);
void makedate(int *m,int *d,int *y,unsigned total);
void maketime(int *h,int *m,int *s,unsigned total);
char *getfile(char *mask);
int read_data(char *filename);
void openin(char *filename);
void openout(char *filename);
int  fgetline(char *line,int maxlen, FILE *fpin);		/* returns no of non_white chars */
int parse_line(char *buffer, int dataline);
int numbers_per_line(char *buffer);
char *stripwhites(char *s);
void picopen(char *filename);
int check_output_file(char *new_name, char *default_name, char *ext);
int check_dosname(char *s);
void piccorner();
void picfont(char font);
void piccolor(int color);
void picsize(int x,int y);
void picxy(int x,int y);
void picmove(int x,int y);
void picdraw(int x,int y);
void pictext(int direction,int position,char *s);
void picdot(int x,int y, int type, int size);
int picdotdot(double step1, double step2, double xfactor, double yfactor, double *xpos, double *ypos, double xlim, double ylim);
void picdotted_line(int x0, int y0, int x, int y, int type);
void picend();
void picheaders(int headerlines);
void picx_axis_title(char *x_axis_string, int y_pos);
int picy_axis_title(char *y_axis_string, int y_pos);
int pictextlines(int xpos, int ypos, char *text, int direction, int position);
int pictopline(int n);
void piclegend(int legends_per_line);
void legend_menu();
void column_menu();
void picextra_text(int x_origin, int y_origin, int lx, int ly);
int getkey(int flag);
void farewell(int exit_code);
void picxlegend(int n, int lines, char array[][MAX_LEN+1]);
char *find_monthname(char *name, int month, double size_per_month);
void picylegend(int n, int lines, char array[][MAX_LEN+1]);
int picx_cal(int logflag);
int picy_cal(int logflag);
int ascal(int *noofcalibrators, float *min, float *max, int logflag, int calcflag, int format);
double scientific2(double d, double *base, int *exp);
int round(double d);
double val(double mantissa, int exponent);
double pow10d(double exponent);


void plot_point(int column, int range_number, int bar);
void draw_line(int n, float xmin, double x_factor, float ymin, double y_factor);
void draw_xy(int x_origin, float xmin, float xmax, double x_factor, int y_origin, float ymin, float ymax, double y_factor);
float set_env_variable(char *env_string, float default_value);
int picsave(char *source, char *target, char *ext);



char *makefilename(char *full_filename, char *default_path, char *default_ext, int forced_ext_flag);
char *strnleft2(char *buffer, char *s1, char c, int n);
int strpos(char *s,char c,int pos);
int strpos2(char *s,char c,int pos);
int getmaxlegend(void);
int count_char(char *s, char c);
void  yesno(int flag, char *yesstring, char *nostring);

int get_legendlines(void);
char *ftoa(float f);

FILE *fpin, *fpout, *tracefile;
char prnfile[80];
char outfile[80];
char picfile[]		="C:LINE.PIC";
char Input_path[80]	="A:";
char Output_path[80]	="A:";
char symbolstring[20]="0123456789";
char linetypestring[20]="012345678";
char extra_text[10][MAX_LEN+1];
float Xmax=MISSING, Xmin=MISSING, Ymax=MISSING, Ymin=MISSING, xmin, xmax, ymin, ymax;
int result=0, ranges, headerlines;
int data_columns, Data_columns=0;
double scale_xfactor, scale_yfactor;
int Cap=CAP;
char header_vector[]= {1,0,0,0,1,0,8,0,68,0,0,0,0,12,127,9,6};
#ifdef TRACE
   int Trace=TRACE;
#endif
int Show=SHOW, Hgrid=HGRID, Vgrid=VGRID, Y1line=Y1LINE, Xformat=XFORMAT, Yformat=YFORMAT, Legend=LEGEND, Legendpos=LEGENDPOS, Logxflag=LOGXFLAG, Logyflag=LOGYFLAG, Xy=XY;
int Symbol_size=SYMBOL_SIZE, Line=LINE, Group=GROUP, Box=BOX;
int Color=COLOR, Plotter=PLOTTER, Xcal=XCAL, Ycal=YCAL;
int YSIZE, DX, DY, Vsize, Hsize;  
int Textsize;
int maxlegend, legendblocksize;
int xll, xul, yll, yul;         /* xll=x_lower_limit in screen units */
int xllflag, xulflag, yllflag, yulflag; /*xulflag: data_points higher than Xmax found */
int logxflag, logyflag;
int x_origin, x_length=X_LENGTH, X_length, log0;
int y_origin, y_length=Y_LENGTH, Y_length;
int Rim;
char filename[MAXFILES][LENFILENAME+1];
char flag[COLUMNS];
char range_name[RANGES+1][MAX_LEN+1];
int range_size[RANGES+1];
int range_start[RANGES+1];
int range_startpos[RANGES+1];
float xx1;
float xx2;
float xx3;
float yy1;
float yy2;
float yy3;
float *x1;
float *x2;
float *x3;
float *y1;
float *y2;
float *y3;

int result;
int maxrange;
unsigned columns;
char monthname[12][10]={
"DECEMBER",
"JANUARI",
"FEBRUARI",
"MARCH",
"APRIL",
"MAY",
"JUNE",
"JULY",
"AUGUST",
"SEPTEMBER",
"OCTOBER",
"NOVEMBER"
};
char    calibratorstring[MAXNOOFCALIBRATORS][12];
double value_of_calibrator[MAXNOOFCALIBRATORS];
int noofcalibrators=MAXNOOFCALIBRATORS;
int calbase[4][4]=   {1 , 0, 0, 0,
        	                         1 , 3, 0, 0,
                	                 1 , 2, 5, 0,
                        	         10,20,25,50
                                	 };
int startup_drive;
char x_legend[MAX_LEN];
char y_legend[MAX_LEN];
char headerline[HEADERLINES][MAX_LEN];
char first_title[MAX_LEN+1], second_title[MAX_LEN+1];
char stringline[HEADERLINES+2][MAX_LEN];	/* extra lines: x- and y-legend */
char buffer[MAX_LEN];
char startchars[MAXFILES];

/************************ START OF MAIN ************************/

int main(int argc, char* argv[]) {
   int r, n, legend, bar;
   int column;
   int maxlen, changes_made;
   long prnlength;
   noofcalibrators=MAXNOOFCALIBRATORS;
   read_environment();
   if (Show) startup_message();
   allocate();
   Vsize=Textsize*9;
   Hsize=Textsize*8;
   YSIZE=0.9*Vsize;   /* vertical size of legend block */
   if (Xformat==2) Logxflag=0;
   DX=30;
   DY=30;
   setdisk(0);
#ifdef TRACE
   if (Trace) {
      if ((tracefile=fopen("C:trace","wt"))==0) {
         printf("cannot open \"C:trace\"");
         farewell(-1);
      } else printf("C:trace open\n");
      print_environment(tracefile);
   }
#endif
   do {
      if (argc>2) {
         if (*argv[2] != '-') strcpy(outfile,argv[2]);
         else strcpy(outfile,argv[2]+1);
      }
      if (argc==1 || (argc>1 && *argv[1]=='-')) {
          strcpy(prnfile,"A:*.prn");
          makefilename(prnfile,Input_path,".PRN",1);
          while (getfile(prnfile)==NULL) {
                CLS;
                M0;
                if (getch()!=CR) farewell(-1);
                CLS;
                strcpy(prnfile,"A:*.prn");
                makefilename(prnfile,Input_path,".PRN",1);
          }
      } else if (argc>1 && *argv[1]!='-') strcpy(prnfile,argv[1]);
      makefilename(prnfile, Input_path, ".PRN", 0);
      if (argc>1 && *argv[1]=='-') {
         strcpy(outfile,argv[1]+1);
         makefilename(outfile, Output_path, ".PIC",1);
      }
      if (! *outfile) {
         strcpy(outfile,prnfile);
         makefilename(outfile,Output_path,".PIC",1);
      }
      while ((fpin=fopen(prnfile,"rb"))== NULL) {
          CLS;
          E0;
          if (getch()!=CR) farewell(-1);
     }
     if ((prnlength=filelength(fileno(fpin)))==0) {
         clrscr();
         printf("Selected file is empty\n"
         "Possible cause: file not closed when printing to file\n"
         "e.g. Lotus-123 command sequence:\n"
         "Print File Range Go Quit\n"
         "Forgetting \"Quit\"  results in empty (non-closed) file\n\n"
         "Press Esc to quit program\n"
         "Any other key to select other file");
         if (getch()==ESC) farewell(-1);
      }
   } while (!prnlength);
   clrscr();
   printf("reading file %s\n",prnfile);
   columns=read_data(prnfile);
   if (Show) {
      for (r= 0, column=0;r < ranges; r++) {
         if (ranges>1) printf("\nrange %d: %s", r+1, range_name[r]);
         for (bar=0; bar<range_size[r]; bar++) {
            printf("\ncolumn %3d: %9.2lf %9.2lf %9.2lf %9.2lf",
               column+1, x2[column], y1[column], y2[column], y3[column]);
            column++;
        }
      }
   }
   setdisk(startup_drive);
   do {
      x_length=X_length;
      y_length=Y_length;
      if (*first_title) {
         strcpy(headerline[0], first_title);
         if (headerlines<1)  headerlines=1;
      }
      if (*second_title) {
         strcpy(headerline[1], second_title);
         if (headerlines<2) headerlines=2;
      }

/**** determine max and min values ****/
      if (Legend<2 && ranges==1) Legend=0;
      legend=(Legend==0 || Legendpos !=0)?1:1+ceil((double)ranges/Legend);
#ifdef TRACE
      if (Trace) fprintf(tracefile,"\n%4d Legend=%d legend=%d ranges=%d columns=%d",
         __LINE__, Legend, legend, ranges, columns);
#endif
      y_origin=(Legend==0 || Legendpos !=0)? picbottomline(2)+20:picbottomline(legend+2)+20;
      if (Xformat==1 && (Xcal==0 || Xcal==2)) y_origin+=VSIZE;
      y_length= pictopline(headerlines)-y_origin-(Ycal==0?Rim:0);

/**** find min/max values for graph */

      xmin=-MISSING;
      xmax=MISSING;
      log0=0;
      for (column=0;column<columns;column++) {
         if (Logxflag && !x2[column]) log0=LOG0;
         else if (xmin >x1[column]) xmin=x1[column] ;
         if (xmax <x3[column]) xmax=x3[column] ;
      }
      if (Xmax !=MISSING) xmax= Xmax;
      if (Xmin !=MISSING) xmin= Xmin;
      if (xmin <0 ) Logxflag=0;
      if (Xmin==MISSING && !Logxflag && xmin>0 && Xformat<2) xmin=0;
      if (Logxflag && xmax / xmin <6) {
         xmin=sqrt(xmax * xmin)/2.5;
         xmax=xmin*6;
      }
      ymin=-MISSING;
      ymax=MISSING;
      for (column=0;column<columns;column++) {
         if (ymin >y1[column] ) ymin=y1[column] ;
         if (ymax <y3[column] ) ymax=y3[column] ;
      }
      if (Ymax !=MISSING) ymax= Ymax;
      if (Ymin !=MISSING) ymin= Ymin;
      if (ymin <=0) Logyflag=0;
      if (Ymin==MISSING && !Logyflag && ymin>0) ymin=0;
      if ( Logyflag && ymax / ymin <6) {
         ymin=sqrt(ymax * ymin)/2.5;
         ymax=ymin*6;
      }
      xllflag=yllflag=xulflag=yulflag=0;
      for (column=0;column<columns;column++) {
         if (log0 && !x2[column]) continue;
         if (x2[column]<xmin && x2[column]!=MISSING) xllflag=1;
         if (y2[column]<ymin && y2[column]!=MISSING) yllflag=1;
         if (x2[column]>xmax) xulflag=1;
         if (y2[column]>ymax) yulflag=1;
      }
      maxlegend= getmaxlegend();
      legendblocksize= maxlegend*Hsize/2 + 3*DX + LEGEND_SYMBOL_SIZE;
      if (Line) legendblocksize+=LEGEND_SYMBOL_SIZE + DX;

/**** write line_graph to PIC-file ****/

      picopen(picfile);
/*
      piccorner();
*/
      x_origin= X_ORIGIN + picy_axis_title(y_legend, y_origin + y_length);
      ascal(&noofcalibrators, &ymin, &ymax, Logyflag, 0, Yformat);
      for (n=0, maxlen=0; n<noofcalibrators;n++) if (maxlen<strlen(calibratorstring[n])) maxlen=strlen(calibratorstring[n]);
      x_origin+= maxlen * Hsize/2 + 2*Rim;
      x_length= (Legendpos==1 && ranges>1) ? X_length - x_origin - legendblocksize - 2*Rim-2*DX:X_length - x_origin - 2*Rim;
      if (x_length<=100) x_length=100;
      if (Ycal/3==0) {
         x_origin+=Rim;
         x_length-=Rim+((Ycal==0)?Rim:0);
      }
      if (Xcal/3==0) {
         y_origin+=Rim;
         y_length-=Rim+((Xcal==0)?Rim:0);
      }
      logyflag= picy_cal(Logyflag);
      x_origin+=log0;
      logxflag= picx_cal(Logxflag);
      picextra_text(x_origin, y_origin, x_length, y_length);
      xll=x_origin-log0;
      xul=x_origin+(xmax-xmin)*scale_xfactor;
      yll=y_origin;
      yul=y_origin+(ymax-ymin)*scale_yfactor;
      if (xllflag) dotted_v_line(xll,y_origin,y_origin+y_length);
      if (xulflag) dotted_v_line(xul,y_origin,y_origin+y_length);
      if (yllflag) dotted_h_line(x_origin-log0,x_origin+x_length,yll);
      if (yulflag) dotted_h_line(x_origin-log0,x_origin+x_length,yul);
      if (xmin < 0 && xmax>0 && !logxflag) for (n=0;n<Plotter;n++) {
         picmove(x_origin - xmin * scale_xfactor, y_origin);
         picdraw(x_origin - xmin * scale_xfactor, y_origin+y_length);
      }
      if (ymin < 0 && ymax > 0 && (!logyflag || (logyflag && Y1line))) for (n=0;n<Plotter;n++) {
         picmove(x_origin-log0, y_origin - ymin * scale_yfactor);
         picdraw(x_origin-log0 + x_length+log0, y_origin - ymin * scale_yfactor);
      }

      for (n=0;n<Plotter;n++) picheaders(headerlines);
      column=0;
      for (r= 0;r < ranges; r++) {
         if (Color) piccolor(r);
         for (bar=0; bar<range_size[r]; bar++) {
            if (!(y2[column]==MISSING||x2[column]==MISSING)) {
               if (logyflag) {
                  yy1=(y1[column]>0)?log(y1[column]):MISSING;
                  yy2=(y2[column]>0)?log(y2[column]):MISSING;
                  yy3=(y3[column]>0)?log(y3[column]):MISSING;
               } else {
                  yy1=y1[column];
                  yy2=y2[column];
                  yy3=y3[column];
               }
               if (logxflag && x2[column]) {
                  xx1=(x1[column]>0)?log(x1[column]):MISSING;
                  xx2=(x2[column]>0)?log(x2[column]):MISSING;
                  xx3=(x3[column]>0)?log(x3[column]):MISSING;
               } else {
                  xx1=x1[column];
                  xx2=x2[column];
                  xx3=x3[column];
               }
               for (n=0;n<Plotter;n++)  plot_point(column,r,bar);
               column++;
            }
         }
      }
      for (r=0;r<ranges;r++) {
         if (Line || symbolstring[r]=='L') {
            if (Color) piccolor(r);
            for (n=0;n<Plotter;n++) draw_line(r, xmin, scale_xfactor, ymin, scale_yfactor);
         }
      }
      if (Xy) draw_xy ( x_origin, xmin, xmax, scale_xfactor, y_origin, ymin, ymax, scale_yfactor);
      if (Legend && ranges>1) for (n=0;n<Plotter;n++) piclegend(Legend);
      fputc(END,fpout);
      if (fclose(fpout)==EOF) {
        E3;
        farewell(-1);
      }
      if (logxflag) {
         xmin=exp(xmin);
         xmax=exp(xmax);
      }
      if (logyflag) {
         ymin=exp(ymin);
         ymax=exp(ymax);
      }
      if (Show) {
         if (spawnlp(P_WAIT,"drawpic.exe","drawpic.exe",picfile,NULL)==-1) {
            printf("\nspawn-error\n");
            farewell(-1);
         }
         changes_made=get_options();
      } else changes_made=0;
      if (changes_made== -1) farewell(0);
      if (changes_made== 0) {
         changes_made=picsave(picfile, outfile, ".PIC");
         if (changes_made) if(get_options()==-1) farewell(0);
      }
   } while (changes_made>0 && Show);
   farewell(0);
   return 1;
}

/****************************************************************
*								*
*			END OF MAIN()				*
*								*
****************************************************************/

void allocate(void) {
if ((x1= (float *)calloc( COLUMNS , sizeof(float) ))==0) no_room();
if ((x2= (float *)calloc( COLUMNS , sizeof(float) ))==0) no_room();
if ((x3= (float *)calloc( COLUMNS , sizeof(float) ))==0) no_room();
if ((y1= (float *)calloc( COLUMNS , sizeof(float) ))==0) no_room();
if ((y2= (float *)calloc( COLUMNS , sizeof(float) ))==0) no_room();
if ((y3= (float *)calloc( COLUMNS , sizeof(float) ))==0) no_room();
}

void no_room(void){
   printf("\nError: Out of memory\n");
   farewell(0);
}


void farewell(int exit_code) {
   setdisk(startup_drive);
   exit(exit_code);
}

int get_options(void) {
int c, n, option, changes=0;
   for (;;) {
      do {
         CLS;
         printf("0 - x-axis log-transformation: %s\n",(Logxflag?"yes":"no"));
         printf("1 - y-axis log-transformation: %s\n",(Logyflag?"yes":"no"));
         printf("2 - first title: \"%s\"\n",  first_title);
         printf("3 - second title: \"%s\"\n", second_title);
         printf("4 - x-axis title: \"%s\"\n", x_legend);
         printf("5 - y-axis title: \"%s\"\n", y_legend);
/*
         printf("6 - number of data_columns: %d\n",data_columns);
*/
         printf("7 - cap on error-lines: %d\n", Cap);
         printf("8 - lines connecting points: %s\n",(Line?"yes":"no")); 
         printf("9 - (X= Y) - line: %s\n",(Xy?"yes":"no"));
         printf("A - Axis: modify format X- or Y-axis\n");
         printf("C - %s\n", Color?"4-COLOR (for plotter)":"B/W rather than Color");
         printf("F - Format of lines: current line-types: %s\n", linetypestring);
         printf("G - Grid: Horizontal grid: %s; vertical grid: %s\n",Hgrid?"YES":"NO",Vgrid?"YES":"NO");
         if (Logyflag)
           printf("H - Horizontal line at y=1: %s\n",Y1line?"yes":"no");
         printf("L - Legends: modify text of legends\n");
         printf("M - MinMax: ");
              printf("Xmin=%s ",(Xmin==MISSING)?"AUTO":ftoa(Xmin));
              printf("Xmax=%s ",(Xmax==MISSING)?"AUTO":ftoa(Xmax));
              printf("Ymin=%s ",(Ymin==MISSING)?"AUTO":ftoa(Ymin));
              printf("Ymax=%s\n",(Ymax==MISSING)?"AUTO":ftoa(Ymax));
         printf("P - Position: modify position of legends\n");
         printf("S - Symbols: modify type/size of symbols\n");
         printf("T - Text: change text-size (default: %i)\n",Textsize);
         printf("X - X-axis: modify length of x-axis\n");
         printf("Y - Y-axis: modify length of y-axis\n");
         printf("\nRETURN= accept options\n");
         printf("Escape= quit\n");
         printf("Select option:  ");
         if ((option=getkey(0))==RETURN || option==EXEC) return changes;
         if (option==ESC || option==CANCEL) return -1;
      } while (strpos("ACFGHLMPSTXY012345789",option,0)==-1);
      changes++;
      switch (option) {
         case 'A':
            format_menu();
            break;
         case 'C':
            Color=(Color)?0:3;
            break;
         case 'F':
            clrscr();
            printf("\n\nLine-type sequence used: \"%s\" \n"
               "0 = solid line\n"
               "1 = ----------\n"
               "2 = ..........\n"
               "3 = -.-.-.-.-.\n"
               "4 = -...-...-.\n"
               "5 = double solid line\n"
               "6 = double dashed line\n"
               "7 = double dotted line\n"
               "8 = double dashdotted line\n", linetypestring);
            strcpy(linetypestring, keycopy(buffer, linetypestring, 19));
            for (n=0; n<strlen(linetypestring); n++) {
               linetypestring[n]=toupper(linetypestring[n]);
               if (symbolstring[n]=='O') symbolstring[n]='0';
            }
            break;
         case 'G':
            do {
               clrscr();
               printf("H - Horizontal grid: ");
               yesno(Hgrid, "Yes", "No");
               printf("V - Vertical   grid: ");
               yesno(Vgrid, "Yes", "No");
               printf("\RETURN = accept\n");
               c=getkey(0);
               if (c=='H') Hgrid=Hgrid?0:1;
               if (c=='V') Vgrid=Vgrid?0:1;
            } while (c!=RETURN && c!=ESC);
            break;
         case 'H':
            Y1line=(Y1line)?0:1;
            break;
         case 'L':
            legend_menu();
            break;
         case 'M':
            minmax_menu();
            break;
         case 'P':
            position_menu();
            break;
         case 'S':
            clrscr();
            printf("\n\nSymbol sequence used: \"%s\" \n"
               "0 = open circle\n"
               "1 = filled circle\n"
               "2 = open square\n"
               "3 = filled square\n"
               "4 = open triangle\n"
               "5 = filled triangle\n"
               "6 = open inverted triangle\n"
               "7 = filled inverted triangle\n"
               "8 = *\n"
               "9 = vertical line\n\n"
               "L = line without symbols\n"
               "B = vertical bar\n\n: ",symbolstring);
            strcpy(symbolstring, keycopy(buffer, symbolstring, 19));
            for (n=0; n<strlen(symbolstring); n++) {
               symbolstring[n]=toupper(symbolstring[n]);
               if (symbolstring[n]=='O') symbolstring[n]='0';
            }
            printf("\nsymbolstring:\"%s\"\n\n\nsymbol size (0-400, default %d)\n: ",
               symbolstring, Symbol_size);
            gets(buffer);
            if (*buffer) {
               n=atoi(buffer);
               if (n>=0 && n<=400) Symbol_size=n;
            }
#ifdef TRACE
            if (Trace) fprintf(tracefile,"\n%4d:symbolstring=\"%s\", size=%d",__LINE__, symbolstring, Symbol_size);
#endif
            break;
         case 'T':
            clrscr();
            printf("Text-size: (max=%d,default=%d)", 2*TEXTSIZE, Textsize);
            gets(buffer);
            n=atoi(buffer);
            if (n>0 && n<=2*TEXTSIZE) {
               Textsize=n;
               Vsize=Textsize*9;
               Hsize=Textsize*8;
               YSIZE=0.9*Vsize;   /* vertical size of legend block */
               DY=0.4*YSIZE;
            }
            break;
         case 'X':
            printf("\nLength of x-axis (max=%d,default=%d)",X_LENGTH, X_length);
            gets(buffer);
            n=atoi(buffer);
            if (n>1 && n<=X_LENGTH) X_length=n;
            break;
         case 'Y':
            printf("\nLength of y-axis (max=%d,default=%d)",Y_LENGTH, Y_length);
            gets(buffer);
            n=atoi(buffer);
            if (n>1 && n<=Y_LENGTH) Y_length=n;
            break;
         case '0':
            Logxflag=(Logxflag)?0:1;
            break;
         case '1':
            Logyflag=(Logyflag)?0:1;
            break;
         case '2':
            CLS;
            printf("First title \"%s\": ",first_title);
            strcpy(first_title,keycopy(buffer, first_title, MAX_LEN));
            break;
         case '3':
            CLS;
            printf("\nSecond title \"%s\": ",second_title);
            strcpy(second_title,keycopy(buffer, second_title, MAX_LEN));
            break;
         case '4':
            CLS;
            printf("\nLegend x-axis \"%s\": ",x_legend);
            strcpy(x_legend, keycopy(buffer, x_legend, MAX_LEN));
            break;
         case '5':
            CLS;
            printf("\nLegend y-axis \"%s\": ",y_legend);
            strcpy(y_legend, keycopy(buffer, y_legend, MAX_LEN));
            break;
         case '6':
            CLS;
            printf("\nnumber of datacolumns (max=%d,default=%d)",DATA_COLUMNS, data_columns);
            gets(buffer);
            if (*buffer) {
               n=atoi(buffer);
               if (n>1 && n<=DATA_COLUMNS) Data_columns=n;
            }
            data_columns=Data_columns;
            break;
         case '7':
            CLS;
            printf("\n0      = no cap on error-bars\n"
                     "0 - 400= length of cap-line (default:%d): ",Cap);
            gets(buffer);
            if (*buffer) Cap=atof(buffer);
            if (Cap<0) Cap=0;
            if (Cap>400) Cap=400;
            break;
         case '8':
            Line=(Line)?0:1;
            break;
         case '9':
            Xy=(Xy)?0:1;
            break;
      }
   }
}

void minmax_menu(void) {
   CLS;
   printf("M - MinMax: ");
   printf("Xmin=%s ",(Xmin==MISSING)?"AUTO":ftoa(Xmin));
   printf("Xmax=%s ",(Xmax==MISSING)?"AUTO":ftoa(Xmax));
   printf("Ymin=%s ",(Ymin==MISSING)?"AUTO":ftoa(Ymin));
   printf("Ymax=%s\n\n",(Ymax==MISSING)?"AUTO":ftoa(Ymax));
   printf("'?'= AUTOMATIC\n\n");
   printf("Xmin=lowest value x-axis (%s) ",(Xmin==MISSING)?"AUTO":ftoa(Xmin));
   gets(buffer);
   if (*buffer=='?' || *buffer=='/' || *buffer=='A' || *buffer=='a') Xmin=MISSING;
   else if (*buffer) Xmin=atof(buffer);
   printf("\nXmax=highest value x-axis (%s) ",(Xmax==MISSING)?"AUTO":ftoa(Xmax));
   gets(buffer);
   if (*buffer=='?' || *buffer=='/' || *buffer=='A' || *buffer=='a') Xmax=MISSING;
   else if (*buffer) Xmax=atof(buffer);
   printf("\nYmin=lowest value y-axis (%s) ",(Ymin==MISSING)?"AUTO":ftoa(Ymin));
   gets(buffer);
   if (*buffer=='?' || *buffer=='/' || *buffer=='A' || *buffer=='a') Ymin=MISSING;
   else if (*buffer) Ymin=atof(buffer);
   printf("\nYmax=highest value y-axis (%s) ",(Ymax==MISSING)?"AUTO":ftoa(Ymax));
   gets(buffer);
   if (*buffer=='?' || *buffer=='/' || *buffer=='A' || *buffer=='a') Ymax=MISSING;
   else if (*buffer) Ymax=atof(buffer);
}

void legend_menu(void) {
   int option;
   CLS;
   printf("1 - Show/modify legends of ranges\n");
   printf("2 - Show/modify extra text\n");
   printf("\n\nEscape or RETURN= previous menu\n"
              "Choose 1 or 2:  \n");
   option=getkey(0);
   switch (option) {
      case '1':
         range_menu();
         break;
      case '2':
         extra_text_menu();
         break;
   }
}

void range_menu(void) {
   int t, response;
   for (;;) {
      CLS;
      ULON;
      printf("Current range-names:\n\n");
      NORM;
      for (t=0;t<ranges;t++) printf("\n%d=%-16s",t+1,range_name[t]);
      printf("\n\nRETURN= accept\nModify which legend (1-%d) : ",ranges);
      do {
         response=getkey(0);
         if (response==ESC || response==CANCEL) return;
         t=response-'1';
      } while (response!=RETURN && (t<0 || t>=ranges));
      if (response==RETURN) break;
      printf("%c\n%s: ",response,range_name[t]);
      keycopy(buffer,range_name[t],MAX_LEN);
      if (isvoid(buffer)) range_name[t][0]='\0';
      else strcpy(range_name[t],buffer);
   }
}
void format_menu(void) {
   int i;
   clrscr();
   printf("X-axis:\n\n"
          "0=Numerical format\n"
          "1=Exponential format\n"
          "2=Month-format\n"
          "Default: %i ",Xformat);
   i=toupper(getch());
   if (i!=RETURN && i>='0' && i<='2') Xformat=i-'0';
   printf("\n\n0,1,2: \"exploded\"\n\n"
            "0 - Tick marks on both sides of the figure\n"
            "1 - Tick marks at left, only a line at right\n"
            "2 - Tick marks at left, empty at right\n\n"
            "3,4,5: \"closed\"\n\n"
            "3 - Tick marks on both sides of the figure\n"
            "4 - Tick marks at left, only a line at right\n"
            "5 - Tick marks at left, empty at right\n\n"
            "Default: %i ",Xcal);
   i=toupper(getch());
   if (i!=RETURN && i>='0' && i<'6') Xcal=i-'0';
   if (Xformat==2) Logxflag=0;
   clrscr();
   printf("Y-axis:\n\n"
          "0=Numerical format\n"
          "1=Exponential format\n"
          "Default: %i ",Yformat);
   i=getch();
   if (i!=RETURN && i>='0' && i<='1') Yformat=i-'0';
   printf("\n\n0,1,2: \"exploded\"\n\n"
            "0 - Tick marks bottom and top\n"
            "1 - Tick marks at bottom axis, only a line at top of figure\n"
            "2 - Tick marks at bottom axis, empty at top of figure\n\n"
            "3,4,5: \"closed\"\n\n"
            "3 - Tick marks bottom and top\n"
            "4 - Tick marks at bottom axis, only a line at top of figure\n"
            "5 - Tick marks at bottom axis, empty at top of figure\n\n"
            "Default: %i ",Ycal);
   i=toupper(getch());
   if (i!=RETURN && i>='0' && i<'6') Ycal=i-'0';
}
void position_menu(void) {
   int r;
   CLS;
   printf("Legend at the indicated position (%d):\n\n"
               "%c%c%c%c%c%c%c\n"
               "%c3   2%c1\n"
               "%c     %c\n"
               "%c     %c\n"
               "%c%c%c%c%c%c%c\n"
               "0\n\n",Legendpos,218,196,196,196,196,196,191,
                                 179,179,179,179,179,179,
                                 192,196,196,196,196,196,217);
   r=getch();
   if (r>='0' && r<'4') Legendpos=r-'0';
   if (Legendpos==0 && Legend>=0) {
      printf("\n\nLegends printed over %d column(s) ",Legend);
      r=getch();
      if (r>='0' && r<'9') Legend=r-'0';
   }
}

void extra_text_menu(void) {
   int t, response;
   char buffer[MAX_LEN+1];
   for (;;) {
      CLS;
      printf("\Extra text at the indicated positions:\n\n"
               "0         1\n"
               "  2  3  4\n\n"
               "  5  6  7\n"
               "8         9\n\n");
      for (t=0;t<10;t++) if (extra_text[t][0]) printf("\nextra text %d: %s",t,extra_text[t]);
      printf("\n\nRETURN= accept\nModify/add which text (0 - 9) : ");
      do {
         response=getkey(0);
         t=response-'0';
      } while (response!=RETURN && (t<0 || t>9));
      if (response==RETURN) break;
      printf("%c\n%s: ",response,extra_text[t]);
      keycopy(buffer,extra_text[t],MAX_LEN);
      if (isvoid(buffer)) extra_text[t][0]='\0';
      else strcpy(extra_text[t],buffer);
   }
#ifdef TRACE
   if (Trace) {
      fprintf(tracefile,"%4d extra text:\n",__LINE__);
      for (t=0;t<10;t++) fprintf(tracefile,"\n%d \"%s\"",t,extra_text[t]);
   }
#endif
}

int isvoid(char *s) {
   int i;
   for (i=0;s[i];i++) if (!isspace(s[i])) return 0;
   return 1;
}

void picextra_text(int x_origin, int y_origin, int lx, int ly) {
   int i, x, y, position;
   for (i=0; i<10; i++) {
      if (extra_text[i][0]) {
         switch (i) {
            case 0:
               position=TOPLEFT;
               x=X_ORIGIN;
               y=Y_length;
               break;
            case 1:
               position=TOPRIGHT;
               x=X_ORIGIN+X_length;
               y=Y_length;
               break;
            case 2:
               position=TOPLEFT;
               x=x_origin+12;
               y=y_origin+ly-12;
               break;
            case 3:
               position=CENTERTOP;
               x=x_origin + lx/2;
               y=y_origin+ly-12;
               break;
            case 4:
               position=TOPRIGHT;
               x=x_origin+lx-12;
               y=y_origin+ly-12;
               break;
            case 5:
               position=BOTTOMLEFT;
               x=x_origin+12;
               y=y_origin+12;
               break;
            case 6:
               position=CENTERBOTTOM;
               x=x_origin + lx/2;
               y=y_origin+12;
               break;
            case 7:
               position=BOTTOMRIGHT;
               x=x_origin+lx-12;
               y=y_origin+12;
               break;
            case 8:
               position=BOTTOMLEFT;
               x=X_ORIGIN;
               y=picbottomline(1);
               break;
            case 9:
               position=BOTTOMRIGHT;
               x=X_length;
               y=Y_ORIGIN;
               break;
         }
         picmove(x,y);
         pictext(0,position, extra_text[i]);
      }
   }
}

int getkey(int flag) {
int c;
   result=1;
   c=getch();
   if (c==SPECIAL_KEY) {
      c=256+getch();
      if (c>F5 && c<=F10) return c;
   } else {
      if (c==ESC) result=0;
      if (c==CTRL_C) farewell(-1);
      if (!flag) c=toupper(c);
   }
   return c;
}

int read_data(char *f) {
   int non_whites, line=0, column=0, n, r, maxlen=MAX_LEN;
   int rangeline, dataline=-1;
   int stringlines=0;
   int ranges_read=0;
   headerlines=0;
   for (r=0;r<RANGES;r++) range_size[r]=0;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n\n%4d ++++++++++ reading from %s +++++++++++\n",__LINE__, f);
#endif
   openin(f);
   do {
      line ++;
      if (line%10==1) putch('.');
      if ((non_whites=fgetline(buffer,maxlen,fpin))<1) continue;
      data_columns=parse_line(buffer, column);
      if (data_columns>0) {
         if (stringlines && dataline==-1) ranges_read=1;
         if (ranges_read) range_size[ranges_read-1]++;
         dataline=1;
         column++;
      }
      if (column>=COLUMNS) break;
      if (data_columns==0 && stringlines<HEADERLINES+2 && *buffer!='\0') {
         strcpy(stringline[stringlines],buffer);
         if (dataline==-1) headerlines++;
         if (dataline) stringlines++;
         if (dataline > 0) {
            dataline=0;
            range_size[ranges_read]=0;
            range_start[ranges_read]=column;
            ranges_read++;
         }
      }
      if (ranges_read>=RANGES){
         ranges_read=RANGES;
         break;
      }
      if (stringlines>=HEADERLINES+2){
         stringlines=HEADERLINES+2;
         headerlines--;
         break;
      }
   } while (non_whites!=EOF && column<COLUMNS && ranges_read<RANGES && stringlines<HEADERLINES+2);
   fclose(fpin);
   ranges=ranges_read;
   if (ranges>1) headerlines--;
   rangeline=headerlines;
   for (n=0;n<stringlines;n++) {
#ifdef TRACE
      if (Trace) fprintf(tracefile,"\n%4d stringline %d: \"%s\"",
         __LINE__,n,stringline[n]);
#endif
      stripwhites(stringline[n]);
   }
   if (headerlines) {
      headerlines --;
      if (!*x_legend) strcpy(x_legend,stringline[headerlines]);
   } else if (!*x_legend) strcpy(x_legend,X_LEGEND);
   if (headerlines) {
      headerlines --;
      if (!*y_legend) strcpy(y_legend,stringline[headerlines]);
   } else if (!*y_legend) strcpy(y_legend,Y_LEGEND);
   if (ranges>1) for (r=0,n=rangeline;n<stringlines;r++,n++) strcpy(range_name[r],stringline[n]);
   if (headerlines) for (n=0;n<headerlines;n++) {
      strcpy(headerline[n],stringline[n]);
      if (n==0) if (!*first_title) strcpy (first_title,headerline[0]);
      if (n==1) if (!*second_title) strcpy (second_title,headerline[1]);
   }
#ifdef TRACE
   if (Trace) {
      for (n=0;n<stringlines;n++) fprintf(tracefile,"\n%4d line %d: \"%s\"",
      __LINE__,n,stringline[n]);
      for (n=0;n<column;     n++) fprintf(tracefile,"\n%4d column %4d:  %9.2lf: %9.2lf %9.2lf %9.2lf",
            __LINE__, n, x2[n], y1[n], y2[n], y3[n]);
   }
#endif
   return column;
}

int parse_line(char *buffer, int dataline) {
   int data_columns=-1, textstring=0, digits=0, pos, pos1, pos2, p, n;
   char value[20];
   float digit[DATA_COLUMNS], tempdigit;
   char c;
   digits=0;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n\n%4d line to parse: %s",__LINE__, buffer);
#endif
   if (!Data_columns) data_columns=numbers_per_line(buffer);



   else data_columns=Data_columns;

   if (data_columns>DATA_COLUMNS) data_columns=DATA_COLUMNS;
   if (!data_columns) return 0;
   for (n=data_columns-1,pos2=strlen(buffer)-1;n>=0 && !textstring;n--) {
      do {
         *value='\0';
         c=buffer[pos2];
         if ( !(isdelimiter(c) || isdigit(c))) textstring=TRUE;
         if (isdelimiter(c) ) pos2--;
      } while (!(textstring) && isspace(c) && pos2>-1 );
      if (textstring) return 0;
      pos1=pos2;
      while (pos1>0 && isdecimal(c=buffer[pos1])) pos1--;
      if (isdelimiter(c) || pos1==0) {
         digits ++;
         for (pos=pos1;!isdecimal(buffer[pos]) && pos<pos2+1;pos++)
            ;
         for (p=0;pos<pos2+1;p++,pos++)
            if (p<20) value[p]=buffer[pos];
            else {
               printf("\nERROR in line %s: number too long: %p\n",
                  buffer,p);
               farewell(-1);
            }
         value[p]='\0';
         if (!(isnumber(value))) textstring=TRUE;
         else digit[data_columns-digits]= (float)atof(value);
      } else textstring=TRUE;
      pos2=pos1;
      if (textstring) return 0;
   }
   if (data_columns<2) return 0;
   switch(data_columns) {
      case 2:
         x1[dataline]=digit[0];
         x2[dataline]=digit[0];
         x3[dataline]=digit[0];
         y1[dataline]=digit[1];
         y2[dataline]=digit[1];
         y3[dataline]=digit[1];
         break;
      case 3:
         x1[dataline]=digit[0];
         x2[dataline]=digit[0];
         x3[dataline]=digit[0];
         y1[dataline]=digit[1]-digit[2];
         y2[dataline]=digit[1];
         y3[dataline]=digit[1]+digit[2];
         break;
      case 4:
         if (digit[1]>digit[3]) {
            tempdigit=digit[1];
            digit[1]=digit[3];
            digit[3]=tempdigit;
         }
         x1[dataline]=digit[0];
         x2[dataline]=digit[0];
         x3[dataline]=digit[0];
         y1[dataline]=digit[1];
         y2[dataline]=digit[2];
         y3[dataline]=digit[3];
         break;
      case 6:
         if (digit[0] > digit[2]) {
            tempdigit= digit[0];
            digit[0]= digit[2];
            digit[2]= tempdigit;
         }
         if (digit[3] > digit[5]) {
            tempdigit= digit[3];
            digit[3]= digit[5];
            digit[5]= tempdigit;
         }
         x1[dataline]=digit[0];
         x2[dataline]=digit[1];
         x3[dataline]=digit[2];
         y1[dataline]=digit[3];
         y2[dataline]=digit[4];
         y3[dataline]=digit[5];
         break;
      default:
         return 0;
   }
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d dataline=%d datacolumns=%d: %8.2lf %8.2lf %8.2lf;  %8.2lf %8.2lf %8.2lf",
      __LINE__, dataline, data_columns, x1[dataline], x2[dataline], x3[dataline],
      y1[dataline], y2[dataline], y3[dataline]);
#endif
   return data_columns;
}

int numbers_per_line(char *s) {
   int p, pos=0, len, n=0;
   char number[81];
   len=strlen(s);
   do {
      while (isdelimiter(s[pos]) && pos < len) pos++;
      if (pos >= strlen(s)) break;
      p=0;
      while (!isdelimiter(s[pos]) && pos<strlen(s)) number[p++]=s[pos++];
      number[p]='\0';
#ifdef TRACE
      if (Trace) fprintf(tracefile,"\n%4d isnumber(\"%s\")=%d",__LINE__,number,isnumber(number));
#endif
      if (isnumber(number)) n++;
      else n=0;
   } while (pos<len);
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d numbers in line \"%s\" : %d",__LINE__,s,n);
#endif
   return n;
}

int isdecimal(char c) {
   if (isdigit(c) ||
       c=='.'     ||
       c=='+'     ||
       c=='-') return 1;
   else return 0;
}

int isdelimiter(char c) {
   return (isspace(c) || c==',' || c==';');
}

int isnumber(char *s) {
int n, len=strlen(s);
   if (!len)                                        return 0;
   for (n=0; n<len ; n++)
      if (!(isdecimal(s[n])))                       return 0;
   if (s[len]=='.')                                 return 0;
   for (n=1;n<len;n++) if (s[n]=='+' || s[n]=='-')  return 0;
   for (n=0;n<len-1;n++) if (s[n]=='.')  
      for (n++;n<len-1;n++) if (s[n]=='.')          return 0;
   return 1;
}

char *stripwhites(char *s) {
   int p, len;
   char *s2;
   s2=s;
   for (p=0;isspace(s[p]) && p<strlen(s);s2++)
      ;
   for (p=strlen(s2)-1;isspace(s2[p]) && p;p--) s2[p]='\0';
   if (*s2==QUOTE){
      s2++;
      len=strlen(s2);
      if (s2[len-1]==QUOTE) s2[len-1]='\0';
   }
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d stripwhites \"%s\"=\"%s\"",__LINE__,s,s2);
#endif
   strcpy(s,s2);
   return s;
}

int fgetline(char *s,int i,FILE *fpin) {
   char c;
   int skip=FALSE, pos=0, non_whites=0;
   while((c=fgetc(fpin))!=EOF && c!='\r' && c!='\n' && pos<i ) {
      if (c==26) {
         c=EOF;
         break;
      }
      if (non_whites==0 && c=='\\') skip=TRUE;
      if (c!=' ' && c!='\t') {
         if (!isprint(c)) {
            E2;
            farewell(-1);
         }
         non_whites ++;
         s[pos]=c;
         pos++;
      } else if (pos) {
         s[pos]=c;
         pos++;
      }
   }
   while((c=fgetc(fpin))!=EOF && (c=='\r' || c=='\n'))
      ;
   ungetc(c,fpin);
   s[pos]='\0';
   if (non_whites==0 && c==EOF) return EOF;
   if (skip) return 0;
   else return non_whites;
}

void picdot(int x,int y, int type, int size) {
   int ybase, dx,dy,r=size/2, t;
   char buffer[2]=" ";
   if (type>=' ' && type<127) {
      *buffer=type;
      picsize(2*size, size*18/8);
      picmove(x,y);
      pictext(0,CENTER,buffer);
      picsize(Hsize,Vsize);
      return;
   }
   t=symbolstring[type%strlen(symbolstring)];
   if (t=='L') return;
   if (t=='B') {
      ybase=y_origin;
      if (ymin < 0 && (!logyflag || (logyflag && Y1line))) ybase-=ymin * scale_yfactor;
      picmove(x-size, ybase);
      picdraw(x-size, y);
      picdraw(x+size, y);
      picdraw(x+size, ybase);
      picdraw(x-size, ybase);
      return;
   }
   #ifdef TRACE
      if (Trace==2) fprintf(tracefile,"\n%4d: type=%d symbolstring=%s t=%d size=%d",
      __LINE__, type, symbolstring, t, size);
   #endif
   switch(t) {
      case '0':                     /* open circle */
         picmove(x,y+r);
         for (dy=r; dy > -r; dy -= PIXELS_PER_LINE) {
            dx= sqrt((long)r*r-(long)dy*dy);
            picdraw(x+dx,y+dy);
         }
         for ( ; dy <= r; dy+= PIXELS_PER_LINE) {
            dx= sqrt((long)r*r-(long)dy*dy);
            picdraw(x-dx,y+dy);
         }
         break;
      case '1':                     /* filled circle */
         for (dy=r; dy > -r; dy -= PIXELS_PER_LINE) {
            dx= sqrt((long)r*r-(long)dy*dy);
            picmove(x-dx,y+dy);
            picdraw(x+dx,y+dy);
         }
         break;
      case '2':                     /* open square */
         picmove(x-r,y+r);
         picdraw(x+r,y+r);
         picdraw(x+r,y-r);
         picdraw(x-r,y-r);
         picdraw(x-r,y+r);
         break;
      case '3':                     /* filled square */
         for (dy=r; dy > -r; dy -= PIXELS_PER_LINE) {
            picmove(x-r,y+dy);
            picdraw(x+r,y+dy);
         }
         break;
      case '4':                     /* open triangle */
         picmove(x  ,y+r);
         picdraw(x-r,y-r);
         picdraw(x+r,y-r);
         picdraw(x  ,y+r);
         break;
      case '5':                     /* filled triangle */
         for (dx=0,dy=r; dx <= r ; dx+= PIXELS_PER_LINE/2, dy -= PIXELS_PER_LINE) {
            picmove(x-dx,y+dy);
            picdraw(x+dx,y+dy);
         }
         break;
      case '6':                     /* upside_down triangle, open */
         picmove(x-r,y+r);
         picdraw(x+r,y+r);
         picdraw(x  ,y-r);
         picdraw(x-r,y+r);
         break;
      case '7':                     /* upside_down triangle, filled */
         for (dx=0,dy=-r; dx <= r ; dx+= PIXELS_PER_LINE/2, dy+= PIXELS_PER_LINE) {
            picmove(x-dx,y+dy);
            picdraw(x+dx,y+dy);
         }
         break;
      case '8':                     /* star */
         picmove(x-r,y-r);
         picdraw(x+r,y+r);
         picmove(x+r,y-r);
         picdraw(x-r,y+r);
         picmove(x-r,y);
         picdraw(x+r,y);
         break;
      case '9':                     /* vertical line */
         picmove(x,y+r);
         picdraw(x,y-r);
         break;
     default:                       /* ASCII-karakter */
        buffer[1]='\0';
        buffer[0]=t;
        picsize(15*r, 12*r);
        picmove(x,y);
        pictext(0, CENTER, buffer);
        picsize(Hsize, Vsize);
      }
}

void picdotted_line(int x0, int y0, int x, int y, int type) {
#define SIZE1 8.0
#define SIZE2 32.0
#define SIZE3 40.0
#define SIZE4 64.0
   int t, i, ddx, ddy;
   double dx, dy, size, xpos, ypos, xfactor, yfactor;
   t=linetypestring[type%strlen(linetypestring)]-'0';
   dx=(double)(x-x0);
   dy=(double)(y-y0);
   size=sqrt(dx*dx+dy*dy);
   if (!size) return;
   xfactor=dx/size;
   yfactor=dy/size;
   xpos=(double)x0;
   ypos=(double)y0;
   switch (t) {
      case 1: /* ________ */
         while (picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y));
         break;
      case 2: /* ........ */
         while (picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y));
      case 3: /* _._._._. */
         do {
            i=       picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i=picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
         } while (i);
         break;
      case 4: /*.. _..._. */
         do {
            i=        picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
         } while (i);
         break;
      case 5: /* ======= */
         ddx=(int)(6.0*yfactor);
         ddy=(int)(6.0*xfactor);
         picmove(x0+ddx ,y0-ddy);
         picdraw(x +ddx, y -ddy);
         picmove(x0-ddx, y0+ddy);
         picdraw(x -ddx, y +ddy);
         break;
      case 6: /* = = = = = = */
         xpos=x0+6.0*yfactor;
         ypos=y0-6.0*xfactor;
         while (picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x+6.0*yfactor, (double) y-6.0*xfactor));
         xpos=x0-6.0*yfactor;
         ypos=y0+6.0*xfactor;
         while (picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x-6.0*yfactor, (double) y+6.0*xfactor));
         break;
      case 7: /* :::::: */
         xpos=x0+6.0*yfactor;
         ypos=y0-6.0*xfactor;
         while (picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x+6.0*yfactor, (double) y-6.0*xfactor));
         xpos=x0-6.0*yfactor;
         ypos=y0+6.0*xfactor;
         while (picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x-6.0*yfactor, (double) y+6.0*xfactor));
         break;
      case 8: /* =:::=::: */
         xpos=x0+6.0*yfactor;
         ypos=y0-6.0*xfactor;
         do {
            i=        picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
         } while (i);
         xpos=x0-6.0*yfactor;
         ypos=y0+6.0*xfactor;
         do {
            i=        picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
         } while (i);
         break;
      case 9: /* _.._.._.. */
         do {
            i=        picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
         } while (i);
         break;
      case 10: /* __..__.. */
         do {
                   i= picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE4, SIZE2, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
            if (i) i= picdotdot( SIZE1, SIZE3, xfactor, yfactor, &xpos, &ypos, (double) x, (double) y);
         } while (i);
         break;
      case 0:
      default:
         picmove(x0,y0);
         picdraw(x,y);
         break;
   }
}
 
int picdotdot(
      double step1,
      double step2,
      double xfactor,
      double yfactor,
      double *xpos,
      double *ypos,
      double xlim,
      double ylim) {
   int hor, vert;
   double dx, dy;
   hor=(*ypos==ylim);
   vert=(*xpos==xlim);
   if (hor && vert) return 0;
   picmove((int)*xpos, (int)*ypos);
   dx=xfactor * step1;
   dy=yfactor * step1;
  *xpos=(
      (dx>0 && *xpos+dx>xlim) ||
      (dx<0 && *xpos+dx<xlim)) ?
         xlim:
         *xpos+dx;
   *ypos=(
      (dy>0 && *ypos+dy>ylim) ||
      (dy<0 && *ypos+dy<ylim)) ?
         ylim:
         *ypos+dy;
   picdraw((int)*xpos, (int)*ypos);
   if ((!vert && *xpos==xlim) || (!hor && *ypos==ylim)) return 0;
   dx=xfactor * step2;
   dy=yfactor * step2;
   *xpos=(
      (dx>0 && *xpos+dx>xlim) ||
      (dx<0 && *xpos+dx<xlim)) ?
         xlim:
         *xpos+dx;
   *ypos=(
      (dy>0 && *ypos+dy>ylim) ||
      (dy<0 && *ypos+dy<ylim)) ?
         ylim:
         *ypos+dy;
   if ((!vert && *xpos==xlim) || (!hor && *ypos==ylim)) return 0;
   return 1;
}

int picbottomline(int n) {
   return(Y_ORIGIN+n*Vsize);
}

int pictopline(int n) {
    return PICTOP-n*Vsize;
}

void plot_point(int column, int range_number, int bar) {
   int xxx1,xxx2,xxx3,yyy1,yyy2,yyy3,d;
   xxx1=(xx1!=MISSING)? x_origin + ( xx1 - xmin ) * scale_xfactor:MISSING;
   xxx2=(xx2!=MISSING)? x_origin + ( xx2 - xmin ) * scale_xfactor:MISSING;
   xxx3=(xx3!=MISSING)? x_origin + ( xx3 - xmin ) * scale_xfactor:MISSING;
   yyy1=(yy1!=MISSING)? y_origin + ( yy1 - ymin ) * scale_yfactor:MISSING;
   yyy2=(yy2!=MISSING)? y_origin + ( yy2 - ymin ) * scale_yfactor:MISSING;
   yyy3=(yy3!=MISSING)? y_origin + ( yy3 - ymin ) * scale_yfactor:MISSING;
   if (log0 && !x2[column] && !bar) xxx1=xxx2=xxx3=x_origin-log0;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d range %3d:%20s %4d %4d %4d    %4d %4d %4d",__LINE__,range_number, range_name[range_number], xxx1,xxx2,xxx3,yyy1,yyy2,yyy3);
#endif
   if (xxx2!=MISSING && yyy2!=MISSING) {
      if (xllflag && xxx2<xll) xxx2=xll-Symbol_size;
      if (xulflag && xxx2>xul) xxx2=xul+Symbol_size;
      if (yllflag && yyy2<yll) yyy2=yll-Symbol_size;
      if (yulflag && yyy2>yul) yyy2=yul+Symbol_size;
      picdot(xxx2 , yyy2, range_number, Symbol_size);
      if (yyy1!=MISSING && (d=yyy2-yyy1)>Symbol_size/2 && d>0 && !yllflag && !yulflag) {
         picmove(xxx2, yyy1);
         picdraw(xxx2, yyy2-Symbol_size/2);
         picmove(xxx2-Cap/2, yyy1);
         picdraw(xxx2+Cap/2, yyy1);
      }
      if (yyy3!=MISSING && (d=yyy3-yyy2)>Symbol_size/2 && d>0 && !yllflag && !yulflag) {
         picmove(xxx2, yyy2+Symbol_size/2);
         picdraw(xxx2, yyy3);
         picmove(xxx2-Cap/2, yyy3);
         picdraw(xxx2+Cap/2, yyy3);
      }
      if (xxx1!=MISSING && (d=xxx2-xxx1)>Symbol_size/2 && d>0 && !xllflag && !xulflag) {
         picmove(xxx1, yyy2);
         picdraw(xxx2-Symbol_size/2, yyy2);
         picmove(xxx1, yyy2-Cap/2);
         picdraw(xxx1, yyy2+Cap/2);
      }
      if (xxx3!=MISSING && (d=xxx3-xxx2)>Symbol_size/2 && d>0 && !xllflag && !xulflag) {
         picmove(xxx2+Symbol_size/2, yyy2);
         picdraw(xxx3, yyy2);
         picmove(xxx3, yyy2-Cap/2);
         picdraw(xxx3, yyy2+Cap/2);
      }
   }
}

void draw_line(int n, float xmin, double scale_xfactor, float ymin, double scale_yfactor) {
   int column, x, y, xxx, yyy;
   double a;
   column=range_start[n];
   xx2=x2[column];
   yy2=y2[column];
   if (xx2!=MISSING && yy2!=MISSING) {
      if (logxflag) xx2=(xx2>0)?log(xx2):0;
      if (logyflag) yy2=(yy2>0)?log(yy2):MISSING;
   }
   if (xx2!=MISSING && yy2!=MISSING) {
      if (log0 && xx2==0) {
         x= x_origin-log0;
         y= y_origin + (yy2-ymin) * scale_yfactor;
         if (yllflag && y<yll) y=yll-Symbol_size;
         if (yulflag && y>yul) y=yul+Symbol_size;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d %s:move x=%d y=%d yy2=%.3f y2[%d]=%.3f",
      __LINE__, __FILE__, x, y, yy2, column, y2[column]);
#endif
         for (column++; column<range_start[n]+range_size[n] && x2[column]==MISSING; column++)
            ;
         if (column<range_start[n]+range_size[n] ) {
            xx2=x2[column];
            yy2=y2[column];
            if (xx2!=MISSING && yy2!=MISSING) {
               if (logxflag) xx2=(xx2>0)?log(xx2):MISSING;
               if (logyflag) yy2=(yy2>0)?log(yy2):MISSING;
            }
            xxx=x_origin + (xx2-xmin) * scale_xfactor;
            yyy=y_origin + (yy2-ymin) * scale_yfactor;
            if (xllflag && xxx<xll) xxx=xll-Symbol_size;
            if (xulflag && xxx>xul) xxx=xul+Symbol_size;
            if (yllflag && yyy<yll) yyy=yll-Symbol_size;
            if (yulflag && yyy>yul) yyy=yul+Symbol_size;
            a=(xxx-x>0)?(double)(yyy-y)/(xxx-x):0;
#ifdef TRACE
            if (Trace) fprintf(tracefile,"\n%4d %s:move a=%.3lf",
                __LINE__, __FILE__, a);
#endif
            if (a) {
               picdotted_line(x, y, x_origin-log0/2, y+a*log0/2, n);
               x=x_origin;
               y=y+a*log0;
            } else {
               picdotted_line(x, y, x_origin-log0/2, y, n);
               x=x_origin;
            }
            if (xxx-x_origin>SYMBOL_SIZE/2) {
               picdotted_line(x, y, xxx, yyy, n);
               x=xxx;
               y=yyy;
            }
            column++;
         }
      } else {
         xx2=x2[column];
         yy2=y2[column];
         if (xx2!=MISSING && yy2!=MISSING){
            if (logxflag) xx2=(xx2>0)?log(xx2):MISSING;
            if (logyflag) yy2=(yy2>0)?log(yy2):MISSING;
         }
         x= x_origin + (xx2-xmin) * scale_xfactor;
         y= y_origin + (yy2-ymin) * scale_yfactor;
         if (xllflag && x<xll) x=xll-Symbol_size;
         if (xulflag && x>xul) x=xul+Symbol_size;
         if (yllflag && y<yll) y=yll-Symbol_size;
         if (yulflag && y>yul) y=yul+Symbol_size;
         column++;
      }
      for ( ; column<range_start[n]+range_size[n]; column++) {
         xx2=x2[column];
         yy2=y2[column];
         if (xx2!=MISSING && yy2!=MISSING) {
            if (logxflag) xx2=(xx2>0)?log(xx2):MISSING;
            if (logyflag) yy2=(yy2>0)?log(yy2):MISSING;
         }
         xxx= x_origin + (xx2-xmin) * scale_xfactor;
         yyy= y_origin + (yy2-ymin) * scale_yfactor;
         if (xllflag && x<xll) xxx=xll-Symbol_size;
         if (xulflag && x>xul) xxx=xul+Symbol_size;
         if (yllflag && y<yll) yyy=yll-Symbol_size;
         if (yulflag && y>yul) yyy=yul+Symbol_size;
         picdotted_line(x, y, xxx, yyy, n);
         x=xxx;
         y=yyy;
      }
   }
}

void draw_xy(int x_origin, float xmin, float xmax, double scale_xfactor, int y_origin, float ymin, float ymax, double scale_yfactor) {
   float x1, x2, y1, y2;
   x1= (xmin<ymin) ? ymin:xmin;
   y1= x1;
   x2= (xmax<ymax) ? xmax:ymax;
   y2= x2;
   picmove(x_origin + (x1-xmin) * scale_xfactor, y_origin + (y1-ymin) * scale_yfactor);
   picdraw(x_origin + (x2-xmin) * scale_xfactor, y_origin + (y2-ymin) * scale_yfactor);
}

int picx_cal(int logflag) {
   int n, month, pos, cal, mantissa, lowest_exponent, highest_exponent;
   int oy, ly;
   char name[10];
   double calibrator_value;
   if (Xformat!=2) {
      logxflag= ascal(&noofcalibrators, &xmin, &xmax, logflag, 1, Xformat);
      xmin=(logxflag)?log(xmin):xmin;
      xmax=(logxflag)?log(xmax):xmax;
   } else {
      logxflag= 0;
      xmin= (int) xmin;
      xmax= ceil(xmax);
   }
   if (Ycal/3==0) {
      oy=y_origin-Rim;
      ly=y_length + Rim + ((Xcal==0)?Rim:0);
   } else {
      oy=y_origin;
      ly=y_length;
   }
   scale_xfactor=(double)x_length/(xmax - xmin);
   for (n=0;n<Plotter;n++) {
      if (Xformat==1) picmove(x_origin-log0,oy - Vsize*1.5-40);
      else picmove(x_origin-log0,oy - Vsize-40);
      pictext(0, TOPLEFT, x_legend);
   }
   if (log0) {
      picmove(x_origin-log0,  oy+Rim/2);
      picdraw(x_origin-log0,  oy);
      picdraw(x_origin-log0/2,oy);
      if (Ycal%3==0) {
         picmove(x_origin-log0/2,oy+ly);
         picdraw(x_origin-log0,  oy+ly);
         picdraw(x_origin-log0,  oy+ly-Rim/2);
      }
      else if (Ycal%3==1) {
         picmove(x_origin,oy+ly);
         picdraw(x_origin-log0-(Xcal==0?Rim/2:0),oy+ly);
      }
      picmove(x_origin-log0,oy-Vsize);
      pictext(0, CENTERBOTTOM, "0");
   }
   picmove(x_origin   , oy);
   picdraw(x_origin+x_length, oy);
   if (Ycal%3<2) {
      picmove(x_origin,    oy+ly);
      picdraw(x_origin+x_length, oy+ly);
   }
   if (Ycal%3==1) {
      picmove(x_origin         - (Xcal<3 ?Rim/2:0), oy+ly);
      picdraw(x_origin+x_length+ (Xcal==0?Rim/2:0), oy+ly);
   }
   if (Xformat<2) for (cal=0; cal<noofcalibrators; cal++) {
      calibrator_value=value_of_calibrator[cal];
      pos= x_origin + scale_xfactor * (calibrator_value-xmin);
      if (abs(x_origin+x_length-pos)<=5) pos=x_origin+x_length;
      for (n=0;n<Plotter;n++) {
         if (Vgrid) {
            picmove(pos, oy);
            picdraw(pos, oy+ly);
         } else {
            picmove(pos,oy+Rim/2);
            picdraw(pos,oy);
            if (Ycal%3==0) {
               picmove(pos,oy+ly);
               picdraw(pos,oy+ly-Rim/2);
            }
         }
         picmove(pos,oy-Vsize);
         if (!logxflag || !Xformat) pictext(0, CENTERBOTTOM, calibratorstring[cal]);
         else {
            pictext(0,BOTTOMRIGHT,"10");
            picmove(pos,oy-0.8*Vsize);
            pictext(0,BOTTOMLEFT,calibratorstring[cal]);
         }
      }
   } else {
      for (month=(int) xmin; month<=ceil(xmax); month++) {
         pos= x_origin + scale_xfactor * (month-(int)xmin);
         if (abs(x_origin+x_length-pos)<=5) pos=x_origin+x_length;
         for (n=0;n<Plotter;n++) {
            if (Vgrid) {
               picmove(pos, oy);
               picdraw(pos, oy+ly);
            } else {
               picmove(pos,oy+Rim/2);
               picdraw(pos,oy);
               if (Ycal%3==0) {
                  picmove(pos,oy+ly);
                  picdraw(pos,oy+ly-Rim/2);
               }
            }
            picmove(pos,oy-Vsize);
            if (find_monthname(name, month, scale_xfactor)) pictext(0, CENTERBOTTOM, name);
         }
      }
      for (month=12; month<ceil(xmax); month+=12) {
         if (month < xmin) continue;
         pos= x_origin + scale_xfactor * ((float) month - xmin + 0.5);
         if (abs(x_origin+x_length-pos)<=5) pos=x_origin+x_length;
         for (n=0;n<Plotter;n++) {
            picmove(pos,oy - Vsize);
            picdraw(pos,oy+ly);
         }
      }
   }
   if (logxflag) {
      highest_exponent=(int)(xmax/log(10)+0.001);
      lowest_exponent=(int)(xmin/log(10)-1.1);
      for (cal=lowest_exponent; cal<=highest_exponent; cal++) {
         for (mantissa=1;mantissa<10;mantissa++) {
            calibrator_value= log(val((double)mantissa,cal));
            if (calibrator_value > xmin && calibrator_value < xmax) {
               pos= x_origin + scale_xfactor * (calibrator_value-xmin);
               if (pos<x_origin-5 || pos>x_origin+ x_length+5) continue;
               if (abs(x_origin+x_length-pos)<=5) pos=x_origin+x_length;
               for (n=0;n<Plotter;n++) {
                  if (Vgrid) {
                     picmove(pos, oy);
                     picdraw(pos, oy+ly);
                  } else {
                     picmove(pos, oy);
                     picdraw(pos, oy+Rim/4);
                     if (Ycal%3==0) {
                        picmove(pos, oy+ly);
                        picdraw(pos, oy+ly-Rim/4);
                     }
                  }
               }
            }
         }
      }
   }
   return logxflag;
}

char *find_monthname(char *name, int month, double size_per_month) {
   int len;
   if (size_per_month>11*Hsize/2) len=10;
   else if (size_per_month>4*Hsize/2) len=3;
   else len=1;
   if (size_per_month<Hsize/2 && (month)%3!=1) return 0;
   strncpy(name, monthname[month%12], len);
   name[len]='\0';
   return name;
}

int picy_cal(int logflag) {
   int n, pos, cal, logyflag, mantissa, lowest_exponent, highest_exponent;
   int ox, lx;
   double calibrator_value;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d picy_cal ymin=%.4f ymax=%.4f",
       __LINE__, ymin, ymax);
#endif
   logyflag= ascal(&noofcalibrators, &ymin, &ymax, logflag, TRUE, Yformat);
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d logflag=%d picy_cal ymin=%.4f ymax=%.4f",
       __LINE__, logflag, ymin, ymax);
#endif
   ymin=(logyflag)?log(ymin):ymin;
   ymax=(logyflag)?log(ymax):ymax;

   if (Xcal/3==0) {
      ox=x_origin - Rim;
      lx=x_length + Rim + ((Ycal==0)?Rim:0);
   }else {
      ox=x_origin;
      lx=x_length;
   }
   scale_yfactor=(double)y_length/(ymax - ymin);
   for (n=0;n<Plotter;n++) {
      picmove(ox,y_origin   );
      picdraw(ox,y_origin+y_length);
      if (Xcal%3<2) {
         picmove(ox+lx+log0,y_origin   );
         picdraw(ox+lx+log0,y_origin+y_length);
      }
      if (Xcal%3==1) {
         picmove(ox+lx+log0,y_origin-(Ycal<3?Rim/2:0));
         picdraw(ox+lx+log0,y_origin+y_length+(Ycal==0?Rim/2:0));
      }
   }
   picsize(Hsize,Vsize);
   for (cal=0; cal<noofcalibrators; cal++) {
      calibrator_value=value_of_calibrator[cal];
      pos= (cal==noofcalibrators-1)?y_origin+y_length: y_origin + scale_yfactor * (calibrator_value-ymin);
      for (n=0;n<Plotter;n++) {
         if (Hgrid) {
            picmove(ox, pos);
            picdraw(ox + lx+log0,pos);
         } else {
            picmove(ox,pos);
            picdraw(ox+Rim/2,pos);
            if (Xcal%3==0) {
               picmove(ox + lx+log0,pos);
               picdraw(ox + lx+log0-Rim/2,pos);
            }
         }
         picmove(ox-Rim/2,pos);
         pictext(0,CENTERRIGHT,calibratorstring[cal]);
      }
   }
   if (logyflag) {
      highest_exponent=(int)(ymax/log(10)+0.001);
      lowest_exponent =(int)(ymin/log(10)-1.1);
#ifdef TRACE
      if (Trace) fprintf(tracefile,"\n%4d: highest exponent:%d lowest exponent:%d",
         __LINE__, highest_exponent, lowest_exponent);
#endif
      for (cal=lowest_exponent; cal<=highest_exponent; cal++) {
         for (mantissa=1;mantissa<10;mantissa++) {
            calibrator_value = log(val((double)mantissa,cal));
            if (calibrator_value > ymin && calibrator_value < ymax) {
               pos= y_origin + scale_yfactor * (calibrator_value-ymin);
               if (pos<y_origin-5 || pos>y_origin + y_length+5) continue;
               if (abs(y_origin+y_length-pos)<=5) pos=y_origin+y_length;
               for (n=0;n<Plotter;n++) {
                  if (Hgrid) {
                     picmove(ox,pos);
                     picdraw(ox+lx+log0,pos);
                  } else {
                     picmove(ox,pos);
                     picdraw(ox+Rim/4,pos);
                     if (Xcal%3==0) {
                        picmove(ox+lx+log0,pos);
                        picdraw(ox+lx+log0-Rim/4,pos);
                     }
                  }
               }
            }
         }
      }
   }
   return logyflag;
}

int picy_axis_title(char *y_axis_string, int y_pos) {
   picsize(Hsize,Vsize);
   picmove(0,y_pos);
   return pictextlines(0, y_pos, y_axis_string, 1, TOPRIGHT);
}

int ascal(int *noofcalibrators, float *min, float *max, int logflag, int calcflag, int expflag) {
    int n, range, exp, exp0, t, t0, found, negative, precision, extra_decimal=0;
    double unit, value, tempmin, tempmax, ratio, base, lowest_calibrator;
    int exponent[MAXNOOFCALIBRATORS];
    if (logflag) round(scientific2(*min, &base, &exp));
    else round(scientific2(*max, &base, &exp));
    tempmin=*min * 10 +  fabs(*min)/10000;
    tempmax=*max * 10 -  fabs(*max)/10000;
    lowest_calibrator=val(10,exp);
    for (n=0;n<MAXNOOFCALIBRATORS;n++) {
        *calibratorstring[n]='\0';
        value_of_calibrator[n]=MISSING_CALIBRATOR;
    }

    if (logflag && tempmax<=0) logflag=FALSE;
    if (logflag) {
        if (tempmin<=0) tempmin= lowest_calibrator;
        ratio= (double)(tempmax / tempmin);
        if (ratio < 51 )       range= SMALL;
        else if (ratio < 301 ) range= MEDIUM;
        else                   range= LARGE;
    } else range=LINEAR;
    t=t0=0;
    found=FALSE;
    do{
       exp0=--exp;
       unit=val(calbase[range][t],exp);
    } while (3*unit>=tempmax-tempmin);
    while (!found) {
       if (! logflag) {
          found= ( 6*unit >= tempmax - tempmin);
          if (!found) {
             t++;
             t%=range+1;
             if (t==0) exp++;
             unit=val(calbase[range][t],exp);
          }
          if (found && t==2) extra_decimal=1;
       } else {
           value=val((double)calbase[range][t],exp+1);
           found= (value >= tempmin);
           if (!found) {
             t0=t;
             exp0=exp;
             t++;
             t%=range+1;
             if (t==0) exp++;
           } else {
             t=t0;
             exp=exp0;
             value=val((double)calbase[range][t],exp+1);
          }
       }
    }

PHASE2: /* find corrected min and max and fill array */
    if (!logflag) {
       if ( tempmin/unit-(int)(tempmin/unit) != 0) {
          negative= ( tempmin < 0);
          tempmin=  unit * (int)(tempmin/unit);
          if (negative) tempmin -= unit;
       }
    } else tempmin=val((double)calbase[range][t],exp+1);
    for (n=0 ; n < MAXNOOFCALIBRATORS ; n++) {
        if ( ! logflag ) {
           value_of_calibrator[n]=(tempmin + n*unit)/10;
           exponent[n]=exp;
        } else {
           exponent[n]= exp;
           value_of_calibrator[n]= val((double)calbase[range][t],exp);
           t++;
           t%=range+1;
           if (t==0) exp++;
        }
        if (value_of_calibrator[n] >= tempmax/10) {
            tempmax= value_of_calibrator[n]*10;
            *noofcalibrators=n+1;
            break;
        }
    }
    *min=tempmin/10;
    *max=tempmax/10;
    if (!calcflag) return logflag;

/* phase 3: print results in minimal-length strings */

    for (n=0; n< *noofcalibrators ; n++) {
        if (logflag && expflag) sprintf(calibratorstring[n],"%d",exponent[n]);
        else {
           if (value_of_calibrator[n]>(*max>0?1.0001* *max:0.9999* *max)) {
#ifdef TRACE
              if (Trace) fprintf(tracefile,"\ncal[%d]=%.4lf *max=%.4lf verschil:%lf",
                 n, value_of_calibrator[n], *max, value_of_calibrator[n] - *max);
#endif
              break;
           }
           precision= (range==LINEAR) ? (extra_decimal - exponent[n]): -exponent[n];
           if (precision<0) precision=0;
           sprintf(calibratorstring[n],"%.*lf", precision, value_of_calibrator[n]);
#ifdef TRACE
           if (Trace) fprintf(tracefile, "\n%4d : precision=%d exponent[%d]=%d range=%d extra_decimal=%d string %d: %s",__LINE__, precision, n, exponent[n], range, extra_decimal, n, calibratorstring[n]);
#endif
       }
    }
/* phase 4: if (logflag) transform data */

   if (logflag) for (n=0; n<*noofcalibrators; n++) value_of_calibrator[n]=log(value_of_calibrator[n]);

/* return logflag to indicate whether log-transformation was actually performed */

    return logflag;
}

double scientific2(double d, double *base, int *exp) {
   double logd;
   int neg=FALSE;
   if (d==0) {
      *base=0;
      *exp=-1;
      return *base;
   }
   if (d<0) {
      neg=1;
      d=-d;
   }
   logd=log10(d);
   *exp= (int)logd - (d<1)-1;
   *base= pow10d(logd-*exp);
   if (neg) *base=-*base;
   return *base;
}

double val(double mantissa, int exponent) {
   return mantissa*pow10(exponent);
}

int round(double d) {
    int i=(int)d;
    if (d-i<.5 ) return (int)(d+.5);
    return (int)(d+1);
}

double pow10d(double exponent) {
   /* 10^exponent, exponent is double rather than int, as required for pow() */
   return exp(exponent*log(10));
}


int strpos(char *s,char c,int pos) {
/* finds next occurrence of c in s starting at pos */
int p;
     for (p=pos+1;s[p];p++) if (s[p]==c) return p;
     for (p=0;p<=pos;p++) if (s[p]==c) return p;
     return -1;
}

void read_environment(void) {
   char *s;
   startup_drive=getdisk();
   s=getenv("COLOR");
   if (!s) s=getenv("COLOUR");
   if (s) Color=atoi(s);
   else Color=COLOR;
   Color--;
   if (Color<0) Color=0;
   if (Color>5) Color=5;
   s=getenv("INPUT_PATH");
   if (!s) s=getenv("INPUT");
   if (s) strcpy(Input_path,s);
   s=getenv("OUTPUT_PATH");
   if (!s) s=getenv("OUTPUT");
   s=getenv("SYMBOLSTRING");
   if (s) strncpy(symbolstring,s,19);
   s=getenv("TEXT0");
   if (s) strcpy(extra_text[0],s);
   s=getenv("TEXT1");
   if (s) strcpy(extra_text[1],s);
   s=getenv("TEXT2");
   if (s) strcpy(extra_text[2],s);
   s=getenv("TEXT3");
   if (s) strcpy(extra_text[3],s);
   s=getenv("TEXT4");
   if (s) strcpy(extra_text[4],s);
   s=getenv("TEXT5");
   if (s) strcpy(extra_text[5],s);
   s=getenv("TEXT6");
   if (s) strcpy(extra_text[6],s);
   s=getenv("TEXT7");
   if (s) strcpy(extra_text[7],s);
   s=getenv("TEXT8");
   if (s) strcpy(extra_text[8],s);
   s=getenv("TEXT9");
   if (s) strcpy(extra_text[9],s);
   if (s) strcpy(Output_path,s);
   s=getenv("PLOTTER");
   if (s) Plotter=atoi(s);
   else Plotter=PLOTTER;
#ifdef TRACE
   Trace=(int)set_env_variable("TRACE", TRACE);
#endif
   Show=(int)set_env_variable("SHOW", SHOW);
   Xformat=(int)set_env_variable("XFORMAT", XFORMAT);
   Xcal=(int)set_env_variable("XCAL",XCAL);
   Ycal=(int)set_env_variable("YCAL",YCAL);
   Rim=(int)set_env_variable("RIM",RIM);
   Yformat=(int)set_env_variable("YFORMAT", YFORMAT);
   Data_columns=(int)set_env_variable("DATA_COLUMNS", 0);
   Legend= set_env_variable("LEGEND", LEGEND);
   Legendpos= set_env_variable("LEGENDPOS", LEGENDPOS);
   Logxflag= set_env_variable("XLOG", LOGXFLAG);
   Logyflag= set_env_variable("YLOG", LOGYFLAG);
   Hgrid= set_env_variable("HGRID", HGRID);
   Vgrid= set_env_variable("VGRID", VGRID);
   Line= set_env_variable("LINE", LINE);
   Textsize=(int)set_env_variable("TEXTSIZE",TEXTSIZE);
   Xy= set_env_variable("XY", XY);
   Y1line= set_env_variable("Y1", Y1LINE);
   Cap= set_env_variable("CAP", CAP);
   Symbol_size= set_env_variable("SYMBOL_SIZE", SYMBOL_SIZE);
   X_length= set_env_variable("X_LENGTH", X_LENGTH);
   if (X_length>X_LENGTH || X_length<=0) X_length=X_LENGTH;
   Y_length=set_env_variable("Y_LENGTH", Y_LENGTH);
   if (Y_length>Y_LENGTH || Y_length<=0) Y_length=Y_LENGTH;
   if (Symbol_size==SYMBOL_SIZE) Symbol_size=     set_env_variable("SIZE",        SYMBOL_SIZE);
   Xmax= set_env_variable("XHIGH", MISSING);
   if (Xmax==MISSING) Xmax= set_env_variable("XMAX",  MISSING);
   Xmin= set_env_variable("XMIN",MISSING);
   if (Xmin==0) Xmin= set_env_variable("XMIN",  0);
   Ymax= set_env_variable("YHIGH",MISSING);
   if (Ymax==MISSING) Ymax= set_env_variable("YMAX", MISSING);
   Ymin= set_env_variable("YMIN",MISSING);
   if (Cap<0) Cap=0;
   if (Cap>400) Cap=400;
   if (Legend<0) Legend=0;
   if (Legend >8) Legend=8;
   if (Symbol_size<0) Symbol_size=0;
   if (Symbol_size>400) Symbol_size=400;
   if (Plotter>10 || Plotter <1) Plotter=PLOTTER;
   if (Xformat==2) {
      Logxflag= 0;
      if (Xmin==0) Xmin=1;
   }
}

float set_env_variable(char *env_string, float default_value) {
   char *s;
   s=getenv(env_string);
   if (s==0)			return default_value;
   if (!stricmp(s,"AUTO"))	return MISSING;
   if (!stricmp(s,"MISSING"))	return MISSING;
   if (!stricmp(s,"OFF"))	return 0;
   if (!stricmp(s,"FALSE"))	return 0;
   if (!stricmp(s,"ON"))	return 1;
   if (!stricmp(s,"TRUE"))	return 1;
   return atof(s);
}

#ifdef TRACE
void print_environment(FILE *outfile) {
   fprintf(outfile, "%4d %s %s\n"
      "Trace         %4d\n"
      "Show          %4d\n"
      "Data_columns  %4d\n"
      "Xmax         %13.2lf\n"
      "Xmin          %13.2lf\n"
      "Ymax         %13.2lf\n"
      "Ymin          %13.2lf\n"
      "Cap           %4d\n"  
      "Logxflag      %4d\n"
      "Logyflag      %4d\n",
      __LINE__,__FILE__, __DATE__,
      Trace,
      Show,
      Data_columns,
      Xmax,
      Xmin,
      Ymax,
      Ymin,
      Cap,
      Logxflag,
      Logyflag);
}
#endif

char *keycopy(char *target,char *source,int maxlen) {
int t,tt,s,insert=0;
int c;
result=0;
for (t=0;t<maxlen;t++) target[t]='\0';
maxlen--;
c=0;
     for (t=0,s=0;t<maxlen && c!=RETURN;) {
          c=getkey(1);
          if (c>31 && c<127) {
               putch(c);
               target[t++]=c;
               if (insert==0 && (source[s+1])!='\0') s++;
          } else {
               switch (c) {
               case RETURN:
                    if (!target[0]) {
                       strcpy(target,source);
                       result=RETURN;
                    }
                    else target[t]='\0';
                    break;
               case EXEC:
               case W_EXEC:
               case ESC:
               case CANCEL:
               case BACKTAB:
                    target[0]=0;
                    c=RETURN;
                    break;
               case BACKSPACE:
                    insert=0;
                    if (t>0) {
                         printf("\b \b");
                         t--;
                    }
                    if (s>0) s--;
                    break;
               case RIGHT:
               case W_RIGHT:
                    insert=0;
                    if (t<maxlen && source[s]){
                         putch(source[s]);
                         target[t++]=source[s++];
                    }
                    break;
               case DELETE:
               case W_DELETE:
                    source++;
                    insert=0;
                    break;
               case INSERT:
               case W_INSERT:
                    insert=1;
                    break;
               case LEFT:
               case W_LEFT:
                    insert=0;
                    if (t>0) {
                         printf("\b \b");
                         t--;
                    }
                    if (s>0) s--;
                    break;
               case F3:
               case W_F3:
                    insert=0;
                    while (t<maxlen && source[s]) {
                         putch(source[s]);
                         target[t++]=source[s++];
                    }    
                    break;
               case F5:
               case W_F5:
                    insert=0;
                    for (tt=0;tt<t;tt++) source[tt]=target[tt];
                    for (t=0;t<maxlen;t++) target[t]='\0';
                    putch('@');
                    putch('\n');
                    s=t=0;
                    break;
               case CTRL_C:
                    farewell(0);
                    break;
               }
          }
     }
     return target;
}

void openin(char *s)
{
   if ((fpin=fopen(s,"rb"))== NULL) {
       E_OPENIN;
       farewell(-1);
   }
}

void openout(char *s)
{
   if ((fpout=fopen(s,"wb"))== NULL) {
       E_OPENOUT;
       farewell(-1);
   }
}

void picopen(char *s) {
int n;
unsigned char c;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n\n%4d $$$$$$$$$$$$$$$$ picopen \"%s\" $$$$$$$$$$$$$$$$\n",__LINE__,s);
#endif
   openout(s);
   for (n=0;n<17;n++){
      c=header_vector[n];
      fputc(c,fpout);
   }
   picsize(Hsize, Vsize);
   picfont(1);
   piccolor(0);
}

void piccorner() {
   picmove(X_ORIGIN,Y_ORIGIN+X_LENGTH);
   picdraw(X_ORIGIN,Y_ORIGIN);
   picdraw(X_ORIGIN+X_LENGTH,Y_ORIGIN);
   picmove(X_LENGTH,PICTOP-Y_LENGTH);
   picdraw(X_LENGTH,PICTOP);
   picdraw(X_LENGTH-Y_LENGTH,PICTOP);
}

void picxy(int x,int y) {
   fputc(x/256,fpout);
   fputc(x%256,fpout);
   fputc(y/256,fpout);
   fputc(y%256,fpout);
}

void picmove(int x,int y)
{
   fputc(MOVE,fpout);
   picxy(x,y);
}

void picfont(char font)
{
   fputc(FONT,fpout);
   fputc(font,fpout);
}

void piccolor(int color) {
   fputc(COLOR0+color%6,fpout);
}

void picsize(int x,int y)
{
   fputc(SIZE,fpout);
   picxy(x,y);
}

void picdraw(int x,int y)
{
   fputc(DRAW,fpout);
   picxy(x,y);
}

void pictext(int direction,int position, char *s)
{
   fputc(TEXT,fpout);
   fputc((unsigned char)direction*16+position,fpout);
   fputs(s,fpout);
   fputc('\0',fpout);
}

void picend(void)
{
   fputc(END,fpout);
   fclose(fpin);
   if (fclose(fpout)==EOF) {
     E3;
     farewell(-1);
   }
}

void picheaders(int headerlines) {
   int h;
   if (*first_title) {  
      picmove(x_origin + (x_length -log0)/2,pictopline(0));
      pictext(0,CENTERTOP,first_title);
   }
   if (*second_title) {
      picmove(x_origin + (x_length -log0)/2,pictopline(1));
      pictext(0,CENTERTOP,second_title);
   }
   for (h=2;h<headerlines;h++) {
      picmove(x_origin + (x_length -log0)/2,pictopline(h));
      pictext(0,CENTERTOP,headerline[h]);
   }
}

int pictextlines(int xpos, int ypos, char *text, int direction, int position) {
   int line, lines, n;
   char *textpointer;
   strncpy(buffer,text,MAX_LEN);
   lines=count_char(buffer,'\\')+1;
   textpointer=strtok(buffer,"\\");
   for (line=0; line<lines; line++) {
#ifdef TRACE
        if (Trace) fprintf(tracefile,"\n%4d xpos=%d ypos=%d text=%s textpointer=%s",
           __LINE__, xpos, ypos, buffer, textpointer);
#endif
        picmove(xpos, ypos);
        if (line==0) for (n=0;n<Plotter;n++) pictext(direction,position,buffer);
        else if (textpointer) for (n=0;n<Plotter;n++) pictext(direction,position,textpointer);
        textpointer=strtok(NULL,"\\");
        if (direction) xpos+= Vsize;
        else           ypos-= Vsize;
  }
  if (direction) return xpos;
  return ypos;
}

int strmenu(int current_pos, int rows, int startrow,int nooflines) {
     int pos, key;
     int n, result, row, col, maxnoofitems;
     maxnoofitems=TEXTCOLUMNS*nooflines;
     if (rows>maxnoofitems) rows=maxnoofitems;
     if (rows>MAXFILES) rows=MAXFILES;
     for (n=0;n<rows;n++) startchars[n]=toupper(*(filename[n]));
     startchars[rows]='\0';
     n= current_pos;
     do {
        row=startrow + n % nooflines;
        col=1+SCREENCOLUMNS/TEXTCOLUMNS*(n/nooflines);
        gotoxy(col, row);
        HLON;
        printf("%-8s",strnleft2(buffer,filename[n],'.',8));
        NORM;
        key=getkey(0);
        gotoxy(col, row);
        printf("%-8s",strnleft2(buffer,filename[n],'.',8));
        if (key<=SPACE || key>256) {
           switch (key) {
              case UP:
              case W_UP:
                   n--;
                   if (n<0) n=rows-1;
                 break;
              case DOWN:
              case W_DOWN:
              case SPACE:
                   n++;
                   if (n > rows-1) n=0;
                 break;
              case TAB:
              case RIGHT:
              case W_RIGHT:
                   if (n<rows-nooflines) n+=nooflines;
                 break;
              case BACKTAB:
              case LEFT:
              case W_LEFT:
                   if (n>nooflines-1) n-=nooflines;
                 break;
              case PgUp:
              case W_PgUp:
                   n=(n>nooflines-1 && rows>nooflines) ?
                        nooflines:
                        0;
                 break;
              case HOME:
              case W_HOME:
                   n=0;
                 break;
              case PgDn:
              case W_PgDn:
                   n=(n>nooflines-1 || nooflines>rows) ?
                        rows-1:
                        nooflines-1;
                   if (n>rows-1) n=rows-1;
                 break;
              case SHIFT_HOME:
                   n=rows-1;
                 break;
                case RETURN:
                case W_ENDKEY:
                case W_EXEC:
                case EXEC:
                   result= RETURN;
                 break;
                case ESC:
                case CANCEL:
                   n=-1;
                 break;
              case CTRL_C:
                  farewell(0);
              default:
                  break;
           }
       } else {
               pos=strpos(startchars,toupper(key),n);
               n=(pos<0) ? n : pos;
       }
     }  while (result!=RETURN && n>=0);
   return n;
}

char *strleft(char *s1,char *s2,char *s3) {
     int i,ii;
     if (strlen(s2)==0 || strlen(s3)==0 ) {
          *s1='\0';
          return s1;
     }
     strcpy(s2,s1);
     for (i=1;i<=strlen(s3);i++) {
          for (ii=strlen(s2);ii>0;ii--) {
               if (s3[i-1]==s2[ii-1]) {
                    s1[ii]='\0';
                    return s1;
               }
          }
     }
     *s1='\0';
     return s1;
}

/* $getfile: GET FILE FROM DISC as a subroutine; first Eco-C version: 081187 */
/* modified 040288,060288,270288,040388: quit with Esc */
/* Turbo-C version 220388 */
/* latest modification: 230388 */

char *getfile(char *s) {
   char drive[MAXDRIVE];
   char dir[MAXDIR];
   char shortname[MAXFILE];
   char ext[MAXEXT];
   char path[120];
   int nooffiles,selected_file;
   do {
		strcpy(path,getmask(s));
		if (!(*path)) return NULL;
		makefilename(path,path,".PRN",0);
		fnsplit(path, drive, dir, shortname, ext);
		fnmerge(Input_path, drive, dir, "*", ext);
		nooffiles=getdir(path,filename);
		if (!nooffiles) {
			CLS;
			M1_GETFILE;
		}
	} while (!nooffiles);
        selected_file= strmenu(
           0,
           nooffiles,
           SCREENSTARTROW,
           NOOFLINES
        );
	if (selected_file==-1) return NULL;
	strcpy(s,filename[selected_file]);
	fnmerge(path,drive,dir,filename[selected_file],ext);
	return path;
}

char *strnleft2(char *buffer, char *s1, char stop, int n) {
   int i=0;
   do buffer[i]=s1[i++];
   while  (i && i<n && s1[i]!=stop);
   buffer[i]='\0';
   return buffer;
}

char *getmask(char *mask) {
	char buffer[80];
	M2_GETFILE;
	keycopy(buffer,mask,80);
	strcpy(mask,buffer);
	return mask;
}

int getdir(char *s, char filename[][LENFILENAME+1]) {
	int done,n,row,col,month,day,year,hour,minute,second;
	struct ffblk ffblk;
	CLS;
	M3_GETFILE;
	for (col=0; col<TEXTCOLUMNS; col++) {
	   gotoxy(1+col*SCREENCOLUMNS/TEXTCOLUMNS, SCREENSTARTROW-1);
           printf("Filename YY/MM/DD");
        }
	done=findfirst(s,&ffblk,0);
        if (done) return 0;
	for(n=0,done=0;!done && n<MAXFILES;n++) {
		row=SCREENSTARTROW + n%NOOFLINES;
                col=1+SCREENCOLUMNS/TEXTCOLUMNS*(n/NOOFLINES);
		gotoxy(col, row);
		strcpy(filename[n],ffblk.ff_name);
		maketime(&hour,&minute,&second,ffblk.ff_ftime);
		makedate(&month,&day,&year,ffblk.ff_fdate);
		printf("%-8s %2.2d/%2.2d/%2.2d\n",strnleft2(buffer, filename[n],'.',8), year, month, day);
                done=findnext(&ffblk);
	}
	return(n);
}

void makedate(int *m,int *d,int *y,unsigned total) {
	*m=(total>>5)&0XF;
	*d=total & 0X1F;
	*y=(total>>9)&0X3F;
	*y+=80;
}

void maketime(int *h,int *m,int *s,unsigned total) {
	*h=(total>>11) & 0X1F;
	*m=(total>>5) & 0X3F;
	*s=total & 0X1F;
}

void startup_message(void) {
   clrscr();
   frame(51,4);
   gotoxy(3,2);
   S1;
   gotoxy(3,3);
   S2;
   gotoxy(2,8);
}

void frame(int hor,int vert) {
   int x,y;
   x=wherex();
   y=wherey();
   putch(201);
   printstring(205,hor-2);
   putch(187);
   down(186,vert-2);
   putch(188);
   gotoxy(x,y);
   down(186,vert-2);
   putch(200);
   printstring(205,hor-2);
   gotoxy(x,y+vert+1);
}   

void printstring(char c,int n) {
   int i;
   for (i=0;i<n;i++) putch(c);
}

void down(char c,int n) {
   int i;
   for (i=0;i<n;i++) {
      putch('\n');
      putch('\b');
      putch(c);
   }
   putch('\n');
   putch('\b');
}

int picsave(char *source, char *target, char *ext) {
   char s[20], cli[MAX_LEN+1];
   int i, files_written, ok;
   if (Show) {
      clrscr();
      printf("RETURN = save as %s_file\n"
             "SPACE  = do NOT save, go back to options menu\n"
             "Esc    = do NOT save, quit program\n", ext);
      i=getkey(0);
   } else i=RETURN;
   switch (i) {
      default:
      case SPACE:
      case TAB:
         return 1;
      case ESC:
      case CANCEL:
      case CTRL_C:
         farewell(0);
         break;
      case RETURN:
      case EXEC:
      case W_EXEC:
         setdisk(0);
         if (Show) {
            do {
               printf("default file-name: %s ",target);
               keycopy(buffer,target,MAX_LEN);
               if (!result) {
                  strcpy(buffer, target);
                  return 1;
               }
               if (!(check_dosname(buffer))) {
                  ok=FALSE;
                  clrscr();
                  printf("\"%s\" is not a valid filename\n"
                  "re-enter filename: ", buffer);
               } else ok=TRUE;
            } while (!ok);
            if (!check_output_file(target,buffer,ext)) return 1;
         }
         sprintf(cli,"copy %s %s > c:bar.log",source, target);
         do {
            *s=0;
            system(cli);
            fpin=fopen("c:bar.log","rt");
            fscanf(fpin,"%s",s);
            fclose(fpin);
            files_written=atoi(s);
            if (!files_written) {
               printf("\nerror executing DOS-command: \"%s\"\n",cli);
               sprintf(cli,"TYPE %s","c:bar.log");
               system(cli);
               printf("\n\nRETURN = re-try\n"
                     "SPACE  = do NOT save, go to options menu\n"
                     "Esc    = do NOT save, quit program\n");
               i=getkey(0);
               switch (i) {
                  default:
                     case SPACE:
                     setdisk(startup_drive);
                     return 1;
                  case RETURN:
                  case EXEC:
                    setdisk(startup_drive);
                    break;
                  case ESC:
                  case CANCEL:
                     farewell(0);
               }
            }
         } while (!files_written);
         setdisk(startup_drive);
         if (!Show) return 1;
         else return 0;
      /* end case RETURN */
   }
   return -1; /* should not occur */
}

int check_output_file(char *new_name, char *default_name, char *ext) {
   result=0;
   strcpy(new_name,default_name);
   makefilename(new_name,Output_path,ext,1);
   while ((fpin=fopen(new_name,"rb"))!=NULL && result!=RETURN) {
     fclose(fpin);
     printf("\n\noutput file %s already exists\nenter new name or press RETURN to overwrite\noutput-PIC-file :",new_name);
     if (keycopy(new_name, default_name, 80)==NULL) return 0;
     strcpy(default_name, new_name);
     if (*new_name==NULL) return 0;
     makefilename(new_name,Output_path,ext,1);
   }
   return 1;
}

char *makefilename(char *fullname, char *default_path, char *default_ext, int forced_ext_flag) {
   int flag;
   char drive[MAXDRIVE];
   char default_drive[MAXDRIVE];
   char dir[MAXDIR];
   char default_dir[MAXDIR];
   char shortname[MAXFILE];
   char ext[MAXEXT];
   flag= fnsplit(default_path, default_drive, default_dir, shortname, ext);
   flag= fnsplit(fullname, drive, dir, shortname, ext);
   if (!(flag & DRIVE))      strcpy( drive, default_drive);
   if (!(flag & DIRECTORY))  strcpy( dir, default_dir);
   if (!(flag & EXTENSION) || forced_ext_flag)  strcpy( ext, default_ext);
   fnmerge(fullname,drive,dir,shortname,ext);
   fnmerge(default_path,drive,dir,"*",ext);
   return fullname;
}

int check_dosname(char *s) {
char c;
int i, namestart=0, extlen, len, dotpos=0;
   if (strpos2(s,'?',0) !=-1) return 0;
   if (strpos2(s,'*',0) !=-1) return 0;
   if (strpos2(s,'/',0) !=-1) return 0;
   if (s[1]==':' && (c=toupper(*s))>'@' && c<'F') namestart=2;
   if (strpos2(s,':',namestart) !=-1) return 0;
   if (strlen(s)-namestart>1 && strpos2(s,' ',namestart+1) !=-1) return 0;
   do {
      i=strpos2(s, '\\', namestart)+1;
      if (i) namestart=i;
   } while (i);
   i=strpos2(s,'.',namestart);
   if (i>-1) {
      dotpos=++i;
      if (i<strlen(s) && strpos2(s,'.',i)!=-1) {
         return 0;
      }
      extlen=strlen(s)-dotpos+1;
      if (extlen<2 || extlen>4) return 0;
   } else extlen=0;
   if ((len=strlen(s)-extlen-namestart)>8) return 0;
   return len;
}

int strpos2(char *s,char c,int pos) {
/* finds occurrence of c in s starting at pos */
int p;
     if (pos>strlen(s)) printf("\nerror: position %d in \"%s\" not found\n", pos, s);
     for (p=pos;s[p];p++) if (s[p]==c) return p;
     return -1;
}

int getmaxlegend(void) {
   int i, len, maxlen=0;
   for (i=0; i<ranges; i++) {
         len=strcspn(range_name[i],"\\");
         if ( maxlen < len) maxlen=len;
#ifdef TRACE
         if (Trace) fprintf(tracefile,"\n%4d i=%d range_name=\"%s\" len=%d maxlegend=%d",
            __LINE__,i, range_name[i], len, maxlen);
#endif
   }
   return maxlen;
}

int get_legendlines(void) {
   int i, n;
   for (i=0, n=0; i<ranges; i++)  n+=count_char(range_name[i],'\\')+1;
   return n;
}

int count_char(char *s, char c) {
   int n=0, result=0;
   while(s[n]) if (s[n++]==c) result++;
   return result;
}

void piclegend(int legends_per_line) {
   int i, x, xpos, xpos1, y, dy, lines, legendlines, size=LEGEND_SYMBOL_SIZE;
   char text[80], *textfragment;
#ifdef TRACE
   if (Trace) fprintf(tracefile,"\n%4d piclegend",__LINE__);
#endif
   if (!legends_per_line) return;
   dy=0.1*Vsize;
   if (Legendpos==0) {
      lines=ceil((double)ranges/legends_per_line);
      for (i=0; i<ranges; i++) {
         if (Color) piccolor(i);
         if ( ranges<2 ) x= x_origin-log0;
         else x= x_origin -log0 + (x_length*((i/lines)%legends_per_line))/legends_per_line;
         y= picbottomline(lines-(i%lines)-1) + Vsize/2;
         if (symbolstring[i]=='B') {
            xpos1=(Line)?x+(XSIZE+size)/2:x;
            picmove(xpos1-size, y-VSIZE/3);
            picdraw(xpos1+size, y-VSIZE/3);
            picmove(xpos1-size/2, y-VSIZE/3);
            picdraw(xpos1-size/2, y+VSIZE/4);
            picdraw(xpos1+size/2, y+VSIZE/4);
            picdraw(xpos1+size/2, y-VSIZE/3);
         } else picdot (x, y - dy, i, size);
         if (symbolstring[i]!='B') {
            if (Line) {
               if (symbolstring[i]!='L') {
                  picdotted_line(x+size/2, y-dy,x+size/2+XSIZE , y - dy, i );
                  picdot (x+size+XSIZE, y - dy , i, size );
               } else {
                  picdotted_line(x, y - dy, x+size+XSIZE, y - dy, i );
               }
            } else if (symbolstring[i]=='L') {
               picdotted_line(x-size/2, y-dy, x+size/2, y-dy, i);
            }
         }
         if (Line) picmove(x+2*size+XSIZE+DX, y);
         else picmove(x+size+DX, y);
         pictext(0, CENTERLEFT, range_name[i]);
#ifdef TRACE
         if (Trace) fprintf(tracefile,"\n%4d legend %d: \"%s\"",__LINE__,i,range_name[i]);
#endif
      }
   } else {
      legendlines=get_legendlines();
      y= y_origin+y_length - 0.2*Vsize;
      if (Legendpos==1) x= x_origin + x_length + ((Ycal==0)?Rim:0) + 50;
      if (Legendpos==2) x= x_origin + x_length - ((Ycal==3)?Rim:0) - legendblocksize;
      if (Legendpos==3) x= x_origin+(Ycal/3==0)?Rim:0 ;
/*
      if (Box)
          picmove(x, y);
          picdraw(x,y2);
          picdraw(x+legendblocksize, y2);
          picdraw(x+legendblocksize, y);
          picdraw(x, y);
      }
*/
      if (Box) {
          picmove(x, y + 0.6*Vsize);
          picdraw(x, y - legendlines*Vsize+0.4*Vsize);
          picdraw(x+legendblocksize, y - legendlines*Vsize+0.4*Vsize);
          picdraw(x+legendblocksize, y + 0.6*Vsize);
          picdraw(x, y + 0.6*Vsize);
      }
      xpos=x+DX+size/2;
      for (i=0; i<ranges; i++) {
         x=xpos;
         if (Color) piccolor(i);
         if (symbolstring[i]=='B') {
            xpos1=(Line)?x+(XSIZE+size)/2:x;
            picmove(xpos1-size, y-VSIZE/3);
            picdraw(xpos1+size, y-VSIZE/3);
            picmove(xpos1-size/2, y-VSIZE/3);
            picdraw(xpos1-size/2, y+VSIZE/4);
            picdraw(xpos1+size/2, y+VSIZE/4);
            picdraw(xpos1+size/2, y-VSIZE/3);
         } else picdot (x, y - dy, i, size);
         if (symbolstring[i]!='B') {
            if (Line) {
               if (symbolstring[i]!='L') {
                  picdotted_line(x+size/2,y - dy,x+size/2+XSIZE , y - dy, i);
                  picdot (x+size+XSIZE, y - dy , i, size );
               } else {
                  picdotted_line(x,        y - dy, x+size+XSIZE , y - dy, i);
               }
            } else if (symbolstring[i]=='L') {
               picdotted_line(x-size/2,y-dy, x+size/2, y-dy, i);
            }
         }
         if (Line) x+=2*size+XSIZE+DX;
         else x+=size+DX;
         strncpy(text,range_name[i],79);
         textfragment=strtok(text,"\\");
         do {
            picmove(x, y);
            if (textfragment) pictext(0, CENTERLEFT, textfragment);
            textfragment=strtok(NULL,"\\");
            y -= YSIZE;
         }  while (textfragment);
#ifdef TRACE
         if (Trace) fprintf(tracefile,"\n%4d legend %d: \"%s\"",__LINE__,i,range_name[i]);
#endif
      }
   }
}

char *ftoa(float f) {
   sprintf(buffer,"%.3f",f);
   return buffer;
}
void dotted_h_line(int x0, int x1, int y0) {
   for (;x0+10<=x1;x0+=40) {
      picmove(x0,y0);
      picdraw(x0+10,y0);
   }
}
void dotted_v_line(int x0, int y0, int y1) {
   for (;y0+10<=y1;y0+=40) {
      picmove(x0,y0);
      picdraw(x0,y0+10);
   }
}

void yesno(int flag, char *yesstring, char *nostring) {
   if (flag) {
      printf(" %s  ", nostring);
      HLON;
      printf("%s\n", yesstring);
      NORM;
   } else {
      putch(' ');
      HLON;
      printf("%s", nostring);
      NORM;
      printf("  %s\n", yesstring);
   }
}


