@echo EJN subklassen ronde printfile
type 1001.    >prn
type 1000.    >prn
type 1002.    >prn
type 1003.    >prn
type 1005.    >prn
