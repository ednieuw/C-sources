bcx /x sub.prj
