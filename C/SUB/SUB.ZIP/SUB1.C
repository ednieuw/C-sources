/* subklassen sub1 flow  Ed Nieuwenhuys*/

/* l.prj file
Compile in LARGE*/

#include "alloc.h"
#include "conio.h"
#include "io.h"
#include "string.h"
#include "stdlib.h"
#include "stdio.h"
#include "process.h"
#include "dir.h"
#include "time.h"
#include "dos.h"
#include "math.h"
#include "fcntl.h"
#include "bios.h"
#include "mem.h"


#define METHODE   0
#define STANDAARD 1
#define Xl 40           /* lengte X en T as van plaatjes */
#define Yl 10


#define LOTUS1 0X0404
#define LOTUS2 0X0405
#define BELL 7
#define MAXROWS 100             /* maximaal aantal deelnemers */
#define MAX_LEN 40
#define MAX_LEN_NAAM  30       /* Lengte van de naam column */
#define MAX_LEN_ADRES 60       /* Lengte van de adres column */
#define MAX_LEN_LAB   50       /* Lengte van de plaats column */
#define MAX_LEN_PLAATS 60      /* Lengte van de plaats column */
#define MAX_LEN_TELNR 13       /* Lengte van de telnr column */
#define MAX_LEN_DATUM 7        /* Lengte van de datum column */
#define MAX_RONDEN    5        /* 2 meer invoeren dan nodig */
#define MAX_MONSTER   3        /* aantal testsera */
#define MAX_METHODE   10       /* aantal methoden */
#define MAX_STANDAARD 10       /* aantal std'en   */

#define MISSING -999999.0

#define DATUM __DATE__
#define LARGE 0
#define MEDIUM 1
#define SMALL  2
#define LINEAR 3
#define MAXNOOFCALIBRATORS  10
#define MISSING_CALIBRATOR -999


extern int MAX_ROW;
extern struct fvak {
	    long serumnr;
	    char techniek,standaard;
	    float IgG1,IgG2,IgG3,IgG4,IgG,IgGsom,IgGdev;
	    int g1pos,g2pos,g3pos,g4pos,gpos,ptpos,devpos;
	   };

extern struct vak {
	     char naam[MAX_LEN_NAAM];
	     char adres[MAX_LEN_ADRES];
	     char plaats[MAX_LEN_PLAATS];
	     char lab[MAX_LEN_LAB];
	     char telnr[MAX_LEN_TELNR];
	     long lidnr;
	     struct fvak dag[MAX_RONDEN];
	     int check;
	   };

    /*            regel kolom  */


extern struct vak **wie;
extern int    rows, columns;
extern char   calibratorstring[MAXNOOFCALIBRATORS][12];
extern double value_of_calibrator[MAXNOOFCALIBRATORS];
extern int    xnoofcalibrators=MAXNOOFCALIBRATORS;
extern int    ascal(int *xnoofcalibrators, float *min, float *max,
		 int logflag, int calcflag, int expflag);

float mean[MAX_MONSTER][9];
float min[MAX_MONSTER][9];
float max[MAX_MONSTER][9];
float aantal[MAX_MONSTER][9];

void   print_rapport(void);
void   maak_plaatjes(void);
void   maak_rapport(int pers);
void   printkop(int pers,int pagina,FILE *file);

void print_rapport(void)
{
 int persoon;
 maak_plaatjes();
 for(persoon=0;persoon<rows;persoon++) maak_rapport(persoon);
/* maak_rapport(0);*/
}
void maak_plaatjes(void)
{
FILE  *outs,*outm;
int   pos;
float waarde;
float posfac;
char  c;
char  sarray[Yl+3][Xl+3]; /* Xl pos op regel, Yl regels hoog */
int   sarrayno[Xl+3];     /* standaard array */
char  marray[Yl+3][Xl+3]; /* Xl pos op regel, Yl regels hoog */
int   marrayno[Xl+3];     /* techniek array */
char  line[80];
char  topline[80];
char  prnfile[15];
char  prnfilem[15];
char  prnfiles[15];
int   b,m,n,i,j,k;
int   persoon;

  for(n=0;n<MAX_MONSTER;n++){
    for(m=0;m<9;m++) {
       mean[n][m] = 0.0;
	min[n][m] = 99999.0;
	max[n][m] = 0.0;
     aantal[n][m] = 0.0;
    }}

 for(persoon=0;persoon<rows;persoon++){
  for(n=0;n<MAX_MONSTER;n++){
  m=0;
   if(wie[persoon]->dag[n].IgG1 > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG1)
	 max[n][m]=wie[persoon]->dag[n].IgG1;
      if(min[n][m]>wie[persoon]->dag[n].IgG1)
	 min[n][m]=wie[persoon]->dag[n].IgG1;
	 mean[n][m]+=wie[persoon]->dag[n].IgG1;
	 aantal[n][m]++;
    }
   m++;
   if(wie[persoon]->dag[n].IgG2 > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG2)
	 max[n][m]=wie[persoon]->dag[n].IgG2;
      if(min[n][m]>wie[persoon]->dag[n].IgG2)
	 min[n][m]=wie[persoon]->dag[n].IgG2;
	 mean[n][m]+=wie[persoon]->dag[n].IgG2;
	 aantal[n][m]++;
    }
   m++;
   if(wie[persoon]->dag[n].IgG3 > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG3)
	 max[n][m]=wie[persoon]->dag[n].IgG3;
      if(min[n][m]>wie[persoon]->dag[n].IgG3)
	 min[n][m]=wie[persoon]->dag[n].IgG3;
	 mean[n][m]+=wie[persoon]->dag[n].IgG3;
	 aantal[n][m]++;
    }

   m++;
   if(wie[persoon]->dag[n].IgG4 > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG4)
	 max[n][m]=wie[persoon]->dag[n].IgG4;
      if(min[n][m]>wie[persoon]->dag[n].IgG4)
	 min[n][m]=wie[persoon]->dag[n].IgG4;
	 mean[n][m]+=wie[persoon]->dag[n].IgG4;
	 aantal[n][m]++;
    }

   m++;
   if(wie[persoon]->dag[n].IgG  > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG )
	 max[n][m]=wie[persoon]->dag[n].IgG ;
      if(min[n][m]>wie[persoon]->dag[n].IgG )
	 min[n][m]=wie[persoon]->dag[n].IgG ;
	 mean[n][m]+=wie[persoon]->dag[n].IgG ;
	 aantal[n][m]++;
    }

   m++;
   if(wie[persoon]->dag[n].IgGsom  > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgGsom )
	 max[n][m]=wie[persoon]->dag[n].IgGsom ;
      if(min[n][m]>wie[persoon]->dag[n].IgGsom )
	 min[n][m]=wie[persoon]->dag[n].IgGsom ;
	 mean[n][m]+=wie[persoon]->dag[n].IgGsom ;
	 aantal[n][m]++;
    }

   m++;
/*   if(wie[persoon]->dag[n].IgGdev  > 0)
    {                                    */
      if(max[n][m]<wie[persoon]->dag[n].IgGdev )
	 max[n][m]=wie[persoon]->dag[n].IgGdev ;
      if(min[n][m]>wie[persoon]->dag[n].IgGdev )
	 min[n][m]=wie[persoon]->dag[n].IgGdev ;
	 mean[n][m]+=wie[persoon]->dag[n].IgGdev ;
	 aantal[n][m]++;
 /*   }*/

  }} /*end for's*/


 for(m=0;m<7;m++){
  for(n=0;n<MAX_MONSTER;n++){
   if(aantal[n][m] > 0)
    {
     mean[n][m]/=aantal[n][m];
     if(min[n][m] > 0)  min[n][m]*=0.99;
     else               min[n][m]*=1.01;
     max[n][m]*=1.01;
   ascal(&xnoofcalibrators,&min[n][m],&max[n][m],0,0,0);
  }}}


 /* lus plaatjes maken */

  for(m=0;m<7;m++){	/* IgG1, m=1 IgG2 enz. */
  for(n=0;n<MAX_MONSTER;n++)
    {
    if(aantal[n][0]==0)   /* Als er waarden voor het monster zijn -> plaatjes */
	  continue;     /* anders zijn er minder monsters rondgestuurd */

				/* wissen array voor plaatje*/
    for(j=0;j<=Yl;j++){
       for(i=0;i<=Xl;i++){ sarray[j][i]=32; marray[j][i]=32;}
	 sarray[j][Xl+1]=0; marray[j][Xl+1]=0;
      }

    for(i=0;i<=Xl;i++){         	/* wissen array voor plaatje*/
       sarrayno[i]=0;
       marrayno[i]=0;}


    for(persoon=0;persoon<rows;persoon++)
      {
	   switch(m){
	    case 0: waarde=wie[persoon]->dag[n].IgG1;   break;
	    case 1: waarde=wie[persoon]->dag[n].IgG2;   break;
	    case 2: waarde=wie[persoon]->dag[n].IgG3;   break;
	    case 3: waarde=wie[persoon]->dag[n].IgG4;   break;
	    case 4: waarde=wie[persoon]->dag[n].IgG;    break;
	    case 5: waarde=wie[persoon]->dag[n].IgGsom; break;
	    case 6: waarde=wie[persoon]->dag[n].IgGdev; break;
	  default : puts("fout in cases in print rapport"); getch();
	}
	posfac=(max[n][m]-min[n][m]) / Xl;
	pos= (waarde - min[n][m]) / posfac ;
	sarray[sarrayno[pos]][pos]=wie[persoon]->dag[n].standaard;
	marray[marrayno[pos]][pos]=wie[persoon]->dag[n].techniek;
	if(sarrayno[pos]>0){  /*sorteren op character */
		for(i=sarrayno[pos];i>0;i--){
		  if(sarray[i-1][pos]>sarray[i][pos]){
		     c=sarray[i-1][pos];
		     sarray[i-1][pos]=sarray[i][pos];
		     sarray[i][pos]=c;
		  }
		}
	}

	if(marrayno[pos]>0){  /*sorteren op character */
		for(i=marrayno[pos];i>0;i--){
		  if(marray[i-1][pos]>marray[i][pos]){
		     c=marray[i-1][pos];
		     marray[i-1][pos]=marray[i][pos];
		     marray[i][pos]=c;
		  }
		}
	}


	sarrayno[pos]++;
	marrayno[pos]++;
	if(sarrayno[pos]>=Yl){sarray[sarrayno[pos]--][pos]= '^';}
	if(marrayno[pos]>=Yl){marray[marrayno[pos]--][pos]= '^';}
      }

      switch(m){
	    case 0: sprintf(prnfile,"%4s%d","IgG1",n+1);   break;
	    case 1: sprintf(prnfile,"%4s%d","IgG2",n+1);   break;
	    case 2: sprintf(prnfile,"%4s%d","IgG3",n+1);   break;
	    case 3: sprintf(prnfile,"%4s%d","IgG4",n+1);   break;
	    case 4: sprintf(prnfile,"%4s%d","IgGt",n+1);   break;
	    case 5: sprintf(prnfile,"%4s%d","IgGs",n+1);   break;
	    case 6: sprintf(prnfile,"%4s%d","IgGd",n+1);   break;
	}
      clrscr();
      strcpy(prnfilem,prnfile);
      strcat(prnfilem,".met");
      if ((outm = fopen(prnfilem, "wb")) == NULL)
	 printf("Error writing on disk, disk Full ??\r\n");

      strcpy(prnfiles,prnfile);
      strcat(prnfiles,".std");
      if ((outs = fopen(prnfiles, "wb")) == NULL)
	 printf("Error writing on disk, disk Full ??\r\n");

      switch(m){
	    case 0: sprintf(topline,"  %16s  Sample : %d\r\n","IgG1 (g/l)",n+1);   break;
	    case 1: sprintf(topline,"  %16s  Sample : %d\r\n","IgG2 (g/l)",n+1);   break;
	    case 2: sprintf(topline,"  %16s  Sample : %d\r\n","IgG3 (g/l)",n+1);   break;
	    case 3: sprintf(topline,"  %16s  Sample : %d\r\n","IgG4 (g/l)",n+1);   break;
	    case 4: sprintf(topline,"  %16s  Sample : %d\r\n","IgG (g/l)",n+1);   break;
	    case 5: sprintf(topline,"  %16s  Sample : %d\r\n","IgGsum (g/l)",n+1); break;
	    case 6: sprintf(topline,"  %16s  Sample : %d\r\n","IgGdeviation(%)",n+1);   break;
	}
	 printf("%s",topline);
	fprintf(outs,"METHOD   %s",topline);
	fprintf(outm,"STANDARD %s",topline);

      for(j=Yl-1;j>=0;j--)
	{
	 printf("|  %s\r\n",sarray[j]);
	fprintf(outs,"|  %s\r\n",sarray[j]);
	fprintf(outm,"|  %s\r\n",marray[j]);
	 }

   ascal(&xnoofcalibrators,&min[n][m],&max[n][m],0,1,0);
   i=0;
   for(j=0;j<Xl+18;j++) line[j]=' ';
   for(j=0;j<Xl+8;j++) line[j]='-';
   line[Xl+9]=0;
   while(strlen(calibratorstring[i]) )
    {
	pos=3+ (atof(calibratorstring[i])- min[n][m]) / posfac ;
	line[pos]='|';
	i++;
    }
    printf("%s\r\n",line);
   fprintf(outs,"%s\r\n",line);
   fprintf(outm,"%s\r\n",line);
   i=0;
   for(j=0;j<Xl+18;j++) line[j]=' ';
   line[Xl+12]=0;
   while(strlen(calibratorstring[i]) )
    {
	pos= 3+(atof(calibratorstring[i])- min[n][m]) / posfac ;
	if(pos<Xl+8){
		sprintf(line+pos-1,"%s",calibratorstring[i]);
		line[pos-1+strlen(calibratorstring[i])]=' ';
	}
	i++;
    }
    printf("%s\r\n",line);
   fprintf(outs,"%s\r\n",line);
   fprintf(outm,"%s\r\n",line);

      printf("\r\n");
     fprintf(outs,"\r\n");
     fprintf(outm,"\r\n");
/*      getch();*/
     fcloseall();


   }
  } /* einde lus < MAX_MONSTER  */


}


void  maak_rapport(int pers)
{
char fonttekst[90];
char text[255],nop[255];
char fileout[20];
char prnfile[15];
char prnfilem[15];
char prnfiles[15];
FILE *fontfile,*outfile,*filein,*inm,*ins,*outbatfile;
int  pagina;
int  i,j,m,n;
int  pos;
float waarde;
float posfac;

 ltoa(wie[pers]->lidnr,fileout,10);
 fileout[8]=0;
 if ((outfile = fopen(fileout, "wb")) == NULL)
     printf("Error opening textfile, Disk full??\r\n");

 if ((outbatfile = fopen("pr.bat", "at")) == NULL)
     printf("Error opening textfile, Disk full??\r\n");
     fprintf(outbatfile,"type %s.    >prn\n",fileout);
     fclose(outbatfile);
 pagina=1;
 printkop(pers,pagina,outfile);

 if ((fontfile = fopen("INTRO.FNT", "rb")) == NULL)
     printf("intro.FNT file not found\r\n");
 else{
     fgets(fonttekst,80,fontfile);
     fclose(fontfile);
     fprintf(outfile,"%s",fonttekst);
     }

 if ((filein = fopen("INTRO.TXT", "rb")) == NULL)
     printf("INTRO.TXT file not found\r\n");
 else{
     while(fgets(text,255,filein))
       fputs(text,outfile);
     fputs("\f",outfile);
     fclose(filein);
     }

 if ((fontfile = fopen("PLAATJES.FNT", "rb")) == NULL)
     printf("PLAATJES.FNT file not found\r\n");
 else{
     fgets(fonttekst,80,fontfile);
     fclose(fontfile);
     }


 for(m=0;m<7;m++) {
 pagina++;
 printkop(pers,pagina,outfile);
    for(n=0;n<MAX_MONSTER;n++){
    if(aantal[n][0]==0)   /* Als er waarden voor het monster zijn -> plaatjes */
	  continue;     /* anders zijn er minder monsters rondgestuurd */
     fprintf(outfile,"%s",fonttekst); /* font voor plaatjes */

      switch(m){
	    case 0: sprintf(prnfile,"%4s%d","IgG1",n+1);   break;
	    case 1: sprintf(prnfile,"%4s%d","IgG2",n+1);   break;
	    case 2: sprintf(prnfile,"%4s%d","IgG3",n+1);   break;
	    case 3: sprintf(prnfile,"%4s%d","IgG4",n+1);   break;
	    case 4: sprintf(prnfile,"%4s%d","IgGt",n+1);   break;
	    case 5: sprintf(prnfile,"%4s%d","IgGs",n+1);   break;
	    case 6: sprintf(prnfile,"%4s%d","IgGd",n+1);   break;
	}
      strcpy(prnfilem,prnfile);
      strcat(prnfilem,".met");
      if ((inm = fopen(prnfilem, "rb")) == NULL)
	 printf("Error reading from disk %s\r\n",prnfilem);

      strcpy(prnfiles,prnfile);
      strcat(prnfiles,".std");
      if ((ins = fopen(prnfiles, "rb")) == NULL)
	 printf("Error reading from disk %s\r\n",prnfiles);
      printf("%s,%s,%s\r\n",wie[pers]->naam,prnfiles,prnfilem);

      while(fgets(nop,60,inm))
      {
	strcpy(text,nop);
	text[strlen(text)-2]=0;
	strcat(text,"                                  ");
	text[60]=0;
	fgets(nop,60,ins);
	strcat(text,nop);
	fprintf(outfile,"%s",text);
      }
	   switch(m){
	    case 0: waarde=wie[pers]->dag[n].IgG1;   break;
	    case 1: waarde=wie[pers]->dag[n].IgG2;   break;
	    case 2: waarde=wie[pers]->dag[n].IgG3;   break;
	    case 3: waarde=wie[pers]->dag[n].IgG4;   break;
	    case 4: waarde=wie[pers]->dag[n].IgG;    break;
	    case 5: waarde=wie[pers]->dag[n].IgGsom; break;
	    case 6: waarde=wie[pers]->dag[n].IgGdev; break;
	  default : puts("fout in cases in print rapport"); getch();
	}
	for(i=0;i<130;i++) text[i]=' ';
	posfac=(max[n][m]-min[n][m]) / Xl;
	pos= (waarde - min[n][m]) / posfac ;
	text[pos+3]='^';
	text[pos+63]='^';
	text[pos+64]=0;
	fprintf(outfile,"%s\r\n",text);
	fprintf(outfile,"%s\r\n",text);
	fprintf(outfile,"%s\r\n\r\n",text);

     fclose(inm);
     fclose(ins);


    }
    fputs("\f",outfile);

   } /*einde m lus */
fcloseall();
}

void printkop(int pers,int pagina,FILE *file)
{
FILE *fontfile;
char fonttekst[90];

 if ((fontfile = fopen("INTRO.FNT", "rb")) != NULL)
    {
     fgets(fonttekst,80,fontfile);
     fclose(fontfile);
     fprintf(file,"%s",fonttekst);
     }

 fprintf(file,"%-60s Page: %d\r\n",wie[pers]->naam,pagina);
 fprintf(file,"%s, %s\r\n",wie[pers]->adres,wie[pers]->plaats);
 fprintf(file,"No : %-ld  Lab: %s \r\n",wie[pers]->lidnr,wie[pers]->lab);
 fprintf(file,"--------------------------------------------------------------------------------\r\n\r\n");

}
