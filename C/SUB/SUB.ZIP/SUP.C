/* subklassen flow  Ed Nieuwenhuys*/

/* l.prj file
l
cga.obj
herc.obj
egavga.obj
litt.obj
Compile in LARGE*/

#include "alloc.h"
#include "conio.h"
#include "io.h"
#include "string.h"
#include "stdlib.h"
#include "stdio.h"
#include "process.h"
#include "dir.h"
#include "time.h"
#include "dos.h"
#include "math.h"
#include "fcntl.h"
#include "bios.h"
#include "mem.h"

#define breedte_menu     35     /* Breedte van menu's */
#define MAXDISK   5
#define TRUE      1
#define FALSE     0
#define LEEG     -1
#define SPECIAL_KEY  0
#define UP     72
#define DOWN   80
#define HOME   71
#define ENDT   79
#define LEFT   75
#define UP     72
#define EXEC   13
#define ESC    27
#define RIGHT  77
#define PgUp   73
#define PgDn   81
#define SPACE  32
#define RETURN 13
#define TAB     9
#define CHBIN 0xF000    /* Blink Invers */
#define CHBHI 0x8F00	/* Blink Highligted */
#define CHHIG 0x0F00    /* Highligted */
#define CHINV 0x7000    /* Invers */
#define CHNOR 0x0700    /* Normaal */

#define EDIT      0
#define LOAD      1       /* hoofdmenu items */
#define OVERZICHT 2
#define NEW       3
#define VOEGTOE   4
#define PASSWORD  5
#define CHADIR    6
#define EDITOR    7
#define PRINTUIT  8
#define QUIT      9

#define METHODE   1
#define STANDAARD 2
#define Xl 51           /* lengte X en T as van plaatjes */
#define Yl 20

#define LARGE 0
#define MEDIUM 1
#define SMALL  2
#define LINEAR 3
#define MAXNOOFCALIBRATORS  15
#define MISSING_CALIBRATOR -999
char    calibratorstring[MAXNOOFCALIBRATORS][12];
double  value_of_calibrator[MAXNOOFCALIBRATORS];
int noofcalibrators=MAXNOOFCALIBRATORS;
int calbase[4][4]=   {		1 , 0, 0, 0,
				1 , 3, 0, 0,
				1 , 2, 5, 0,
				10,20,25,50
					 };

#define CHECKCODE 12345

int AUTOMENU = FALSE;
static char titel[QUIT+1][breedte_menu];

#define BARCOLOR 0X2400

#define LOTUS1 0X0404
#define LOTUS2 0X0405
#define BELL 7
#define MAXROWS 100             /* maximaal aantal deelnemers */
#define MAX_LEN 40
#define MAX_LEN_NAAM  30       /* Lengte van de naam column */
#define MAX_LEN_ADRES 60       /* Lengte van de adres column */
#define MAX_LEN_LAB   50       /* Lengte van de plaats column */
#define MAX_LEN_PLAATS 60      /* Lengte van de plaats column */
#define MAX_LEN_TELNR 13       /* Lengte van de telnr column */
#define MAX_LEN_DATUM 7        /* Lengte van de datum column */
#define MAX_RONDEN    5        /* 2 meer invoeren dan nodig */
#define MAX_MONSTER   3        /* aantal testsera */
#define MAX_METHODE   10       /* aantal methoden */
#define MAX_STANDAARD 10       /* aantal std'en   */

#define MISSING -999999.0

#define DATUM __DATE__
int MAX_ROW;

struct ffblk ffblk;
unsigned disk;
char *directory;
char curdir[132];
int size;
int show;

struct fvak {
	    long serumnr;
	    char techniek,standaard;
	    float IgG1,IgG2,IgG3,IgG4,IgG,IgGsom,IgGdev;
	    int g1pos,g2pos,g3pos,g4pos,gpos,ptpos,devpos;
	   };

struct vak {
	     char naam[MAX_LEN_NAAM];
	     char adres[MAX_LEN_ADRES];
	     char plaats[MAX_LEN_PLAATS];
	     char lab[MAX_LEN_LAB];
	     char telnr[MAX_LEN_TELNR];
	     long lidnr;
	     struct fvak dag[MAX_RONDEN];
	     int check;
	   };

    /*            regel kolom  */

struct vak **wie;

int lost,print,LXG,LYG,berekend;
int rows, columns;
int corrupted=FALSE;

FILE *fp;
FILE *fpin;
FILE *fpout;
FILE *printer;
char filename[12];     /* naam voor de punt van de ingelezen file */
char file[30];
char filein[40];
char fileout[40];
char fileload[40];
char outfile[20];
int maindisk;
char maindir[40];
char drawdir[40];
char dir[40];
int geladen=0;
int wis=1;
/*
int    GraphDriver;		/* The Graphics device driver		*/
int    GraphMode;		/* The Graphics mode value		*/
int    MaxX, MaxY;		/* The maximum resolution of the screen */
int    MaxColors;		/* The maximum # of colors available	*/
int    ErrorCode;		/* Reports any graphics errors		*/
struct palettetype palette;     /* for palette info			*/
*/

int  far *SCHERMPTR;
unsigned char far *video;
unsigned char far *vid;
int far *PTR  = (int far *) 0XB800L;
int SIZE,FONT; 		                  /* wordt gebruikt in graphbody() */
int MaxX, MaxY = 0;
float xnop,ynop;
char *password;

/****************************  FUNCTION PROTOTYPES ***************/
void   set_prn_filename(char *);
int    display_menu(int ,int );
int    menuver(int ,int ,int ,int, int );
int    load_menu();
void   stuiteren(void);
void   makedate(int *, int *, int *,unsigned );
char   *filedir(char *);
void   changedir(char *);
int    parse(char *);
void   box(int ,int ,int ,int ,int ,int );
void   swrite(int ,int ,char * , int );
void   twrite(int ,int ,char *,int ,int );
void   initdisplay();
void   veeg(int ,int ,int ,int );
void   lveeg(int ,int ,int ,int ,char,unsigned );
int    prntest();
char   *remove_lt_space(char *);
double getd(FILE *);
void   read_wks(char *);
void   skip(FILE *,long );
void   prnonoff(void);
void   Initialize(void);
void   mallocdata(void);
void   freemallocdata(void);
void   readprn(char *);
void   edit_fields(void);
int    kiesnaam(char *text);
int    save_data(void);
int    load_data(void);
int    display_persoon(int pers);
int    persoon_editen(void);
void   prnt_pers_id(int pers);
void   wissen(int pers);
void   delete_entry(int pers,int dagnr);
void   overzicht(void);
void   print_overzicht(int pers);
void   csort(int n);
void   print_rapport(void);
int    ascal(int *noofcalibrators, float *min, float *max,
		 int logflag, int calcflag, int expflag);
double scientific2(double d, double *base, int *exp);
int    round(double d);
double val(double mantissa, int exponent);
double pow10d(double exponent);


/************************************************************/


/************************** MAIN **************************/

main(int argc,char **argv)
{
char fnop[15];
int k,actie;
struct dfree free;
long avail;
int drive;

char ext[12],filenop[20];
printer = fopen("LPT1","w");
lost     = FALSE;
print    = TRUE;
show     = FALSE;
LXG      = TRUE;
LYG      = FALSE;
berekend = FALSE;
strcpy(outfile,"");
fileload[0] = 0;
filenop[0] = 0;
actie=EDIT;
MAX_ROW=MAXROWS;

clrscr();
strcpy(password,"q");
initdisplay();
normvideo();
textcolor(WHITE);
textbackground(BLACK);

   drive = getdisk();
   getdfree(drive+1, &free);
   if (free.df_sclus == 0xFFFF)
   {
      printf("Error in getdfree() call\n");
      exit(1);
   }

   avail =  (long) free.df_avail *
	    (long) free.df_bsec *
	    (long) free.df_sclus;
   if(avail<50000)
   {
   printf("\n\n\n\nDrive %c: has %8ld bytes available\n", 'A' + drive, avail);
   puts("\nIk zou eerst maar wat wissen voor ik verder ging");
   puts("\n\nDruk en toets");
   getch();
   }

if (argv[1][0]=='?')
 {
  swrite(1,0,"Start het programma op met SUB [1] [2],waarin, [1] een optionele ",0X0700);
  swrite(1,1,"optionele filenaam is met de extensie .SUB of .$$$         ",0X0700);
  swrite(1,4,"[1] of [2] kan ook het maximaal aantal regels zijn dan kan   ",0X0700);
  swrite(1,5,"worden ingelezen. Dit kan handig zijn bij te weinig geheugen.",0X0700);
  swrite(1,6,"Coreleft geeft aan hoeveel ruimte er nog vrij is aan geheugen.",0X0700);
  swrite(1,7,"Het maximaal aantal in te lezen personen staat onderin beeld ",0X0700);
 swrite(1,10,"Een PRN file is de ASCII file van dit bestand                ",0X0700);
 swrite(1,11,"Met Editor wordt de PRN of overzichts file geladen.          ",0X0700);
 swrite(1,12,"In de PRN file kunnen dan bijv. regels gewist worden.        ",0X0700);
 swrite(1,13,"Druk F7 om uit de editor te komen.                           ",0X0700);
 getch();
 exit(1);
 }

if(argc>=2) /* als een file meegegeven in commandline */
   {
   if(argv[1][0]<58) { MAX_ROW=atoi(argv[1]); ext[0]=0;}
    else
     {
     strcpy(filenop,argv[1]);
     strcpy(filenop,strtok(filenop,"."));
     strcpy(ext,strupr(strtok(NULL,".")));
     if(stricmp(ext,"SUB")==0 || stricmp(ext,"$$$")==0)
	 {actie=LOAD; AUTOMENU = TRUE; strcpy(fileload,argv[1]);}
     else if(stricmp(ext,"PRT")==0)
	 {actie=EDIT; AUTOMENU = TRUE; strcpy(fileload,argv[1]);}
    }
   }
if(argc==3) /* als een MAXROW is meegegeven in commandline */
    {
     if(argv[2][0]<58) MAX_ROW=atoi(argv[2]);
    }

mallocdata();
strcpy(curdir,"?:\\");
curdir[0] = 'A'+getdisk();
maindisk = getdisk();
getcurdir(0,curdir+3);
if(curdir[(int)strlen(curdir)-1] != 92) strcat(curdir,"\\");
strcpy(maindir,(char *)curdir);

while(1)
   {
   wis = 1;
   if(!AUTOMENU)
	 actie=display_menu(wis,actie); /* Als geen filenaam in commandline */
   if (actie == -1) actie=QUIT;
   switch (actie)
      {
	   case EDIT:
		  if(!geladen)  break;
		  veeg(0,0,25,80);
		  lost =FALSE;
		  veeg(0,0,25,80);
		  edit_fields();
		  AUTOMENU = FALSE;
		  actie = EDIT;
		  break;

	   case LOAD:
		  veeg(0,0,25,80);
		  lost = FALSE;
                  if(geladen){ save_data(); veeg(0,0,25,80);}
		  freemallocdata();
		  mallocdata();
		  if(!AUTOMENU) strcpy(fileload,(char *)filedir("*.SUB"));
		  geladen=load_data();
		  if (geladen)
		    {
		     strcpy(fnop,fileload);
		     strcpy(filename,strtok(fnop,"."));
		    }
		  veeg(0,0,25,80);
		  AUTOMENU = FALSE;
		  actie = EDIT;
		  break;

	   case OVERZICHT:
		  if(!geladen) break;
		  veeg(0,0,25,80);
		  strcpy(file,fileload);
		  overzicht();
		  AUTOMENU = FALSE;
		  actie=EDIT;
		  break;

	   case NEW:
		  veeg(0,0,25,80);
		  lost =FALSE;
		  password=0;
		  password = getpass("Input a password:");
		  if(stricmp(password,"eddie")!=0) break;
		  freemallocdata();
		  mallocdata();
		  if(!AUTOMENU) strcpy(fileload,(char *)filedir("*.PRN"));
		  if (strlen(fileload) < 2) break;
		  strcpy(file,fileload);
		  berekend  = 0;
		  geladen = 1;
		  veeg(0,0,25,80);
		  strcpy(fnop,fileload);
		  strcpy(filename,strtok(fnop,"."));
		  
		  readprn(fileload);
		  strcpy(outfile,fileload);
		  AUTOMENU = FALSE;
		  actie = EDIT; 
		  break;

	   case VOEGTOE:
		  if(!geladen)  break;
		  persoon_editen();
		  AUTOMENU = FALSE;
		  actie=VOEGTOE;
		  break;

	   case CHADIR:
		  veeg(24,0,1,80);
		  swrite(13,22,"RETURN or New directory: \0",0x1300);
		  gotoxy(39,23);
		  gets(dir);
		  if (strlen(dir) >1) changedir(dir);
		  strcpy(curdir,"?:\\");
		  curdir[0]='A'+getdisk();
		  getcurdir(0,curdir+3);
		  if(curdir[strlen(curdir)-1] != 92) strcat(curdir,"\\");
		  veeg(23,0,2,80);
		  AUTOMENU = FALSE;
		  actie=EDIT;
		  if(geladen) actie=OVERZICHT;
		  break;

	   case PASSWORD:
		  veeg(0,0,25,80);
		  lost =FALSE;
		  password = getpass("Input a password:");
		  if(stricmp(password,"eddie")!=0) strcpy(password,"q");
		  break;


/*		  if(print)           print = FALSE;
		    else {prntest();  print = TRUE;}
		  AUTOMENU = FALSE;
		  actie=EDIT;
		  if(geladen) actie=OVERZICHT;
		  break;
*/
		case EDITOR:
/*		  strcpy(file,fileload);*/
		  strcpy(drawdir,searchpath("pe.exe"));
		  if(spawnlp(P_WAIT,drawdir,"pe.exe",outfile,NULL)==-1)
		   {
		     veeg(0,0,25,80);
		     puts("\n\n\n\n\n      NOT ENOUGH MEMORY FOR EDITOR OR EDITOR NOT FOUND\0");
		     delay(3000);
		    }
		  AUTOMENU = FALSE;
		  actie=EDIT;
		  if(geladen) actie=OVERZICHT;
		  break;

	   case PRINTUIT:
		  if(!geladen)  break;
		  print_rapport();
		  AUTOMENU = FALSE;
		  break;

	   case QUIT:
		 default:
		  if(geladen) save_data();
		  veeg(0,0,25,80);
		  setdisk(maindisk);
		  chdir(maindir);
		  printf("%s\n",maindir);
/*		  freemallocdata();*/
		  exit(1);
		  break;
      }
  }
}
/**********************  EINDE MAIN ***********************/

int display_menu(int wis,int barkeuze)
{
   int num,nr,breed,keuze;
   char datum[12],nop[50],nopp[30];
   num=load_menu();                   /* laad tekst menu */
   if(wis) lveeg(0,0,25,80,'�',0x2500);
   strcpy(datum,DATUM);
   sprintf(nop,"Farcoreleft %lu bytes",farcoreleft());
   sprintf(nopp,"  Max. personen %d \0",MAX_ROW);
   strcat(nop,nopp);
   swrite(2,24,nop,0x2100);

   twrite(2,20,"����������������������������ͻ\0",YELLOW,RED);
   twrite(2,21,"�Problemen? Ed Nieuwenhuys   �\0",YELLOW,RED);
   twrite(2,22,"����������������������������ͼ\0",YELLOW,RED);


   swrite(16,0,"����������������������������ͻ\0",0x0600);
   swrite(16,1,"� Subklassen ronde           �\0",0x0600);
   swrite(16,2,"����������������������������ͼ\0",0x0600);
   swrite(33,1,datum,0x0600);
   swrite(16,3,curdir,0x0700);
   swrite(50,6,fileload,0x0700);
   if(lost) swrite(0,22,"Database te klein om iedereen in te lezen",0X0700);
   gotoxy(1,1);
   breed=breedte_menu;
   keuze = menuver(num,5,17,breed-5, barkeuze);
   if (keuze==QUIT || keuze==-1) veeg(0,0,20,80);
   return(keuze);

}


int menuver(int num,int ltopy,int ltopx,int breed, int barkeuze)
{
   long secs_now;
   char *str_now;
   char s[33];
   int x, y, code, code1, oke, yy, xx, keer,leave,keus;
   int keuze;
   char ch;

   yy = ltopy;
   xx = ltopx;
   oke = 0;
   keuze = barkeuze;
   box(yy,xx,num,breed,1,0);

   while (1)
	 {
	 yy=ltopy;
	 for (y=0; y<num; y++)
	  {
	   yy++;
	   xx=ltopx+1;
	   for (x=0; x<strlen(titel[y]); x++)
		{
		xx++;
		ch = titel[y][x];
		if (y==keuze)   *(SCHERMPTR + yy*80 + xx) = ch | 0x7000;
		else
		  if (x==0)     *(SCHERMPTR + yy*80 + xx) = ch | 0x1300;
			else    *(SCHERMPTR + yy*80 + xx) = ch | 0x4700;
		 }
		}
	  if(oke == 1)		return(keuze);
	  while(bioskey(1)==0)
		{
		 time(&secs_now);
		 str_now=ctime(&secs_now);
		 xx=55;
		 str_now[24]='\0';
		 swrite(xx,0,str_now,0x1300);
		 }

	   code = getch();
	   code1=SPECIAL_KEY;
	   if(code==SPACE) {code1=SPACE; code=SPECIAL_KEY;}
	   if(code == SPECIAL_KEY)
            {
	     if(code1 !=SPACE)  code1 = getch();
	     switch (code1)
	       {
			   case PgUp:    keuze -=20;      break;
	                   case PgDn:    keuze +=20;      break;
			   case UP:
			   case LEFT:    --keuze;         break;
			   case SPACE:
			   case DOWN:
			   case RIGHT:   ++keuze;         break;
			   case HOME:
			   case ENDT:    keuze = num-1;   break;
               }
			   if(keuze < 0)   keuze = num-1;
			   if(keuze > num-1)   keuze = 0;
	     }
	   else
		{
		  ch = code;  keus=keuze;  leave=0;   keer=-1;
		  while(keer<2)
		   {
		    keer++;
		    if(keer==1) { keus=-1;}
		    for(y=keus+1; y<num; y++)
		     {
		      if(strnicmp(&titel[y][0],&ch,1) == 0)
			{ keuze = y; oke = 0; leave=1;  keer=2;  }
		      if(leave) break;
		     }
		    }
		  oke = 1;
		  if(ch == ESC) {    keuze = -1;   oke = 1;   }
		}
	}
}


void stuiteren(void)
{
int x,y,xx,yy,xoud,youd,ymax,yyy;
char str[30];
long secs_now;
char *str_now;

xx=55;
yy=0;
youd=0;
yyy=1;
ymax=16;
	  while(bioskey(1)==0)
		{
		 time(&secs_now);
		 str_now=ctime(&secs_now);
		 xx=55;
		 str_now[24]='\0';
		 yy+=yyy;
		 if(yyy<0 && yy<ymax) {yyy= 1; ymax=(24-ymax)*2/3;}
		 if(yyy>0 && yy>23)   yyy=-1;
		 swrite(xx,yy,str_now,0x1300);
                 lveeg(youd,55,1,25,'�',0x2500);
                 youd=yy;
                 if(ymax>22) {ymax=16;yyy=1;yy=0;}
                 delay(100);
		 }



}
/********************** LOAD MENU ********************************/
int load_menu()
{
   int nr=QUIT+1;
	  strcpy(titel[0],"Invoer                    \0");
	  strcpy(titel[1],"Laad/Save                 \0");
	  strcpy(titel[2],"Maak overzichtslijst      \0");
	  strcpy(titel[3],"@Laad PRN file/New        \0");
	  strcpy(titel[4],"Wissen/toevoegen/editen   \0");
	  strcpy(titel[5],"Password                  \0");
	  strcpy(titel[6],"Andere drive / directory  \0");
	  strcpy(titel[7],"Tekst editor              \0");
	  strcpy(titel[8],"Go                        \0");
	  strcpy(titel[9],"Quit en save              \0");
  return(nr);
 }



/***************** haal datum uit ffblk.ff_fdate ************************/
void makedate(int *d, int *m, int *y,unsigned dosdate)
{
 *m = (dosdate >>5)&0XF;
 *d = dosdate & 0x1F;
 *y = (dosdate >>9) & 0X3F;
 *y += 80;
 }


/* Directory listen op scherm en keuze maken ****************************** */
/*                                                                          */
/* char dir 			zoek sleutel directory                      */
/*                                                                          */
/* ************************************************************************ */

char *filedir(char *filein)
{
   char nop[30];
   int y,leave;
   static char filenaam[250][30];   /* nr,breedte filenaam + datum*/
   char ch;			    /* te printen char */
   int begin = 0;                   /* 1e file uit blok van 25 dat geprint word */
   int keuze = 0;		    /* nummer gekozen file */
   int num = 0;                     /* aantal files */
   int oke;                         /* 0 = geen keuze ESC 1 = keuze RETURN */
   int toets;			    /* toetsaanslag via getch() */
   int pos = 0;			    /* positie binnen filenaam */
   int veld;			    /* nummer van filenaam */
   int x = 0;			    /* teller */
   int xx =0;                       /* row waar geprint moet worden */
   int yy = 0;                      /* colom waar geprint moet worden */
/*   int maxaantal = 110; */        /* aantal files per beeldscherm */
   int keus=0;
   int keer=0;
   int day,month,year;

   oke = findfirst((char *)filein,&ffblk,0);
   while (!oke)
      {
       sscanf(ffblk.ff_name,"%s", &nop);
       makedate(&day,&month,&year,ffblk.ff_fdate);
       sprintf(filenaam[x],"%12.12s %2.2d-%2.2d-%2.2d",nop,day,month,year);
       if(++x == 250)
	{
	 sound(100);
	 nosound();
	 sound(1000);
	 swrite(10,10,"Niet alle files ingelezen\0",0x0200);
	 swrite(10,11,"Max. is 250 files\0",0x0200);
	 delay(50);
	 nosound();
	 sleep(3);
	 break;
	}
      oke = findnext(&ffblk);
      }
   num = x;
   oke = 0;

   box(0,6,(num/3)+1,69,2,1);

   while (1)
    {
    for(veld = begin; veld < begin + num; veld++)
     {
      yy = 1 + (veld - begin) / 3;
      xx = 8 + (((veld - begin) % 3) * 22);
      if(veld < num)
       {
       for(pos = 0; pos < 21; pos++, xx++)
	{
	 if(pos < strlen((char *)filenaam[veld]) )
	       ch = (filenaam[veld][pos]);
	 else  ch = SPACE;
	    if (veld == keuze) *(SCHERMPTR + yy * 80 + xx) = ch | CHHIG;
	    else               *(SCHERMPTR + yy * 80 + xx) = ch | CHINV;
	 }
	}
	 else
	   for(pos = 0; pos < 21; pos++, xx++)
			       *(SCHERMPTR + yy * 80 + xx) = SPACE | CHINV;
     }
    if(oke > 0)
      {
	veeg(0,6,25,69);
	if(oke==1) return((char*)"");
	 else
	  {
	   filenaam[keuze][12]=0;
	   return((char*)remove_lt_space(filenaam[keuze]));
	  }
      }
    toets = getch();
    if(toets == SPECIAL_KEY)
     {
      toets = getch();
      switch (toets)
	{
	   case UP:      keuze -= 3;      break;
	   case LEFT:  --keuze;           break;
	   case DOWN:    keuze += 3;      break;
	   case RIGHT: ++keuze;           break;
	   case HOME:    keuze = 0;       break;
	   case ENDT:    keuze = num - 1; break;
	}
      if(keuze < 0)          keuze = num - 1;
      if(keuze > num - 1)    keuze = 0;
/*    if(keuze > num - 1)    keuze = num - 1;
*/    if(keuze < 25)         begin = 0;
      else                   begin = ((keuze - 20) / 3 ) * 3;
     }
     else
      {
       ch = toets;
       keus=keuze;
       leave=0;
       keer=-1;
       while(keer<2)
	 {
	   keer++;
	   if(keer==1) { keus=-1;}
	     for(y=keus+1; y<num; y++)
	      {
	       if(strnicmp(&filenaam[y][0],&ch,1) == 0)
		  {
		    keuze = y;  oke = 0; leave=1;  keer=2;
		    if(keuze < 25)  begin = 0;
		    else  begin = ((keuze - 20) / 3 ) * 3;
		  }
	       if(leave) break;
	       }
	  }

    if(ch == RETURN)   oke = 2;
    if(ch == ESC) { keuze=-1;   oke = 1;}
   }
  }
}

/************************** CHANGE DIR *****************************/
void changedir(char *filein)
{
if ( parse((char *)filein) )
     {
      swrite(5,23,"Illegal drive input ",0x1300);
      sleep(1);
     }
else setdisk(disk);
if(chdir(directory))
     {
       swrite(5,23,"Illegal dir input ",0x1300);
       sleep(1);
     }
}

int parse(char *ptr)
{
 if ( ptr[1] == ':')
   {
	disk = (unsigned) toupper( ptr[0]) - 'A';
	if (disk > MAXDISK)         return(-1);
    directory = ptr+ 2;
   }
 else    {   disk=getdisk();     directory=ptr;     }
if (*directory=='\0') directory=".";
return(0);
}

/* printen box op het scherm ********************************************** */
/*                                                                          */
/* int topy			row waar box geprint moet worden            */
/* int topx			col waar box geprint moet worden            */
/* int lang			lengte box                                  */
/* int breed		        breedte box                                 */
/* int type			1 = enkel  2 = dubbel                       */
/* int kleur		        0 = norm  1 = invers  2 = high              */
/*                                                                          */
/* ************************************************************************ */

void box(int topy,int topx,int lang,int breed,int type,int kleur)
{
   int x;			/* teller */
   int y;                       /* teller */
   int z;                       /* teller */
   unsigned int ch;		/* horizontale streep */
   unsigned int ck;		/* kleur die geprint moet worden */
   unsigned int clb;		/* hoek links boven */
   unsigned int crb;            /* hoek rechts boven */
   unsigned int clo;            /* hoek links onder */
   unsigned int cro;            /* hoek rechts onder */
   unsigned int cv;             /* verticale streep */

   switch (type)
      {
      case 1:
	 clb = '�'; crb = '�';
         clo = '�'; cro = '�';
         ch  = '�';  cv  = '�';
         break;
      case 2:
         clb = '�'; crb = '�';
	 clo = '�'; cro = '�';
         ch  = '�';  cv  = '�';
         break;
      }
   switch(kleur)
      {
      case 0: ck = CHNOR; break;
      case 1: ck = CHINV; break;
      case 2: ck = CHHIG; break;
      }

   z = 0;
   PTR = SCHERMPTR + (topy + z) * 80 + topx ;
				       *(PTR)               = clb | ck;
   for(x = 1; x < breed - 1; x++)      *(PTR + x)           = ch  | ck;
				       *(PTR + (breed - 1)) = crb | ck;
   for(x = 0; x < lang; x++)
      {
      z = x + 1;
	  PTR = SCHERMPTR + (topy + z) * 80 + topx ;
					   *(PTR)               = cv | ck;
	  for(y = 1; y < breed - 1; y++)   *(PTR + y)           = SPACE | ck;
					   *(PTR + (breed - 1)) = cv | ck;
      }
	z = lang + 1 ;
	PTR = SCHERMPTR + (topy + z) * 80 + topx ;
				       *(PTR)               = clo | ck;
   for(x = 1; x < breed - 1; x++)      *(PTR + x)           = ch  | ck;
				       *(PTR + (breed - 1)) = cro | ck;
}


/***********************  write text  ****************/

void swrite(int posx,int posy,char * tekst,int kleur)
{
   int far *nop= SCHERMPTR + posy*80 + posx;
   int x=0;
   for(;tekst[x];*(nop+x) = tekst[x++] | kleur);
}

void twrite(int posx,int posy,char * tekst,int forground,int background)
{
   int far *nop= SCHERMPTR + posy*80 + posx;
   int x=0;
   unsigned int kleur = (background<<12) + (forground<<8);
   for(;tekst[x]; *(nop+x) = tekst[x++] | kleur);
}

/********************** init display *********************/
void initdisplay(void)
{
union REGS reg;
reg.h.ah=15;
int86(0X10,&reg,&reg);
SCHERMPTR=(int  *far)( (reg.h.al == 7) ? 0XB0000000L : 0XB8000000L);
}

void veeg(int topy,int topx,int totl,int totb)       /* veeg scherm schoon */
{
   int y, x;
   for(y=topy; y<topy+totl; y++)
      for(x=topx; x<topx+totb; x++)
		 *(SCHERMPTR + y*80 + x) = SPACE | 0x0700;
}

void lveeg(int topy,int topx,int totl,int totb,char kar,unsigned kleur)
{
/*   int y, x;
   unsigned k1 = 0x0000 +kleur;
   unsigned k2 = 0x0100;
   for(y=topy; y<topy+totl; y++)
	{
	  k1+=0x0100;
	  kleur = k1 + k2;
	  for(x=topx; x<topx+totb; x++)
	   {
	   kleur += k2;
		  if (((kleur& 0x8000)-0x8000)==0)  kleur = 0x0000;
 		 *(SCHERMPTR + y*80 + x) = kar | kleur;
	   }
	 }
*/
   int y, x;
   for(y=topy; y<topy+totl; y++)
	  for(x=topx; x<topx+totb; x++)
		 *(SCHERMPTR + y*80 + x) = kar | kleur;

}


/**************** PRINTER TEST   EJN 040388   ********************
Dit programma test of de printer op printen staat en blijft dit
testen totdat negen pogingen zijn ondernomen
*/
int prntest(void)
{
int i,j,n,count;

count=0;
while(count<9)
 {
  count++;
  n= biosprint(2,0,0);
  if( n == 0x90) break;
  nosound();
  sound(9000);
  veeg(0,0,25,80);
  if (count>3)
     {
       printf("\n**********************************\n"
	      "*       It does not work        *\n"
	      "*        CALL FOR HELP          *\n"
	      "*********************************\n");
	  nosound();
     }
  printf("\n\n\n\nERROR %x ",n);
  if ((n & 0x01) ==0x01)
	     puts("\n         Printer Device time out error");
  if ((n & 0x08) ==0x08)
	     puts("\n         Printer I/O error");
  if ((n & 0x10) == 0x10)
	     puts("\n         Printer not ONLINE");
  if ((n & 0x20) == 0x20)
	     puts("\n         Printer Out of paper");
  if ((n & 0x40) == 0x40)
	     puts("\n         Printer is OFF");
  if ((n & 0x80) == 0x80)
	     puts("\n         Printer NOT BUSY");
  puts("Press a key after solving the error");
  while(bioskey(1)==0);
  i=getch();
  nosound();
  if(i==27) return 0;
  }
  return 1;
 }

/************  remove kleiner dan spatie ***************/
char *remove_lt_space(char *inputline)
{
int n;
char nop[1024];
strcpy(nop,strrev(inputline));
for(n=strlen(nop);n>=0;n--)	{ if(nop[n]<=' ') nop[n]=0; else break;}
strcpy(inputline,strrev(nop));
for(n=strlen(inputline);n>=0;n--)
	 { if(inputline[n] <= ' ') inputline[n]=0; else break;}
return(inputline);
}

double getd(FILE *fp)
{
 double a;
 char *b;
 int i,j;
  b=(char *) &a;
  for (i=0;i<sizeof(double);++i)
   {
    if((j = getc(fp)) == EOF) return(-1.0);
    b[i]= j & 0xFF;
   }
return(a);
}



/******************** TEST OF PRINTER AAN OF UIT ************************/
void prnonoff(void)
{
 if(biosprint(2,0,0)  != 0x90)
 {
  sound(2200);
  delay(13);
  nosound();
  sound(200);
  delay(300);
  nosound();
  exit(-1);
 }
/* Verlaat het programma als de printer uitstaat*/
 }

/*************************  INITIALIZE *****************************/

void Initialize(void)
{
}

/************************ malloc data ************************/

void mallocdata(void)
 {
   int n;


   /* struct vak */
   wie = (struct vak **)calloc((MAX_ROW) , sizeof(struct vak *) );
   for (n=0;n < MAX_ROW+1;n++)
   {
    wie[n] = (struct vak *) calloc(1,sizeof(struct vak));
     if (wie[n]==0)
	   {
	    printf("%u coreleft\n\n",coreleft());
	    puts("TOO LESS MEMORY\n");
	    exit(-1);
	   }
   }
}
/***************** DEALLOCEER DATA *************************************/
void freemallocdata(void)
{
  int n;
  for (n=MAX_ROW; n >= 0;n--)	free(wie[n]);     free(wie);
}
/*************************READ PRT FILE *******************************/
void readprn(char *filein)
{
   int n,fout,row,nentrie;
   char  inputline[1024];
   long count;
   char *token,nop[80],nopp[25];
   char getal[8];
   float bars;
   int nieuwjaar=0;

   cputs("Wil je alle rondes bij iedereen wissen?\r\n");
   cputs("Doe dit alleen als je een nieuwe backup disk hebt genomen.\r\n");
   cputs("Plak de oude disk af zodat er niet meer op geschreven kan worden\r\n");
   cputs("en stop een nieuwe, geformateerde flop in de a: drive\r\n");
   cputs("\r\n\nWil je nog steeds alle afgeschreven rondes bij iedereen wissen?\r\n");
   cputs("(j/n)");
   n=getch();
   if(n=='j' || n=='J')
     {
      cputs("\r\n\nZEKER WETEN ?  (j/n)");
      n=getch();
      if(n=='j' || n=='J') nieuwjaar=TRUE;
     }

   printf("\n\nInlezen %s ",filein);

   if ((fpin=fopen(filein,"r")) == NULL)
	{
	   printf("cannot open input-file %s\n",filein);
	   exit(1);
	}

  swrite(30,10,"���������������������Ŀ",0x1700);
  swrite(30,11,"�                     �",0x1700);
  swrite(30,12,"�����������������������",0x1700);
  swrite(30,13,"0%        50%      100%",0x2700);
  strcpy(nopp,"                     ");
   count=0;
   row=0;
   bars=(float)( filelength(fileno(fpin)) ) / 21;

   while(TRUE)
	{
	  if(fgets(inputline,1024,fpin)==NULL)    break;
	  count+=strlen(inputline)+2;
	  strnset(nopp,176,(int)((float)count/bars));
	  swrite(31,11,nopp,BARCOLOR);
/*	  strcpy(nop,"  ");
	  strcat(nop,inputline);
*/	  strcpy(inputline,remove_lt_space(inputline));

	  fout=FALSE;
	  if(strlen(inputline)<3)  fout=TRUE;
	  if(inputline[0]==';')    fout=TRUE;
	  if(row>=MAX_ROW-3) {lost=TRUE; fout=TRUE;}
	  if(!fout)
	  {

	  strcpy(nop,strtok(inputline,","));
	  nop[MAX_LEN_NAAM-1]=0;
	  strcpy(wie[row]->naam,nop);

	  strcpy(nop,strtok(NULL,","));
	  nop[MAX_LEN_ADRES-1]=0;
	  strcpy(wie[row]->adres,nop);

	  strcpy(nop,strtok(NULL,","));
	  nop[MAX_LEN_PLAATS-1]=0;
	  strcpy(wie[row]->plaats,nop);

	  strcpy(nop,strtok(NULL,","));
	  nop[MAX_LEN_LAB]=0;
	  strcpy(wie[row]->lab,nop);

	  strcpy(nop,strtok(NULL,","));
	  nop[MAX_LEN_TELNR-1]=0;
	  strcpy(wie[row]->telnr,nop);


	  strcpy(nop,strtok(NULL,","));
	  wie[row]->lidnr=atol(nop);


	  if(!nieuwjaar){/* Entries niet meenemen*/
	  nentrie=0;
	  while(strcpy(nop,strtok(NULL,","))!=NULL)
	       {
	     if(nop[0]=='|') break;
		    wie[row]->dag[nentrie].serumnr=atol(nop);
		    strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[nentrie].techniek =nop[0];
		    strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[nentrie].standaard=nop[0];
	     strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[nentrie].IgG1=atof(nop);
	     strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[nentrie].IgG2=atof(nop);
	     strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[nentrie].IgG3=atof(nop);
	     strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[nentrie].IgG4=atof(nop);
	     strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[nentrie].IgG=atof(nop);
	     strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[nentrie].IgGsom=atof(nop);
	     strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[nentrie].IgGdev=atof(nop);
	      if(++nentrie > MAX_RONDEN-1) {corrupted=TRUE; break;}
	       }
			}
	  row++;
	  if(row+2 > MAX_ROW) {lost=TRUE; break;}
	  }
	}
rows=row;
fclose(fpin);
}

/********************* edit fields ********************/

void edit_fields(void)
{
int persoon;
clrscr();
persoon=0;

while (persoon!=999)
{
persoon=kiesnaam("**AFSCHRIJVEN** Kies een naam door de eerste letter te drukken");
if(persoon != 999 ) display_persoon(persoon);
}
window(1,1,80,25);

}


/********************* kies naam **************************/
int kiesnaam(char *text)
{
   char nop[80];
   int m,n,y,leave;
   char ch;			/* te printen char */
   int begin = 0;               /* 1e file uit blok van 25 dat geprint word */
   int keuze = 0;		/* nummer gekozen file */
   int num = 0;                 /* aantal files */
   int oke;                     /* 0 = geen keuze ESC 1 = keuze RETURN */
   int toets;			/* toetsaanslag via getch() */
   int pos = 0;			/* positie binnen filenaam */
   int veld;			/* nummer van filenaam */
   int xx =0;                   /* row waar geprint moet worden */
   int yy = 0;                  /* colom waar geprint moet worden */
   int keus=0;
   int keer=0;
   char volnaam[82];
   struct date d;

  window(1,1,80,25);
  clrscr();
  gotoxy(1,1);
  textcolor(YELLOW);
  highvideo();
  cprintf("%s",text);
  normvideo();
   for(n=0;n<MAX_ROW;n++)
      {
      if(wie[n]->naam[0]==0 && wie[n]->plaats[0]==0) break;
      num++;
      }
   while (1)
    {
    oke=0;
    m=begin+24;
    if(m>num) m=num;
    for(veld = begin; veld < begin+24; veld++)
     {
      yy = 2 + (veld - begin);
      xx = 0;
      if(veld < num)
       {
       sprintf(volnaam,"%-30s %-15s  %-30s",wie[veld]->naam,wie[veld]->plaats,wie[veld]->lab);
       for(pos = 0; pos < strlen(volnaam); pos++, xx++)
	{
	  ch = (volnaam[pos]);
	  if (veld == keuze) *(SCHERMPTR + yy * 80 + xx) = ch | CHINV;
	  else               *(SCHERMPTR + yy * 80 + xx) = ch | CHNOR;
	 }
	}
	 else
	   for(pos = 0; pos < 80; pos++, xx++)
			     *(SCHERMPTR + yy * 80 + xx) = SPACE | CHNOR;

     }
    if(oke > 0)
      {
	veeg(0,0,25,80);
	if(oke==1) return(999);
	 else	   return(keuze);
      }
    toets = getch();
    if(toets == SPECIAL_KEY)
     {
      toets = getch();
      switch (toets)
	{
	   case PgUp:    keuze -=20;      break;
	   case PgDn:    keuze +=20;      break;
	   case UP:      keuze -= 1;      break;
	   case LEFT:  --keuze;           break;
	   case DOWN:    keuze += 1;      break;
	   case RIGHT: ++keuze;           break;
	   case HOME:    keuze = 0;       break;
	   case ENDT:    keuze = num - 1; break;
	}
      if(keuze < 0)          keuze = num - 1;
      if(keuze > num - 1)    keuze = 0;
      if(keuze>20)           begin = keuze - 20;
      else                   begin = 0;
     }
     else
      {
       ch = toets;
       keus=keuze;
       leave=0;
       keer=-1;
       while(keer<2 && ch>31)
	 {
	   keer++;
	   if(keer==1) { keus=-1;}
	     for(y=keus+1; y<num; y++)
	      {
	       if(strnicmp(&wie[y]->naam[0],&ch,1) == 0)
		  {
		    keuze = y;  oke = 0; leave=1;  keer=2;
		    if(keuze < 20)  begin = 0;
		    else  begin = keuze - 20;
		  }
	       if(leave) break;
	       }
	  }

    if(ch == RETURN)  { oke = 2; return(keuze); }
    if(ch == ESC) { keuze=-1;   oke = 1; return(999); }
    if(ch == '@') {
    if(!prntest()) return(999);
    getdate(&d);
    fprintf(printer,"Printdatum : %d-%d-%d\n",d.da_day,d.da_mon,d.da_year);
    for(veld=0;veld<num;veld++)
       fprintf(printer," %-30s %-30s \n",wie[veld]->naam,wie[veld]->lab);
       fprintf(printer,"\f");
       fflush(printer);
     keuze=-1;   oke = 1; return(999); }
   }
  }
}
/****************** save data ***************************/
int save_data(void)
{
   FILE *stream;
   int n,i;
   long count;
   float bars;
   char nopp[30];
   int persoon,ndag;

   clrscr();

   strcpy(fileout,filename);
   strcat(fileout,".SUB");
   if ((stream = fopen(fileout, "wb")) == NULL) /* open file TEST.$$$ */
   {
      fprintf(stderr, "Cannot open output file.\n");
      getch();
      return 0;
   }
  printf("\n\nSchrijven %s ",fileout);
  swrite(30,10,"���������������������Ŀ",0x1700);
  swrite(30,11,"�                     �",0x1700);
  swrite(30,12,"�����������������������",0x1700);
  swrite(30,13,"0%        50%      100%",0x2000);
  strcpy(nopp,"                     ");

rows=0;
  for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->plaats[0]==0) break;

  count=0;
  bars=(float)( rows*sizeof(struct vak )) / 21;

 fwrite(&rows, sizeof(int), 1, stream); /* write struct vak to file */

  for(n=0;n<rows;n++)
    {
    wie[n]->check=CHECKCODE;
    fwrite(wie[n], sizeof(struct vak), 1, stream); /* write struct vak to file */
    count+=sizeof(struct vak);
    strnset(nopp,176,(int)((float)count/bars));
    swrite(31,11,nopp,BARCOLOR);
    }

  if(fclose(stream))        /* close file */
    {clrscr();
     puts("Er is iets mis met saven gegaan, Disk full??");
     puts("Doe je computer uit en copieer het backup bestand");
     getch();
     getch();
     getch();
     getch();
    }

   strcpy(fileout,filename);
   strcat(fileout,".PRN");

     if ((stream = fopen(fileout, "w")) == NULL)
       {
	 fprintf(stderr, "Cannot open output file %s.\n",fileout);
	 getch();
	 return 0;
	}


rows=0;
  for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->plaats[0]==0) break;

      for(n=0;n<rows;n++)
	 {
	  fprintf(stream,"%s,%s,%s,%s,%s,%ld",
	     wie[n]->naam,
	     wie[n]->adres,
	     wie[n]->plaats,
	     wie[n]->lab,
	     wie[n]->telnr,
	     wie[n]->lidnr
	   );
	     ndag=0;
	 while(wie[n]->dag[ndag].techniek!=0)
	  {
	   fprintf(stream,",%ld,%c,%c,%f,%f,%f,%f,%f,%f,%f,%f",
	     wie[n]->dag[ndag].serumnr,
	     wie[n]->dag[ndag].techniek,
	     wie[n]->dag[ndag].standaard,
	     wie[n]->dag[ndag].IgG1,
	     wie[n]->dag[ndag].IgG2,
	     wie[n]->dag[ndag].IgG3,
	     wie[n]->dag[ndag].IgG4,
	     wie[n]->dag[ndag].IgG,
	     wie[n]->dag[ndag].IgGsom,
	     wie[n]->dag[ndag].IgGdev   );
	   ndag++;
	  }
	   fprintf(stream,",|\n");
	  }
  if(fclose(stream))        /* close file */
    {clrscr();
     puts("Er is iets mis met saven gegaan, Disk full??");
     puts("Doe je computer uit en copieer het backup bestand");
     getch();
     getch();
     getch();
     getch();
    }
   return 1;
}

/*****************   load_data(void)*****************/
int load_data(void)
{
   FILE *stream;
   int n;
   long count;
   float bars;
   char nopp[30];

   clrscr();

   if ((stream = fopen(fileload, "rb"))
       == NULL)
   {
      fprintf(stderr,
	      "Cannot open input file.\n");
      getch();
      return 0;
   }
   printf("\n\nInlezen %s ",fileload);
  swrite(30,10,"���������������������Ŀ",0x1700);
  swrite(30,11,"�                     �",0x1700);
  swrite(30,12,"�����������������������",0x1700);
  swrite(30,13,"0%        50%      100%",0x2400);
  strcpy(nopp,"                     ");

  count=0;
  bars=(float)( filelength(fileno(stream)) ) / 21;

 fread(&rows, sizeof(int), 1, stream); /* read aantal entries */

  for(n=0;n<rows;n++)
    {
     if(n>MAX_ROW-3) {lost=TRUE; break;}
     fread(wie[n], sizeof(struct vak), 1, stream); /* read struct vak to file */
     count+=sizeof(struct vak);
     if(wie[n]->check != CHECKCODE)
       {
	 cputs("\r\nEr klopt iets niet met deze file\r\n");
	 cputs("Lees de backup file in\r\n");
	 getch();
	 return(0);
       }
     strnset(nopp,176,(int)((float)count/bars));
     swrite(31,11,nopp,BARCOLOR);
    }
  fclose(stream);
  return 1;
}
/********************* display en edit persoon *****************/
int display_persoon(int pers)
{
int i,j,m,n;
long nrronde;
char text[80];
char Text[10][10];
char cc,ss;

while(TRUE)
{

prnt_pers_id(pers);

window(1,8,80,21);
n=0;

/*while(wie[pers]->dag[n++].techniek!=0)
if(n>=MAX_RONDEN-2)
  delete_entry(pers,0);
*/

textbackground(LIGHTGRAY);
textcolor(BLACK);
clrscr();


window(1,7,80,11);
textbackground(LIGHTGRAY);
textcolor(BLACK);
clrscr();
gotoxy(1,1);

/*
for(n=0;n<=MAX_RONDEN-2;n++)
 {if( wie[pers]->dag[n].serumnr==nrronde) break;}

 if(n>=MAX_RONDEN-3)  for(n=0;wie[pers]->dag[n].serumnr!=0;++n);
*/

cputs(  "No Tech  Std  IgG1   IgG2   IgG3   IgG4   IgG    IgGsom  IgGdev");
textcolor(RED);
for (n=0;n<3;n++){
cprintf("\r\n%3ld  %c    %c  %5.2f  %5.2f  %5.2f  %5.2f  %5.2f  %5.2f  %5.2f",
wie[pers]->dag[n].serumnr,
wie[pers]->dag[n].techniek,
wie[pers]->dag[n].standaard,
wie[pers]->dag[n].IgG1,
wie[pers]->dag[n].IgG2,
wie[pers]->dag[n].IgG3,
wie[pers]->dag[n].IgG4,
wie[pers]->dag[n].IgG ,
wie[pers]->dag[n].IgGsom,
wie[pers]->dag[n].IgGdev);
}
textbackground(BLACK);
textcolor(WHITE);

window(1,11,80,25);

normvideo();
clrscr();
window(1,12,80,25);


while(bioskey(1)) getch();

while (TRUE)
{
 gotoxy(1,1);
 cputs(" Rondenr         : .              Voer niets in om te stoppen");
 gotoxy(20,1);
 gets(text);
 if(text[0]<48 || text[0]>57) { window(1,1,80,25); clrscr(); return 1;}
 nrronde=atol(text);
 if ( nrronde>0 && nrronde <4) break;
}
 gotoxy(1,2);
 cputs(" Techniek        : .               Voer niets in om te stoppen");
 gotoxy(20,2);
 cc=getche();
 if(cc<64) { window(1,1,80,25); clrscr(); return 1;}
 if(cc>96) cc-=32;

 gotoxy(1,3);
 cputs(" Standaard       : .                                           ");
 gotoxy(20,3);
 ss=getche();
 if(ss<64) { window(1,1,80,25); clrscr(); return 1;}
 if(ss>96) ss-=32;

while (TRUE)
{
 gotoxy(1,4);
 cputs(" IgG1            : ______          ");
 gotoxy(20,4);
 gets(text);
 if(text[0]==32)  return 0;
 if(strlen(text)==0) {strcpy(Text[0],"0"); break;}
 text[MAX_LEN_DATUM-1]=0;
 if(! strlen(text))  {sound(600); delay(100); nosound(); continue;}
 strcpy(Text[0],text);
 break;
}

while (TRUE)
{
 gotoxy(1,5);
 cputs(" IgG2            : ______       ");
 gotoxy(20,5);
 gets(text);
 if(text[0]==32)  return 0;
 if(strlen(text)==0) {strcpy(Text[1],"0"); break;}
 text[MAX_LEN_DATUM-1]=0;
 if(! strlen(text))  {sound(600); delay(100); nosound(); continue;}
 strcpy(Text[1],text);
 break;
}
while (TRUE)
{
 gotoxy(1,6);
 cputs(" IgG3            : ______       ");
 gotoxy(20,6);
 gets(text);
 if(text[0]==32)  return 0;
 if(strlen(text)==0) {strcpy(Text[2],"0"); break;}
 text[MAX_LEN_DATUM-1]=0;
 if(! strlen(text))  {sound(600); delay(100); nosound(); continue;}
 strcpy(Text[2],text);
 break;
}


while (TRUE)
{
 gotoxy(1,7);
 cputs(" IgG4            : ______       ");
 gotoxy(20,7);
 gets(text);
 if(text[0]==32)  return 0;
 if(strlen(text)==0) {strcpy(Text[3],"0"); break;}
 text[MAX_LEN_DATUM-1]=0;
 if(! strlen(text))  {sound(600); delay(100); nosound(); continue;}
 strcpy(Text[3],text);
 break;
}

while (TRUE)
{
 gotoxy(1,8);
 cputs(" IgG             : ______       ");
 gotoxy(20,8);
 gets(text);
 if(text[0]==32)  return 0;
 if(strlen(text)==0) {strcpy(Text[4],"0"); break;}
 text[MAX_LEN_DATUM-1]=0;
 if(! strlen(text))  {sound(600); delay(100); nosound(); continue;}
 strcpy(Text[4],text);
 break;
}

n=nrronde-1;
wie[pers]->dag[n].serumnr=nrronde;
wie[pers]->dag[n].techniek=cc;
wie[pers]->dag[n].standaard=ss;
wie[pers]->dag[n].IgG1=atof(Text[0]);
wie[pers]->dag[n].IgG2=atof(Text[1]);
wie[pers]->dag[n].IgG3=atof(Text[2]);
wie[pers]->dag[n].IgG4=atof(Text[3]);
wie[pers]->dag[n].IgG =atof(Text[4]);

   if(wie[pers]->dag[n].IgG1 > 0
   && wie[pers]->dag[n].IgG2 > 0
   && wie[pers]->dag[n].IgG3 > 0
   && wie[pers]->dag[n].IgG4 > 0)

      wie[pers]->dag[n].IgGsom =
      wie[pers]->dag[n].IgG1 +  wie[pers]->dag[n].IgG2 +
      wie[pers]->dag[n].IgG3 +  wie[pers]->dag[n].IgG4 ;
      wie[pers]->dag[n].IgGdev =
      (( wie[pers]->dag[n].IgGsom - wie[pers]->dag[n].IgG) /
       wie[pers]->dag[n].IgG ) *100;

}

}


/******************** persoon_editen ***********************/
int    persoon_editen(void)
{
char text[90];
int persoon,pers;

clrscr();
persoon=0;
  for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->plaats[0]==0) break;


persoon=kiesnaam("** EDIT **      Druk escape om toe te voegen");


if(persoon==999)
 pers=rows;
  else pers=persoon;
  if(rows>=MAX_ROW-3) {lost=TRUE; return 0;}

prnt_pers_id(pers);
gotoxy(5,10);
cputs("Voer een SPATIE in een veld in om invoeren te verlaten");
while(TRUE)
{
 window(1,12,80,25);
 clrscr();
 gotoxy(1,1);
 gotoxy(1,2);
 cputs("      Naam :");
 gotoxy(1,3);
 cputs("     Adres :");
 gotoxy(1,4);
 cputs("Woonplaats :");
 gotoxy(1,5);
 cputs("     Telnr :");
 gotoxy(1,6);
 cputs("     Lidnr :");
 gotoxy(1,7);
 cputs("       Lab :");


 gotoxy(1,1);
 cputs("  Type in: @, om persoon te wissen");


 gotoxy(1,2);
 cputs("      Naam : .......................................");
 gotoxy(14,2);
 gets(text);
 if(text[0]==32) return 0;
 text[MAX_LEN_NAAM-1]=0;
 if(strcmp(text,"@")==0) { wissen(pers); return 0; }
 if(strlen(text))
   strcpy(wie[pers]->naam,text);
 if(wie[pers]->naam[0]==0) strcpy(wie[pers]->naam,"?");

 gotoxy(1,3);
 cputs("     Adres : ............................................................");
 gotoxy(14,3);
 gets(text);
 if(text[0]==32) return 0;
 text[MAX_LEN_ADRES-1]=0;
 if(strlen(text))
   strcpy(wie[pers]->adres,text);
 if(wie[pers]->adres[0]==0) strcpy(wie[pers]->adres,"?");

 gotoxy(1,4);
 cputs("Woonplaats : ..................................................");
 gotoxy(14,4);
 gets(text);
 if(text[0]==32) return 0;
 text[MAX_LEN_PLAATS-1]=0;
 if(strlen(text))
   strcpy(wie[pers]->plaats,text);
 if(wie[pers]->plaats[0]==0) strcpy(wie[pers]->plaats,"?");

 gotoxy(1,5);
 cputs("     Telnr : .............");
 gotoxy(14,5);
 gets(text);
 if(text[0]==32) return 0;
 text[MAX_LEN_TELNR-1]=0;
 if(strlen(text))
    strcpy(wie[pers]->telnr,text);
 if(wie[pers]->telnr[0]==0) strcpy(wie[pers]->telnr,"?");

 gotoxy(1,6);
 cputs("     Lidnr : .....");
 gotoxy(14,6);
 gets(text);
 if(text[0]==32) return 0;
 if(strlen(text))
  wie[pers]->lidnr=atol(text);

 gotoxy(1,7);
 cputs("       Lab : .................................................");
 gotoxy(14,7);
 gets(text);
 text[MAX_LEN_LAB-1]=0;
 if(text[0]==32) return 0;
 if(strlen(text))
    strcpy(wie[pers]->lab,text);
 if(wie[pers]->lab[0]==0) strcpy(wie[pers]->lab,"?");

 prnt_pers_id(pers);

 gotoxy(5,12);
 cputs(" OK? Return = OK ");
 if(getch()==13) break;

}
 gotoxy(5,15);
 cputs("Ben aan het sorteren");
 for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->plaats[0]==0) break;

if(rows>2) csort(rows);
window(1,1,80,25);
clrscr();
return 0;
 }


/************* print persoons personalia ********************/
void prnt_pers_id(int pers)
{
window(1,1,80,25);
clrscr();
highvideo();
textcolor(BLUE);
gotoxy(1,1);
cprintf("      Naam : %s",wie[pers]->naam);
gotoxy(1,2);
cprintf("     Adres : %-60s",wie[pers]->adres);
gotoxy(1,3);
cprintf("Woonplaats : %-30s",wie[pers]->plaats);
gotoxy(1,4);
cprintf("     Telnr : %-7s",wie[pers]->telnr);
gotoxy(25,4);
cprintf("     Lidnr : %-ld",wie[pers]->lidnr);
gotoxy(1,5);
cprintf("       Lab : %-30s",wie[pers]->lab);
normvideo();

cputs("\r\n--------------------------------------------------------------------------------");
}

/**************  persoon wissen ******************************/
void wissen(int pers)
{
int n;
for (n=pers;n<MAX_ROW;n++)
	 memcpy(wie[n],wie[n+1],sizeof(struct vak));
}

/************** delete dag ************************/
void delete_entry(int pers,int dagnr)
{
 int n,entry,noofentries=0;
 char text[80];

 wie[pers]->dag[MAX_RONDEN-1].techniek=0;

 if(dagnr==999)
   {
    gotoxy(1,3);
    cputs("Welke no wissen : ..");
    gotoxy(19,3);
    gets(text);
    if(text[2]==0);
    if(strlen(text)==0) return;
    entry=atoi(text)-1;

    while(wie[pers]->dag[noofentries].techniek!=0)
		  noofentries++;

    if(entry > noofentries)
      { gotoxy(25,3);
	puts("Bestaat niet,  Druk een toets");
	   sound(50);
	   nosound();
	   sound(50);
	   delay(200);
	   nosound();
	getch();
	return;
       }
    for (n=entry;n<MAX_RONDEN-2;n++)
	 memcpy(&wie[pers]->dag[n],&wie[pers]->dag[n+1],sizeof(struct fvak));

    return;
   }

for(n=dagnr;n<MAX_RONDEN-2;n++)
memcpy(&wie[pers]->dag[n],&wie[pers]->dag[MAX_RONDEN-1],sizeof(struct fvak));


}

/************************** OVERZICHT ************************/
void   overzicht(void)
{
int n;
int pers,persoon;
char text[80];
long lid;

if(!prntest()) return;

persoon=kiesnaam("**OVERZICHT**   Druk escape om selectie te maken @=Kort overzicht printen");
pers=persoon;

  for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->plaats[0]==0) break;

if(persoon!=999)
 {
  prnt_pers_id(pers);
  gotoxy(5,15);
  cputs("Hier een overzicht van ?? RETURN=OK");
  if(getch()==13)
	   {
	   print_overzicht(persoon);
	   return;
	   }
 }
 clrscr();
 gotoxy(1,5);
 cputs("Geef lidummer of 0 voor overzicht van iedereen");
 gotoxy(1,7);
 cputs("Lidnummer : ");
 gotoxy(13,7);
 lid=0;
 gets(text);
 if(strlen(text))
   lid=atol(text);
 else return;
 if(!prntest()) return;

 for(persoon=0;persoon<rows;persoon++)
    {
     gotoxy(2,2);
     highvideo();
     textcolor(GREEN);
     cprintf("      Naam : %s                         ",wie[persoon]->naam);
     normvideo();
     if(lid>0 && wie[persoon]->lidnr!=lid) continue;
     gotoxy(10,10);
     cputs("Druk een toets om het printen te stoppen");
     cputs("\r\nGeduld, het kan even duren voor hij reageert");
     if(kbhit()){while(kbhit()) getch();  return;}
     print_overzicht(persoon);
    }

}

/******************* overzicht printen ***********************/
void print_overzicht(int pers)
{
int n;

struct date d;
getdate(&d);
fprintf(printer,"Printdatum : %d-%d-%d\n",d.da_day,d.da_mon,d.da_year);
fprintf(printer,"      Naam : %s   \n",wie[pers]->naam);
fprintf(printer,"     Adres : %-60s\n",wie[pers]->adres);
fprintf(printer,"Woonplaats : %-30s\n",wie[pers]->plaats);
fprintf(printer,"     Telnr : %-13s\n",wie[pers]->telnr);
fprintf(printer,"       Lab : %-30s\n",wie[pers]->lab);
fprintf(printer,"     Lidnr : %- 5d\n",wie[pers]->lidnr);
fprintf(printer,"----------------------------------------------------------------------\n");
fprintf(printer,"No Tech  Std  IgG1   IgG2   IgG3   IgG4   IgG    IgA1   IgA2   IgA");
for (n=0;n<3;n++){
fprintf(printer,"\r\n%3ld  %c    %c  %5.2f  %5.2f  %5.2f  %5.2f  %5.2f  %5.2f  %5.2f",
wie[pers]->dag[n].serumnr,
wie[pers]->dag[n].techniek,
wie[pers]->dag[n].standaard,
wie[pers]->dag[n].IgG1,
wie[pers]->dag[n].IgG2,
wie[pers]->dag[n].IgG3,
wie[pers]->dag[n].IgG4,
wie[pers]->dag[n].IgG ,
wie[pers]->dag[n].IgGsom,
wie[pers]->dag[n].IgGdev  );
}
fprintf(printer,"----------------------------------------------------------------------\n");

fprintf(printer,"\f");
fflush(printer);
}


/************************** sorteren op naam ***********************/
void csort(int n)
{
   int l,j,ir,i,s;

   if(n>MAX_ROW-2) n=MAX_ROW;
   l=(n >> 1)+1;
   s=ir=n;
   for(i=n;i>=0;i--) memcpy(wie[i+1],wie[i],sizeof(struct vak ));
   for(;;)
      {
      if(l > 1)
	   memmove(wie[MAX_ROW-1],wie[--l],sizeof(struct vak));
      else {
	   memmove(wie[MAX_ROW-1],wie[ir],sizeof(struct vak));
	   memmove(wie[ir],wie[1],sizeof(struct vak));
	   if(--ir == 1)
	     {
	      memmove(wie[1],wie[MAX_ROW-1],sizeof(struct vak));
     for(i=0;i<=n+1;i++) memcpy(wie[i],wie[i+1],sizeof(struct vak));
	      return;
	     }
	   }
      i=l;
      j=(l << 1) ;
      while(j <= ir )
	{
	 if(j < ir && (strcmp(wie[j]->naam,wie[j+1]->naam)) < 0) ++j;
	 if((strcmp(wie[MAX_ROW-1]->naam,wie[j]->naam)) < 0)
	 {
	 memmove(wie[i],wie[j],sizeof(struct vak));
	 j += (i=j);
	 }
	 else j=ir+1;
	}
      memmove(wie[i],wie[MAX_ROW-1],sizeof(struct vak));
s=s;
     }
}

void print_rapport(void)
{
float mean[MAX_MONSTER][9];
float min[MAX_MONSTER][9];
float max[MAX_MONSTER][9];
float aantal[MAX_MONSTER][9];
int   pos;
float posfac;
float waarde;
char  c;
char  sarray[Yl+3][Xl+3]; /* Xl pos op regel, Yl regels hoog */
int   sarrayno[Xl+3];     /* standaard array */
char  marray[Yl+3][Xl+3]; /* Xl pos op regel, Yl regels hoog */
int   marrayno[Xl+3];     /* techniek array */
char  line[80];
float lenline,aslen,w1,w2;
int   b,m,n,i,j,k;
int   persoon;
float as[10]={0.05,0.1,0.2,0.5,1.0,2.0,5.0,10.0,20.0,50.0};

  for(n=0;n<MAX_MONSTER;n++){
    for(m=0;m<9;m++) {
       mean[n][m] = 0.0;
	min[n][m] = 99999.0;
	max[n][m] = 0.0;
     aantal[n][m] = 0.0;
    }}

 for(persoon=0;persoon<rows;persoon++){
  for(n=0;n<MAX_MONSTER;n++){
  m=0;
   if(wie[persoon]->dag[n].IgG1 > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG1)
	 max[n][m]=wie[persoon]->dag[n].IgG1;
      if(min[n][m]>wie[persoon]->dag[n].IgG1)
	 min[n][m]=wie[persoon]->dag[n].IgG1;
	 mean[n][m]+=wie[persoon]->dag[n].IgG1;
	 aantal[n][m]++;
    }
   m++;
   if(wie[persoon]->dag[n].IgG2 > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG2)
	 max[n][m]=wie[persoon]->dag[n].IgG2;
      if(min[n][m]>wie[persoon]->dag[n].IgG2)
	 min[n][m]=wie[persoon]->dag[n].IgG2;
	 mean[n][m]+=wie[persoon]->dag[n].IgG2;
	 aantal[n][m]++;
    }
   m++;
   if(wie[persoon]->dag[n].IgG3 > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG3)
	 max[n][m]=wie[persoon]->dag[n].IgG3;
      if(min[n][m]>wie[persoon]->dag[n].IgG3)
	 min[n][m]=wie[persoon]->dag[n].IgG3;
	 mean[n][m]+=wie[persoon]->dag[n].IgG3;
	 aantal[n][m]++;
    }

   m++;
   if(wie[persoon]->dag[n].IgG4 > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG4)
	 max[n][m]=wie[persoon]->dag[n].IgG4;
      if(min[n][m]>wie[persoon]->dag[n].IgG4)
	 min[n][m]=wie[persoon]->dag[n].IgG4;
	 mean[n][m]+=wie[persoon]->dag[n].IgG4;
	 aantal[n][m]++;
    }

   m++;
   if(wie[persoon]->dag[n].IgG  > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgG )
	 max[n][m]=wie[persoon]->dag[n].IgG ;
      if(min[n][m]>wie[persoon]->dag[n].IgG )
	 min[n][m]=wie[persoon]->dag[n].IgG ;
	 mean[n][m]+=wie[persoon]->dag[n].IgG ;
	 aantal[n][m]++;
    }

   m++;
   if(wie[persoon]->dag[n].IgGsom  > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgGsom )
	 max[n][m]=wie[persoon]->dag[n].IgGsom ;
      if(min[n][m]>wie[persoon]->dag[n].IgGsom )
	 min[n][m]=wie[persoon]->dag[n].IgGsom ;
	 mean[n][m]+=wie[persoon]->dag[n].IgGsom ;
	 aantal[n][m]++;
    }

   m++;
   if(wie[persoon]->dag[n].IgGdev  > 0)
    {
      if(max[n][m]<wie[persoon]->dag[n].IgGdev )
	 max[n][m]=wie[persoon]->dag[n].IgGdev ;
      if(min[n][m]>wie[persoon]->dag[n].IgGdev )
	 min[n][m]=wie[persoon]->dag[n].IgGdev ;
	 mean[n][m]+=wie[persoon]->dag[n].IgGdev ;
	 aantal[n][m]++;
    }

  }} /*end for's*/

 for(m=0;m<7;m++){
  for(n=0;n<MAX_MONSTER;n++){
   if(aantal[n][m] > 0)
    {
     mean[n][m]/=aantal[n][m];
     min[n][m]*=0.99;
     max[n][m]*=1.01;
   ascal(&noofcalibrators,&min[n][m],&max[n][m],0,1,0);
  }}}


 /* lus plaatjes maken */

  for(n=0;n<MAX_MONSTER;n++)
    {
    if(mean[n][0]==0)   /* Als er waarden voor het monster zijn -> plaatjes */
	  continue;     /* anders zijn er minder monsters rondgestuurd */

  for(m=0;m<7;m++){	/* IgG1, m=1 IgG2 enz. */
				/* wissen array voor plaatje*/
    for(j=0;j<=Yl;j++){
       for(i=0;i<=Xl;i++){ sarray[j][i]=32; marray[j][i]=32;}
	 sarray[j][Xl+1]=0; marray[j][Xl+1]=0;
      }

    for(i=0;i<=Xl;i++){         	/* wissen array voor plaatje*/
       sarrayno[i]=0;
       marrayno[i]=0;}

    for(persoon=0;persoon<rows;persoon++)
      {
	   switch(m){
	    case 0: waarde=wie[persoon]->dag[n].IgG1;   break;
	    case 1: waarde=wie[persoon]->dag[n].IgG2;   break;
	    case 2: waarde=wie[persoon]->dag[n].IgG3;   break;
	    case 3: waarde=wie[persoon]->dag[n].IgG4;   break;
	    case 4: waarde=wie[persoon]->dag[n].IgG;    break;
	    case 5: waarde=wie[persoon]->dag[n].IgGsom; break;
	    case 6: waarde=wie[persoon]->dag[n].IgGdev; break;
	  default : puts("fout in cases in print rapport"); getch();
	}
	posfac=(max[n][m]-min[n][m]) / Xl;
	pos= (waarde - min[n][m]) / posfac ;
	sarray[sarrayno[pos]][pos]=wie[persoon]->dag[n].standaard;
	marray[marrayno[pos]][pos]=wie[persoon]->dag[n].techniek;
	sarrayno[pos]++;
	marrayno[pos]++;
	if(sarrayno[pos]>=Yl){sarray[sarrayno[pos]--][pos]= '^';}
	if(marrayno[pos]>=Yl){marray[marrayno[pos]--][pos]= '^';}
      }

      clrscr();
      for(j=Yl-1;j>=0;j--)
	{printf("%s\r\n",sarray[j]);}

	lenline=max[n][m]-min[n][m];
	 for(i=0;i<11;i++)
	   if(as[i]*4 > lenline)   break;

	  i=0;
   ascal(&noofcalibrators,&min[n][m],&max[n][m],0,1,0);
	  for(j=0;j<Xl;j++)
	   {
	    w1=(j * posfac)+min[n][m];
	    w2=((j+1) * posfac)+min[n][m];
	    if(atof(calibratorstring[i])>=w1 && atof(calibratorstring[i])<w2)
	     { line[j]='|';i++;}
	       else line[j]='-';
	    line[j+1]=0;
	   }
	  printf("%s\r\n",line);
	  k=i=0;
   ascal(&noofcalibrators,&min[n][m],&max[n][m],0,1,0);
	  for(j=0;j<Xl;j++)
	   {
	    w1=(j * posfac)+min[n][m];
	    w2=((j+1) * posfac)+min[n][m];
	    if(atof(calibratorstring[i])>=w1 && atof(calibratorstring[i])<w2)
	    {printf("%s",calibratorstring[i++]); }
	      else printf(" ");

	   }

      printf("\r\n");
      getch();


   }
  } /* einde lus < MAX_MONSTER  */

}

int ascal(int *noofcalibrators, float *min, float *max, int logflag, int calcflag, int expflag) {
    int n, range, exp, exp0, t, t0, found, negative, precision, extra_decimal=0;
    double unit, value, tempmin, tempmax, ratio, base, lowest_calibrator;
    int exponent[MAXNOOFCALIBRATORS];
    if (logflag) round(scientific2(*min, &base, &exp));
    else round(scientific2(*max, &base, &exp));
    tempmin=*min * 10 +  fabs(*min)/10000;
    tempmax=*max * 10 -  fabs(*max)/10000;
    lowest_calibrator=val(10,exp);
    for (n=0;n<MAXNOOFCALIBRATORS;n++) {
	*calibratorstring[n]='\0';
	value_of_calibrator[n]=MISSING_CALIBRATOR;
    }

    if (logflag && tempmax<=0) logflag=FALSE;
    if (logflag) {
	if (tempmin<=0) tempmin= lowest_calibrator;
	ratio= (double)(tempmax / tempmin);
	if (ratio < 51 )       range= SMALL;
	else if (ratio < 301 ) range= MEDIUM;
	else                   range= LARGE;
    } else range=LINEAR;
    t=t0=0;
    found=FALSE;
    do{
       exp0=--exp;
       unit=val(calbase[range][t],exp);
    } while (3*unit>=tempmax-tempmin);
    while (!found) {
       if (! logflag) {
	  found= ( 6*unit >= tempmax - tempmin);
	  if (!found) {
	     t++;
	     t%=range+1;
	     if (t==0) exp++;
	     unit=val(calbase[range][t],exp);
	  }
	  if (found && t==2) extra_decimal=1;
       } else {
	   value=val((double)calbase[range][t],exp+1);
	   found= (value >= tempmin);
	   if (!found) {
	     t0=t;
	     exp0=exp;
	     t++;
	     t%=range+1;
	     if (t==0) exp++;
	   } else {
	     t=t0;
	     exp=exp0;
	     value=val((double)calbase[range][t],exp+1);
	  }
       }
    }

PHASE2: /* find corrected min and max and fill array */
    if (!logflag) {
       if ( tempmin/unit-(int)(tempmin/unit) != 0) {
	  negative= ( tempmin < 0);
	  tempmin=  unit * (int)(tempmin/unit);
	  if (negative) tempmin -= unit;
       }
    } else tempmin=val((double)calbase[range][t],exp+1);
    for (n=0 ; n < MAXNOOFCALIBRATORS ; n++) {
	if ( ! logflag ) {
	   value_of_calibrator[n]=(tempmin + n*unit)/10;
	   exponent[n]=exp;
	} else {
	   exponent[n]= exp;
	   value_of_calibrator[n]= val((double)calbase[range][t],exp);
	   t++;
	   t%=range+1;
	   if (t==0) exp++;
	}
	if (value_of_calibrator[n] >= tempmax/10) {
	    tempmax= value_of_calibrator[n]*10;
	    *noofcalibrators=n+1;
	    break;
	}
    }
    *min=tempmin/10;
    *max=tempmax/10;
    if (!calcflag) return logflag;

/* phase 3: print results in minimal-length strings */

    for (n=0; n< *noofcalibrators ; n++) {
	if (logflag && expflag) sprintf(calibratorstring[n],"%d",exponent[n]);
	else {
	   if (value_of_calibrator[n]>(*max>0?1.0001* *max:0.9999* *max)) {
#ifdef TRACE
	      if (Trace) fprintf(tracefile,"\ncal[%d]=%.4lf *max=%.4lf verschil:%lf",
		 n, value_of_calibrator[n], *max, value_of_calibrator[n] - *max);
#endif
	      break;
	   }
	   precision= (range==LINEAR) ? (extra_decimal - exponent[n]): -exponent[n];
	   if (precision<0) precision=0;
/*	   sprintf(calibratorstring[n],"%.*lf", precision, value_of_calibrator[n]);*/
	   printf("%3.3f",value_of_calibrator[n]);
	   printf("%.*lf", precision, value_of_calibrator[n]);
       }
    }
/* phase 4: if (logflag) transform data */

   if (logflag) for (n=0; n<*noofcalibrators; n++) value_of_calibrator[n]=log(value_of_calibrator[n]);

/* return logflag to indicate whether log-transformation was actually performed */

    return logflag;
}

double scientific2(double d, double *base, int *exp) {
   double logd;
   int neg=FALSE;
   if (d==0) {
      *base=0;
      *exp=-1;
      return *base;
   }
   if (d<0) {
      neg=1;
      d=-d;
   }
   logd=log10(d);
   *exp= (int)logd - (d<1)-1;
   *base= pow10d(logd-*exp);
   if (neg) *base=-*base;
   return *base;
}

double val(double mantissa, int exponent) {
   return mantissa*pow10(exponent);
}

int round(double d) {
    int i=(int)d;
    if (d-i<.5 ) return (int)(d+.5);
    return (int)(d+1);
}

double pow10d(double exponent) {
   /* 10^exponent, exponent is double rather than int, as required for pow() */
   return exp(exponent*log(10));
}
