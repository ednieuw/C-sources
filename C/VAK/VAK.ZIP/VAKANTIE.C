/* lotus 2 logit   EJN*/

/* l.prj file
l
cga.obj
herc.obj
egavga.obj
litt.obj
Compile in LARGE*/

#include "alloc.h"
#include "conio.h"
#include "io.h"
#include "string.h"
#include "stdlib.h"
#include "stdio.h"
#include "process.h"
#include "dir.h"
#include "time.h"
#include "dos.h"
#include "math.h"
#include "fcntl.h"
#include "bios.h"
#include "mem.h"

#define breedte_menu     35     /* Breedte van menu's */
#define MAXDISK   5
#define TRUE      1
#define FALSE     0
#define LEEG     -1
#define SPECIAL_KEY  0
#define UP     72
#define DOWN   80
#define HOME   71
#define ENDT   79
#define LEFT   75
#define UP     72
#define EXEC   13
#define ESC    27
#define RIGHT  77
#define PgUp   73
#define PgDn   81
#define SPACE  32
#define RETURN 13
#define TAB     9
#define CHBIN 0xF000    /* Blink Invers */
#define CHBHI 0x8F00	/* Blink Highligted */
#define CHHIG 0x0F00    /* Highligted */
#define CHINV 0x7000    /* Invers */
#define CHNOR 0x0700    /* Normaal */

#define EDIT    0
#define LOAD    1       /* hoofdmenu items */
#define OVERZICHT 2
#define NEW     3
#define VOEGTOE 4
#define PRNONOF 5
#define CHADIR  6
#define EDITOR  7
#define MAAND   8
#define QUIT    9

#define CHECKCODE 12345

int AUTOMENU = FALSE;
static char titel[QUIT+1][breedte_menu];

#define BARCOLOR 0X2400

#define LOTUS1 0X0404
#define LOTUS2 0X0405
#define BELL 7
#define MAXROWS 20             /* maximale dimensies worksheet */
#define MAX_LEN 40
#define MAX_LEN_NAAM  30       /* Lengte van de naam column */
#define MAX_LEN_VNAAM 10       /* Lengte van de vnaam column */
#define MAX_LEN_ADRES 60       /* Lengte van de adres column */
#define MAX_LEN_PLAATS 30      /* Lengte van de plaats column */
#define MAX_LEN_TELNR 13       /* Lengte van de telnr column */
#define MAX_LEN_DATUM 7        /* Lengte van de datum column */
#define MAX_DAGEN 153

#define MISSING -999999.0

#define DATUM __DATE__
int MAX_ROW;

struct ffblk ffblk;
unsigned disk;
char *directory;
char curdir[132];
int size;
int show;

struct fvak {
	    char RV;
	    char datumvrij[MAX_LEN_DATUM];
	    char datumeindvrij[MAX_LEN_DATUM];
	    int urenopgenomen;
	   };

struct vak { 
	     char naam[MAX_LEN_NAAM];
	     char vnaam[MAX_LEN_VNAAM];
	     char adres[MAX_LEN_ADRES];
	     char plaats[MAX_LEN_PLAATS];
	     char telnr[MAX_LEN_TELNR];
	     long afdnr;
	     int  urenover;
	     int  deeltijd;
	     long persnr;
	     char gebdatum[MAX_LEN_DATUM];
	     struct fvak dag[MAX_DAGEN];
	     int check;
	   };

struct vak **wie;

int lost,print,LXG,LYG,berekend;
int rows, columns;
int corrupted=FALSE;

FILE *fp;
FILE *fpin;
FILE *fpout;
FILE *printer;
char filename[12];     /* naam voor de punt van de ingelezen file */
char file[30];
char filein[40];
char fileout[40];
char fileload[40];
char outfile[20];
int maindisk;
char maindir[40];
char drawdir[40];
char dir[40];
int geladen=0;
int wis=1;
/*
int    GraphDriver;		/* The Graphics device driver		*/
int    GraphMode;		/* The Graphics mode value		*/
int    MaxX, MaxY;		/* The maximum resolution of the screen */
int    MaxColors;		/* The maximum # of colors available	*/
int    ErrorCode;		/* Reports any graphics errors		*/
struct palettetype palette;     /* for palette info			*/
*/

int  far *SCHERMPTR;
unsigned char far *video;
unsigned char far *vid;
int far *PTR  = (int far *) 0XB800L;
int SIZE,FONT; 		                  /* wordt gebruikt in graphbody() */
int MaxX, MaxY = 0;
float xnop,ynop;
char *password;

/****************************  FUNCTION PROTOTYPES ***************/
void   set_prn_filename(char *);
int    display_menu(int ,int );
int    menuver(int ,int ,int ,int, int );
int    load_menu();
void   stuiteren(void);
void   makedate(int *, int *, int *,unsigned );
char   *filedir(char *);
void   changedir(char *);
int    parse(char *);
void   box(int ,int ,int ,int ,int ,int );
void   swrite(int ,int ,char * , int );
void   twrite(int ,int ,char *,int ,int );
void   initdisplay();
void   veeg(int ,int ,int ,int );
void   lveeg(int ,int ,int ,int ,char,unsigned );
int    prntest();
char   *remove_lt_space(char *);
double getd(FILE *);
void   read_wks(char *);
void   skip(FILE *,long );
void   prnonoff(void);
void   Initialize(void);
void   mallocdata(void);
void   freemallocdata(void);
void   readprn(char *);
void   edit_fields(void);
int    kiesnaam(char *text);
int    save_data(void);
int    load_data(void);
int    display_persoon(int pers);
int    persoon_editen(void);
void   prnt_pers_id(int pers);
void   wissen(int pers);
void   delete_entry(int pers,int dagnr);
void   overzicht(void);
void   print_overzicht(int pers);
void   csort(int n);
void   maandoverzicht();

/************************************************************/


/************************** MAIN **************************/

main(int argc,char **argv)
{
char fnop[15];
int k,actie;
struct dfree free;
long avail;
int drive;

char ext[12],filenop[20];
printer = fopen("LPT1","w");
lost     = FALSE;
print    = TRUE;
show     = FALSE;
LXG      = TRUE;
LYG      = FALSE;
berekend = FALSE;
strcpy(outfile,"");
fileload[0] = 0;
filenop[0] = 0;
actie=EDIT;
MAX_ROW=MAXROWS;

clrscr();
strcpy(password,"q");
initdisplay();
normvideo();
textcolor(WHITE);
textbackground(BLACK);

   drive = getdisk();
   getdfree(drive+1, &free);
   if (free.df_sclus == 0xFFFF)
   {
      printf("Error in getdfree() call\n");
      exit(1);
   }

   avail =  (long) free.df_avail *
            (long) free.df_bsec *
            (long) free.df_sclus;
   if(avail<50000)
   {
   printf("\n\n\n\nDrive %c: has %8ld bytes available\n", 'A' + drive, avail);
   puts("\nIk zou eerst maar wat wissen voor ik verder ging");
   puts("\n\nDruk en toets");
   getch();
   }

if (argv[1][0]=='?')
 {
  swrite(1,0,"Start het programma op met VAKANTIE [1] [2],waarin, [1] een optionele ",0X0700);
  swrite(1,1,"optionele filenaam is met de extensie .VAK of .$$$         ",0X0700);
  swrite(1,4,"[1] of [2] kan ook het maximaal aantal regels zijn dan kan   ",0X0700);
  swrite(1,5,"worden ingelezen. Dit kan handig zijn bij te weinig geheugen.",0X0700);
  swrite(1,6,"Coreleft geeft aan hoeveel ruimte er nog vrij is aan geheugen.",0X0700);
  swrite(1,7,"Het maximaal aantal in te lezen personen staat onderin beeld ",0X0700);
 swrite(1,10,"Een PRV file is de ASCII file van dit bestand                ",0X0700);
 swrite(1,11,"Met Editor wordt de PRV of overzichts file geladen.          ",0X0700);
 swrite(1,12,"In de PRV file kunnen dan bijv. regels gewist worden.        ",0X0700);
 swrite(1,13,"Druk F7 om uit de editor te komen.                           ",0X0700);
 getch();
 exit(1);
 }

if(argc>=2) /* als een file meegegeven in commandline */
   {
   if(argv[1][0]<58) { MAX_ROW=atoi(argv[1]); ext[0]=0;}
    else
     {
     strcpy(filenop,argv[1]);
     strcpy(filenop,strtok(filenop,"."));
     strcpy(ext,strupr(strtok(NULL,".")));
     if(stricmp(ext,"VAK")==0 || stricmp(ext,"$$$")==0)
	 {actie=LOAD; AUTOMENU = TRUE; strcpy(fileload,argv[1]);}
     else if(stricmp(ext,"PRT")==0)
	 {actie=EDIT; AUTOMENU = TRUE; strcpy(fileload,argv[1]);}
    }
   }
if(argc==3) /* als een MAXROW is meegegeven in commandline */
    {
     if(argv[2][0]<58) MAX_ROW=atoi(argv[2]);
    }

mallocdata();
strcpy(curdir,"?:\\");
curdir[0] = 'A'+getdisk();
maindisk = getdisk();
getcurdir(0,curdir+3);
if(curdir[(int)strlen(curdir)-1] != 92) strcat(curdir,"\\");
strcpy(maindir,(char *)curdir);

while(1)
   {
   wis = 1;
   if(!AUTOMENU)
	 actie=display_menu(wis,actie); /* Als geen filenaam in commandline */
   if (actie == -1) actie=QUIT;
   switch (actie)
      {
	   case EDIT:
		  if(!geladen)  break;
		  veeg(0,0,25,80);
		  lost =FALSE;
		  veeg(0,0,25,80);
		  edit_fields();
		  AUTOMENU = FALSE;
		  actie = EDIT; 
		  break;

	   case LOAD:
		  veeg(0,0,25,80);
		  lost = FALSE;
                  if(geladen){ save_data(); veeg(0,0,25,80);}
		  freemallocdata();
		  mallocdata();
		  if(!AUTOMENU) strcpy(fileload,(char *)filedir("*.VAK"));
		  geladen=load_data();
		  if (geladen)
		    {
		     strcpy(fnop,fileload);
		     strcpy(filename,strtok(fnop,"."));
		    }
		  veeg(0,0,25,80);
		  AUTOMENU = FALSE;
		  actie = EDIT; 
		  break;

	   case OVERZICHT:
		  if(!geladen) break;
		  veeg(0,0,25,80);
		  strcpy(file,fileload);
		  overzicht();
		  AUTOMENU = FALSE;
		  actie=EDIT;
		  break;

	   case NEW:
		  veeg(0,0,25,80);
		  lost =FALSE;
		  password=0;
		  password = getpass("Input a password:");
		  if(stricmp(password,"eddie")!=0) break;
		  freemallocdata();
		  mallocdata();
		  if(!AUTOMENU) strcpy(fileload,(char *)filedir("*.PRV"));
		  if (strlen(fileload) < 2) break;
		  strcpy(file,fileload);
		  berekend  = 0;
		  geladen = 1;
		  veeg(0,0,25,80);
		  strcpy(fnop,fileload);
		  strcpy(filename,strtok(fnop,"."));
		  
		  readprn(fileload);
		  strcpy(outfile,fileload);
		  AUTOMENU = FALSE;
		  actie = EDIT; 
		  break;

	   case VOEGTOE:
		  if(!geladen)  break;
		  persoon_editen();
		  AUTOMENU = FALSE;
		  actie=VOEGTOE;
		  break;

	   case CHADIR:
		  veeg(24,0,1,80);
		  swrite(13,22,"RETURN or New directory: \0",0x1300);
		  gotoxy(39,23);
		  gets(dir);
		  if (strlen(dir) >1) changedir(dir);
		  strcpy(curdir,"?:\\");
		  curdir[0]='A'+getdisk();
		  getcurdir(0,curdir+3);
		  if(curdir[strlen(curdir)-1] != 92) strcat(curdir,"\\");
		  veeg(23,0,2,80);
		  AUTOMENU = FALSE;
		  actie=EDIT;
		  if(geladen) actie=OVERZICHT;
		  break;

	   case PRNONOF:
		  veeg(0,0,25,80);
		  lost =FALSE;
		  password = getpass("Input a password:");
		  if(stricmp(password,"eddie")!=0) strcpy(password,"q");
		  break;


/*		  if(print)           print = FALSE;
		    else {prntest();  print = TRUE;}
		  AUTOMENU = FALSE;
		  actie=EDIT;
		  if(geladen) actie=OVERZICHT;
		  break;
*/
		case EDITOR:
/*		  strcpy(file,fileload);*/
		  strcpy(drawdir,searchpath("pe.exe"));
		  if(spawnlp(P_WAIT,drawdir,"pe.exe",outfile,NULL)==-1)
		   {
		     veeg(0,0,25,80);
		     puts("\n\n\n\n\n      NOT ENOUGH MEMORY FOR EDITOR OR EDITOR NOT FOUND\0");
		     delay(3000);
		    }
		  AUTOMENU = FALSE;
		  actie=EDIT;
		  if(geladen) actie=OVERZICHT;
		  break;

           case MAAND:
		  if(!geladen)  break;
		  maandoverzicht();
		  AUTOMENU = FALSE;
		  break;

	   case QUIT:
		 default:
		  if(geladen) save_data();
		  veeg(0,0,25,80);
		  setdisk(maindisk);
		  chdir(maindir);
		  printf("%s\n",maindir);
/*		  freemallocdata();*/
		  exit(1);
		  break;
      }
  }
}
/**********************  EINDE MAIN ***********************/

int display_menu(int wis,int barkeuze)
{
   int num,nr,breed,keuze;
   char datum[12],nop[50],nopp[30];
   num=load_menu();                   /* laad tekst menu */
   if(wis) lveeg(0,0,25,80,'�',0x2500);
   strcpy(datum,DATUM);
   sprintf(nop,"Farcoreleft %lu bytes",farcoreleft());
   sprintf(nopp,"  Max. personen %d \0",MAX_ROW);
   strcat(nop,nopp);
   swrite(2,24,nop,0x2100);

   twrite(2,20,"����������������������������ͻ\0",YELLOW,RED);
   twrite(2,21,"�Problemen? Ed Nieuwenhuys   �\0",YELLOW,RED);
   twrite(2,22,"����������������������������ͼ\0",YELLOW,RED);


   swrite(16,0,"����������������������������ͻ\0",0x0600);
   swrite(16,1,"� Vakantiedagen              �\0",0x0600);
   swrite(16,2,"����������������������������ͼ\0",0x0600);
   swrite(33,1,datum,0x0600);
   swrite(16,3,curdir,0x0700);
   swrite(50,6,fileload,0x0700);
   if(lost) swrite(0,22,"Database te klein om iedereen in te lezen",0X0700);
   gotoxy(1,1);
   breed=breedte_menu;
   keuze = menuver(num,5,17,breed-5, barkeuze);
   if (keuze==QUIT || keuze==-1) veeg(0,0,20,80);
   return(keuze);

}


int menuver(int num,int ltopy,int ltopx,int breed, int barkeuze)
{
   long secs_now;
   char *str_now;
   char s[33];
   int x, y, code, code1, oke, yy, xx, keer,leave,keus;
   int keuze;
   char ch;

   yy = ltopy;
   xx = ltopx;
   oke = 0;
   keuze = barkeuze;
   box(yy,xx,num,breed,1,0);

   while (1)
	 {
	 yy=ltopy;
	 for (y=0; y<num; y++)
	  {
	   yy++;
	   xx=ltopx+1;
	   for (x=0; x<strlen(titel[y]); x++)
		{
		xx++;
		ch = titel[y][x];
		if (y==keuze)   *(SCHERMPTR + yy*80 + xx) = ch | 0x7000;
		else
		  if (x==0)     *(SCHERMPTR + yy*80 + xx) = ch | 0x1300;
			else    *(SCHERMPTR + yy*80 + xx) = ch | 0x4700;
		 }
		}
	  if(oke == 1)		return(keuze);
	  while(bioskey(1)==0)
		{
		 time(&secs_now);
		 str_now=ctime(&secs_now);
		 xx=55;
		 str_now[24]='\0';
		 swrite(xx,0,str_now,0x1300);
		 }

	   code = getch();
	   code1=SPECIAL_KEY;
	   if(code==SPACE) {code1=SPACE; code=SPECIAL_KEY;}
	   if(code == SPECIAL_KEY)
            {
	     if(code1 !=SPACE)  code1 = getch();
	     switch (code1)
	       {
 	                   case PgUp:    keuze -=20;      break;
	                   case PgDn:    keuze +=20;      break;
			   case UP:
			   case LEFT:    --keuze;         break;
			   case SPACE:
			   case DOWN:
			   case RIGHT:   ++keuze;         break;
			   case HOME:
			   case ENDT:    keuze = num-1;   break;
               }
			   if(keuze < 0)   keuze = num-1;
			   if(keuze > num-1)   keuze = 0;
	     }
	   else
		{
		  ch = code;  keus=keuze;  leave=0;   keer=-1;
		  while(keer<2)
		   {
		    keer++;
		    if(keer==1) { keus=-1;}
		    for(y=keus+1; y<num; y++)
		     {
		      if(strnicmp(&titel[y][0],&ch,1) == 0)
			{ keuze = y; oke = 0; leave=1;  keer=2;  }
		      if(leave) break;
		     }
		    }
		  oke = 1;
		  if(ch == ESC) {    keuze = -1;   oke = 1;   }
		}
	}
}


void stuiteren(void)
{
int x,y,xx,yy,xoud,youd,ymax,yyy;
char str[30];
long secs_now;
char *str_now;

xx=55;
yy=0;
youd=0;
yyy=1;
ymax=16;
	  while(bioskey(1)==0)
		{
		 time(&secs_now);
		 str_now=ctime(&secs_now);
		 xx=55;
		 str_now[24]='\0';
                 yy+=yyy;
                 if(yyy<0 && yy<ymax) {yyy= 1; ymax=(24-ymax)*2/3;}
                 if(yyy>0 && yy>23)   yyy=-1;
		 swrite(xx,yy,str_now,0x1300);
                 lveeg(youd,55,1,25,'�',0x2500);
                 youd=yy;
                 if(ymax>22) {ymax=16;yyy=1;yy=0;}
                 delay(100);
		 }



}
/********************** LOAD MENU ********************************/
int load_menu()
{
   int nr=QUIT+1;
	  strcpy(titel[0],"Schrijf uren af           \0");
	  strcpy(titel[1],"Laad/Save een afdeling    \0");
	  strcpy(titel[2],"Maak overzichtslijst      \0");
	  strcpy(titel[3],"@Laad PRV file/Nieuwjaar  \0");
	  strcpy(titel[4],"Wissen/toevoegen/editen   \0");
	  strcpy(titel[5],"Password                  \0");
	  strcpy(titel[6],"Andere drive / directory  \0");
	  strcpy(titel[7],"Tekst editor              \0");
          strcpy(titel[8],"Dagen overzicht           \0");
	  strcpy(titel[9],"Quit en save              \0");
  return(nr);
 }



/***************** haal datum uit ffblk.ff_fdate ************************/
void makedate(int *d, int *m, int *y,unsigned dosdate)
{
 *m = (dosdate >>5)&0XF;
 *d = dosdate & 0x1F;
 *y = (dosdate >>9) & 0X3F;
 *y += 80;
 }


/* Directory listen op scherm en keuze maken ****************************** */
/*                                                                          */
/* char dir 			zoek sleutel directory                      */
/*                                                                          */
/* ************************************************************************ */

char *filedir(char *filein)
{
   char nop[30];
   int y,leave;
   static char filenaam[250][30];   /* nr,breedte filenaam + datum*/
   char ch;			    /* te printen char */
   int begin = 0;                   /* 1e file uit blok van 25 dat geprint word */
   int keuze = 0;		    /* nummer gekozen file */
   int num = 0;                     /* aantal files */
   int oke;                         /* 0 = geen keuze ESC 1 = keuze RETURN */
   int toets;			    /* toetsaanslag via getch() */
   int pos = 0;			    /* positie binnen filenaam */
   int veld;			    /* nummer van filenaam */
   int x = 0;			    /* teller */
   int xx =0;                       /* row waar geprint moet worden */
   int yy = 0;                      /* colom waar geprint moet worden */
/*   int maxaantal = 110; */        /* aantal files per beeldscherm */
   int keus=0;
   int keer=0;
   int day,month,year;

   oke = findfirst((char *)filein,&ffblk,0);
   while (!oke)
      {
       sscanf(ffblk.ff_name,"%s", &nop);
       makedate(&day,&month,&year,ffblk.ff_fdate);
       sprintf(filenaam[x],"%12.12s %2.2d-%2.2d-%2.2d",nop,day,month,year);
       if(++x == 250)
	{
	 sound(100);
	 nosound();
	 sound(1000);
	 swrite(10,10,"Niet alle files ingelezen\0",0x0200);
	 swrite(10,11,"Max. is 250 files\0",0x0200);
	 delay(50);
	 nosound();
	 sleep(3);
	 break;
	}
      oke = findnext(&ffblk);
      }
   num = x;
   oke = 0;

   box(0,6,(num/3)+1,69,2,1);

   while (1)
    {
    for(veld = begin; veld < begin + num; veld++)
     {
      yy = 1 + (veld - begin) / 3;
      xx = 8 + (((veld - begin) % 3) * 22);
      if(veld < num)
       {
       for(pos = 0; pos < 21; pos++, xx++)
	{
	 if(pos < strlen((char *)filenaam[veld]) )
	       ch = (filenaam[veld][pos]);
	 else  ch = SPACE;
	    if (veld == keuze) *(SCHERMPTR + yy * 80 + xx) = ch | CHHIG;
	    else               *(SCHERMPTR + yy * 80 + xx) = ch | CHINV;
	 }
	}
	 else
	   for(pos = 0; pos < 21; pos++, xx++)
			       *(SCHERMPTR + yy * 80 + xx) = SPACE | CHINV;
     }
    if(oke > 0)
      {
	veeg(0,6,25,69);
	if(oke==1) return((char*)"");
	 else
	  {
	   filenaam[keuze][12]=0;
	   return((char*)remove_lt_space(filenaam[keuze]));
	  }
      }
    toets = getch();
    if(toets == SPECIAL_KEY)
     {
      toets = getch();
      switch (toets)
	{
	   case UP:      keuze -= 3;      break;
	   case LEFT:  --keuze;           break;
	   case DOWN:    keuze += 3;      break;
	   case RIGHT: ++keuze;           break;
	   case HOME:    keuze = 0;       break;
	   case ENDT:    keuze = num - 1; break;
	}
      if(keuze < 0)          keuze = num - 1;
      if(keuze > num - 1)    keuze = 0;
/*    if(keuze > num - 1)    keuze = num - 1;
*/    if(keuze < 25)         begin = 0;
      else                   begin = ((keuze - 20) / 3 ) * 3;
     }
     else
      {
       ch = toets;
       keus=keuze;
       leave=0;
       keer=-1;
       while(keer<2)
	 {
	   keer++;
	   if(keer==1) { keus=-1;}
	     for(y=keus+1; y<num; y++)
	      {
	       if(strnicmp(&filenaam[y][0],&ch,1) == 0)
		  {
		    keuze = y;  oke = 0; leave=1;  keer=2;
		    if(keuze < 25)  begin = 0;
		    else  begin = ((keuze - 20) / 3 ) * 3;
		  }
	       if(leave) break;
	       }
	  }

    if(ch == RETURN)   oke = 2;
    if(ch == ESC) { keuze=-1;   oke = 1;}
   }
  }
}

/************************** CHANGE DIR *****************************/
void changedir(char *filein)
{
if ( parse((char *)filein) )
     {
      swrite(5,23,"Illegal drive input ",0x1300);
      sleep(1);
     }
else setdisk(disk);
if(chdir(directory))
     {
       swrite(5,23,"Illegal dir input ",0x1300);
       sleep(1);
     }
}

int parse(char *ptr)
{
 if ( ptr[1] == ':')
   {
	disk = (unsigned) toupper( ptr[0]) - 'A';
	if (disk > MAXDISK)         return(-1);
    directory = ptr+ 2;
   }
 else    {   disk=getdisk();     directory=ptr;     }
if (*directory=='\0') directory=".";
return(0);
}

/* printen box op het scherm ********************************************** */
/*                                                                          */
/* int topy			row waar box geprint moet worden            */
/* int topx			col waar box geprint moet worden            */
/* int lang			lengte box                                  */
/* int breed		        breedte box                                 */
/* int type			1 = enkel  2 = dubbel                       */
/* int kleur		        0 = norm  1 = invers  2 = high              */
/*                                                                          */
/* ************************************************************************ */

void box(int topy,int topx,int lang,int breed,int type,int kleur)
{
   int x;			/* teller */
   int y;                       /* teller */
   int z;                       /* teller */
   unsigned int ch;		/* horizontale streep */
   unsigned int ck;		/* kleur die geprint moet worden */
   unsigned int clb;		/* hoek links boven */
   unsigned int crb;            /* hoek rechts boven */
   unsigned int clo;            /* hoek links onder */
   unsigned int cro;            /* hoek rechts onder */
   unsigned int cv;             /* verticale streep */

   switch (type)
      {
      case 1:
         clb = '�'; crb = '�';
         clo = '�'; cro = '�';
         ch  = '�';  cv  = '�';
         break;
      case 2:
         clb = '�'; crb = '�';
         clo = '�'; cro = '�';
         ch  = '�';  cv  = '�';
         break;
      }
   switch(kleur)
      {
      case 0: ck = CHNOR; break;
      case 1: ck = CHINV; break;
      case 2: ck = CHHIG; break;
      }

   z = 0;
   PTR = SCHERMPTR + (topy + z) * 80 + topx ;
				       *(PTR)               = clb | ck;
   for(x = 1; x < breed - 1; x++)      *(PTR + x)           = ch  | ck;
				       *(PTR + (breed - 1)) = crb | ck;
   for(x = 0; x < lang; x++)
      {
      z = x + 1;
	  PTR = SCHERMPTR + (topy + z) * 80 + topx ;
					   *(PTR)               = cv | ck;
	  for(y = 1; y < breed - 1; y++)   *(PTR + y)           = SPACE | ck;
					   *(PTR + (breed - 1)) = cv | ck;
      }
	z = lang + 1 ;
	PTR = SCHERMPTR + (topy + z) * 80 + topx ;
				       *(PTR)               = clo | ck;
   for(x = 1; x < breed - 1; x++)      *(PTR + x)           = ch  | ck;
				       *(PTR + (breed - 1)) = cro | ck;
}


/***********************  write text  ****************/

void swrite(int posx,int posy,char * tekst,int kleur)
{
   int far *nop= SCHERMPTR + posy*80 + posx;
   int x=0;
   for(;tekst[x];*(nop+x) = tekst[x++] | kleur);
}

void twrite(int posx,int posy,char * tekst,int forground,int background)
{
   int far *nop= SCHERMPTR + posy*80 + posx;
   int x=0;
   unsigned int kleur = (background<<12) + (forground<<8);
   for(;tekst[x]; *(nop+x) = tekst[x++] | kleur);
}

/********************** init display *********************/
void initdisplay(void)
{
union REGS reg;
reg.h.ah=15;
int86(0X10,&reg,&reg);
SCHERMPTR=(int  *far)( (reg.h.al == 7) ? 0XB0000000L : 0XB8000000L);
}

void veeg(int topy,int topx,int totl,int totb)       /* veeg scherm schoon */
{
   int y, x;
   for(y=topy; y<topy+totl; y++)
      for(x=topx; x<topx+totb; x++)
		 *(SCHERMPTR + y*80 + x) = SPACE | 0x0700;
}

void lveeg(int topy,int topx,int totl,int totb,char kar,unsigned kleur)
{
/*   int y, x;
   unsigned k1 = 0x0000 +kleur;
   unsigned k2 = 0x0100;
   for(y=topy; y<topy+totl; y++)
	{
	  k1+=0x0100;
	  kleur = k1 + k2;
	  for(x=topx; x<topx+totb; x++)
	   {
	   kleur += k2;
		  if (((kleur& 0x8000)-0x8000)==0)  kleur = 0x0000;
 		 *(SCHERMPTR + y*80 + x) = kar | kleur;
	   }
	 }
*/
   int y, x;
   for(y=topy; y<topy+totl; y++)
	  for(x=topx; x<topx+totb; x++)
		 *(SCHERMPTR + y*80 + x) = kar | kleur;

}


/**************** PRINTER TEST   EJN 040388   ********************
Dit programma test of de printer op printen staat en blijft dit
testen totdat negen pogingen zijn ondernomen
*/
int prntest(void)
{
int i,j,n,count;

count=0;
while(count<9)
 {
  count++;
  n= biosprint(2,0,0);
  if( n == 0x90) break;
  nosound();
  sound(9000);
  veeg(0,0,25,80);
  if (count>3)
     {
       printf("\n**********************************\n"
	      "*       It does not work        *\n"
	      "*        CALL FOR HELP          *\n"
	      "*********************************\n");
	  nosound();
     }
  printf("\n\n\n\nERROR %x ",n);
  if ((n & 0x01) ==0x01)
	     puts("\n         Printer Device time out error");
  if ((n & 0x08) ==0x08)
	     puts("\n         Printer I/O error");
  if ((n & 0x10) == 0x10)
	     puts("\n         Printer not ONLINE");
  if ((n & 0x20) == 0x20)
	     puts("\n         Printer Out of paper");
  if ((n & 0x40) == 0x40)
	     puts("\n         Printer is OFF");
  if ((n & 0x80) == 0x80)
	     puts("\n         Printer NOT BUSY");
  puts("Press a key after solving the error");
  while(bioskey(1)==0);
  i=getch();
  nosound();
  if(i==27) return 0;
  }
  return 1;
 }

/************  remove kleiner dan spatie ***************/
char *remove_lt_space(char *inputline)
{
int n;
char nop[1024];
strcpy(nop,strrev(inputline));
for(n=strlen(nop);n>=0;n--)	{ if(nop[n]<=' ') nop[n]=0; else break;}
strcpy(inputline,strrev(nop));
for(n=strlen(inputline);n>=0;n--)
	 { if(inputline[n] <= ' ') inputline[n]=0; else break;}
return(inputline);
}

double getd(FILE *fp)
{
 double a;
 char *b;
 int i,j;
  b=(char *) &a;
  for (i=0;i<sizeof(double);++i)
   {
    if((j = getc(fp)) == EOF) return(-1.0);
    b[i]= j & 0xFF;
   }
return(a);
}



/******************** TEST OF PRINTER AAN OF UIT ************************/
void prnonoff(void)
{
 if(biosprint(2,0,0)  != 0x90)
 {
  sound(2200);
  delay(13);
  nosound();
  sound(200);
  delay(300);
  nosound();
  closegraph();
  exit(-1);
 }
/* Verlaat het programma als de printer uitstaat*/
 }

/*************************  INITIALIZE *****************************/

void Initialize(void)
{
}

/************************ malloc data ************************/

void mallocdata(void)
 {
   int n;


   /* struct vak */
   wie = (struct vak **)calloc((MAX_ROW) , sizeof(struct vak *) );
   for (n=0;n < MAX_ROW+1;n++)
   {
    wie[n] = (struct vak *) calloc(1,sizeof(struct vak));
     if (wie[n]==0)
	   {
	    printf("%u coreleft\n\n",coreleft());
	    puts("TOO LESS MEMORY\n");
	    exit(-1);
	   }
   }
}
/***************** DEALLOCEER DATA *************************************/
void freemallocdata(void)
{
  int n;
  for (n=MAX_ROW; n >= 0;n--)	free(wie[n]);     free(wie);
}
/*************************READ PRT FILE *******************************/
void readprn(char *filein)
{
   int n,fout,row,ndag;
   char  inputline[1024];
   long count;
   char *token,nop[80],nopp[25];
   char getal[8];
   float bars;
   int nieuwjaar=0;

   cputs("Wil je alle afgeschreven dagen bij iedereen wissen?\r\n");
   cputs("De resterende vrije dagen blijven dan wel staan,\r\n");
   cputs("alleen de afzondelijke afgeschreven dagen worden gewist.\r\n");
   cputs("Doe dit alleen als je een nieuwe backup disk hebt genomen.\r\n");
   cputs("Plak de oude disk af zodat er niet meer op geschreven kan worden\r\n");
   cputs("en stop een nieuwe, geformateerde flop in de a: drive\r\n");
   cputs("\r\n\nWil je nog steeds alle afgeschreven dagen bij iedereen wissen?\r\n");
   cputs("(j/n)");
   n=getch();
   if(n=='j' || n=='J')
     {
      cputs("\r\n\nZEKER WETEN ?  (j/n)");
      n=getch();
      if(n=='j' || n=='J') nieuwjaar=TRUE;
     }

   printf("\n\nInlezen %s ",filein);

   if ((fpin=fopen(filein,"r")) == NULL)
	{
	   printf("cannot open input-file %s\n",filein);
	   exit(1);
	}

  swrite(30,10,"���������������������Ŀ",0x1700);
  swrite(30,11,"�                     �",0x1700);
  swrite(30,12,"�����������������������",0x1700);
  swrite(30,13,"0%        50%      100%",0x2700);
  strcpy(nopp,"                     ");
   count=0;
   row=0;
   bars=(float)( filelength(fileno(fpin)) ) / 21;

   while(TRUE)
	{
	  if(fgets(inputline,1024,fpin)==NULL)    break;
	  count+=strlen(inputline)+2;
	  strnset(nopp,176,(int)((float)count/bars));
	  swrite(31,11,nopp,BARCOLOR);
/*	  strcpy(nop,"  ");
	  strcat(nop,inputline);
*/	  strcpy(inputline,remove_lt_space(inputline));

	  fout=FALSE;
	  if(strlen(inputline)<3)  fout=TRUE;
	  if(inputline[0]==';')    fout=TRUE;
	  if(row>=MAX_ROW-3) {lost=TRUE; fout=TRUE;}
	  if(!fout)
	  {

	  strcpy(nop,strtok(inputline,","));
	  nop[MAX_LEN_NAAM-1]=0;
	  strcpy(wie[row]->naam,nop);

	  strcpy(nop,strtok(NULL,","));
	  nop[MAX_LEN_VNAAM-1]=0;
	  strcpy(wie[row]->vnaam,nop);

	  strcpy(nop,strtok(NULL,","));
	  nop[MAX_LEN_ADRES-1]=0;
	  strcpy(wie[row]->adres,nop);

	  strcpy(nop,strtok(NULL,","));
	  nop[MAX_LEN_PLAATS-1]=0;
	  strcpy(wie[row]->plaats,nop);

	  strcpy(nop,strtok(NULL,","));
	  nop[MAX_LEN_TELNR-1]=0;
	  strcpy(wie[row]->telnr,nop);

	  strcpy(nop,strtok(NULL,","));
	  wie[row]->afdnr=atol(nop);

	  strcpy(nop,strtok(NULL,","));
	  wie[row]->urenover=atoi(nop);

	  strcpy(nop,strtok(NULL,","));
	  wie[row]->deeltijd=atoi(nop);

	  strcpy(nop,strtok(NULL,","));
	  wie[row]->persnr=atol(nop);

	  strcpy(nop,strtok(NULL,","));
	  nop[MAX_LEN_DATUM-1]=0;
	  strcpy(wie[row]->gebdatum,nop);
	  ndag=0;

          if(!nieuwjaar){/* Entries niet meenemen*/

	  while(strcpy(nop,strtok(NULL,","))!=NULL)
	       {
	     if(nop[0]=='|') break;
		    wie[row]->dag[ndag].RV=nop[0];
	     strcpy(wie[row]->dag[ndag].datumvrij,strtok(NULL,","));
		    wie[row]->dag[ndag].datumvrij[MAX_LEN_DATUM-1]=0;
	     strcpy(wie[row]->dag[ndag].datumeindvrij,strtok(NULL,","));
		    wie[row]->dag[ndag].datumeindvrij[MAX_LEN_DATUM-1]=0;
	     strcpy(nop,strtok(NULL,","));
		    wie[row]->dag[ndag].urenopgenomen=atoi(nop);
	      if(++ndag > MAX_DAGEN-1) {corrupted=TRUE; break;}
	       }
                        }
	  row++;
	  if(row+2 > MAX_ROW) {lost=TRUE; break;}
	  }
	}
rows=row;
fclose(fpin);
}

/********************* edit fields ********************/

void edit_fields(void)
{
int persoon;
clrscr();
persoon=0;

while (persoon!=999)
{
persoon=kiesnaam("**AFSCHRIJVEN** Kies een naam door de eerste letter te drukken");
if(persoon != 999 ) display_persoon(persoon); 
}
window(1,1,80,25);

}


/********************* kies naam **************************/
int kiesnaam(char *text)
{
   char nop[80];
   int m,n,y,leave;
   char ch;			/* te printen char */
   int begin = 0;               /* 1e file uit blok van 25 dat geprint word */
   int keuze = 0;		/* nummer gekozen file */
   int num = 0;                 /* aantal files */
   int oke;                     /* 0 = geen keuze ESC 1 = keuze RETURN */
   int toets;			/* toetsaanslag via getch() */
   int pos = 0;			/* positie binnen filenaam */
   int veld;			/* nummer van filenaam */
   int xx =0;                   /* row waar geprint moet worden */
   int yy = 0;                  /* colom waar geprint moet worden */
   int keus=0;
   int keer=0;
   char volnaam[82];
   struct date d;

  window(1,1,80,25);
  clrscr();
  gotoxy(1,1);
  textcolor(YELLOW);
  highvideo();
  cprintf("%s",text);
  normvideo();
   for(n=0;n<MAX_ROW;n++)
      {
      if(wie[n]->naam[0]==0 && wie[n]->vnaam[0]==0) break;
      num++;
      }
   while (1)
    {
    oke=0;
    m=begin+24;
    if(m>num) m=num;
    for(veld = begin; veld < begin+24; veld++)
     {
      yy = 2 + (veld - begin);
      xx = 1;
      if(veld < num)
       {
       sprintf(volnaam," %-30s %-10s  %4d uur %3d dagen  ",wie[veld]->naam,wie[veld]->vnaam,wie[veld]->urenover,wie[veld]->urenover/8);
       for(pos = 0; pos < strlen(volnaam); pos++, xx++)
	{
	  ch = (volnaam[pos]);
	  if (veld == keuze) *(SCHERMPTR + yy * 80 + xx) = ch | CHINV;
	  else               *(SCHERMPTR + yy * 80 + xx) = ch | CHNOR;
	 }
	}
	 else
	   for(pos = 0; pos < 80; pos++, xx++)
			     *(SCHERMPTR + yy * 80 + xx) = SPACE | CHNOR;

     }
    if(oke > 0)
      {
	veeg(0,0,25,80);
	if(oke==1) return(999);
	 else	   return(keuze);
      }
    toets = getch();
    if(toets == SPECIAL_KEY)
     {
      toets = getch();
      switch (toets)
	{
           case PgUp:    keuze -=20;      break;
           case PgDn:    keuze +=20;      break;
	   case UP:      keuze -= 1;      break;
	   case LEFT:  --keuze;           break;
	   case DOWN:    keuze += 1;      break;
	   case RIGHT: ++keuze;           break;
	   case HOME:    keuze = 0;       break;
	   case ENDT:    keuze = num - 1; break;
	}
      if(keuze < 0)          keuze = num - 1;
      if(keuze > num - 1)    keuze = 0;
      if(keuze>20)           begin = keuze - 20;
      else                   begin = 0;
     }
     else
      {
       ch = toets;
       keus=keuze;
       leave=0;
       keer=-1;
       while(keer<2 && ch>31)
	 {
	   keer++;
	   if(keer==1) { keus=-1;}
	     for(y=keus+1; y<num; y++)
	      {
	       if(strnicmp(&wie[y]->naam[0],&ch,1) == 0)
		  {
		    keuze = y;  oke = 0; leave=1;  keer=2;
		    if(keuze < 20)  begin = 0;
		    else  begin = keuze - 20;
		  }
	       if(leave) break;
	       }
	  }

    if(ch == RETURN)  { oke = 2; return(keuze); }
    if(ch == ESC) { keuze=-1;   oke = 1; return(999); }
    if(ch == '@') {
    if(!prntest()) return(999);
    getdate(&d);
    fprintf(printer,"Printdatum : %d-%d-%d\n",d.da_day,d.da_mon,d.da_year);
    for(veld=0;veld<num;veld++)
       fprintf(printer," %-30s %-10s  %4d uur %3d dagen  \n",wie[veld]->naam,wie[veld]->vnaam,wie[veld]->urenover,wie[veld]->urenover/8);
       fprintf(printer,"\f");
       fflush(printer);
     keuze=-1;   oke = 1; return(999); }
   }
  }
}
/****************** save data ***************************/
int save_data(void)
{
   FILE *stream;
   int n,i;
   long count;
   float bars;
   char nopp[30];
   int persoon,ndag;

   clrscr();

   strcpy(fileout,filename);
   strcat(fileout,".VAK");
   if ((stream = fopen(fileout, "wb")) == NULL) /* open file TEST.$$$ */
   {
      fprintf(stderr, "Cannot open output file.\n");
      getch();
      return 0;
   }
  printf("\n\nSchrijven %s ",fileout);
  swrite(30,10,"���������������������Ŀ",0x1700);
  swrite(30,11,"�                     �",0x1700);
  swrite(30,12,"�����������������������",0x1700);
  swrite(30,13,"0%        50%      100%",0x2000);
  strcpy(nopp,"                     ");

rows=0;
  for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->vnaam[0]==0) break;

  count=0;
  bars=(float)( rows*sizeof(struct vak )) / 21;

 fwrite(&rows, sizeof(int), 1, stream); /* write struct vak to file */

  for(n=0;n<rows;n++)
    {
    wie[n]->check=CHECKCODE;
    fwrite(wie[n], sizeof(struct vak), 1, stream); /* write struct vak to file */
    count+=sizeof(struct vak);
    strnset(nopp,176,(int)((float)count/bars));
    swrite(31,11,nopp,BARCOLOR);
    }
   
  if(fclose(stream))        /* close file */
    {clrscr();
     puts("Er is iets mis met saven gegaan, Disk full??");
     puts("Doe je computer uit en copieer het backup bestand");
     getch();
     getch();
     getch();
     getch();
    }

   strcpy(fileout,filename);
   strcat(fileout,".PRV");

     if ((stream = fopen(fileout, "w")) == NULL)
       {
	 fprintf(stderr, "Cannot open output file %s.\n",fileout);
	 getch();
	 return 0;
	}


rows=0;
  for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->vnaam[0]==0) break;

      for(n=0;n<rows;n++)
	 {
	  fprintf(stream,"%s,%s,%s,%s,%s,%ld,%d,%d,%ld,%s",
	     wie[n]->naam,
	     wie[n]->vnaam,
	     wie[n]->adres,
	     wie[n]->plaats,
	     wie[n]->telnr,
	     wie[n]->afdnr,
	     wie[n]->urenover,
	     wie[n]->deeltijd,
	     wie[n]->persnr,
	     wie[n]->gebdatum
	   );
	     ndag=0;
	 while(wie[n]->dag[ndag].RV!=0)
	  {
	   fprintf(stream,",%c,%s,%s,%d",
	     wie[n]->dag[ndag].RV,
	     wie[n]->dag[ndag].datumvrij,
	     wie[n]->dag[ndag].datumeindvrij,
	     wie[n]->dag[ndag].urenopgenomen
	   );
	   ndag++;
	  }
	   fprintf(stream,",|\n");
	  }
  if(fclose(stream))        /* close file */
    {clrscr();
     puts("Er is iets mis met saven gegaan, Disk full??");
     puts("Doe je computer uit en copieer het backup bestand");
     getch();
     getch();
     getch();
     getch();
    }
   return 1;
}

/*****************   load_data(void)*****************/
int load_data(void)
{
   FILE *stream;
   int n;
   long count;
   float bars;
   char nopp[30];

   clrscr();

   if ((stream = fopen(fileload, "rb"))
       == NULL)
   {
      fprintf(stderr,
	      "Cannot open input file.\n");
      getch();
      return 0;
   }
   printf("\n\nInlezen %s ",fileload);
  swrite(30,10,"���������������������Ŀ",0x1700);
  swrite(30,11,"�                     �",0x1700);
  swrite(30,12,"�����������������������",0x1700);
  swrite(30,13,"0%        50%      100%",0x2400);
  strcpy(nopp,"                     ");

  count=0;
  bars=(float)( filelength(fileno(stream)) ) / 21;

 fread(&rows, sizeof(int), 1, stream); /* read aantal entries */

  for(n=0;n<rows;n++)
    {
     if(n>MAX_ROW-3) {lost=TRUE; break;}
     fread(wie[n], sizeof(struct vak), 1, stream); /* read struct vak to file */
     count+=sizeof(struct vak);
     if(wie[n]->check != CHECKCODE)
       {
	 cputs("\r\nEr klopt iets niet met deze file\r\n");
	 cputs("Lees de backup file in\r\n");
	 getch();
	 return(0);
       }
     strnset(nopp,176,(int)((float)count/bars));
     swrite(31,11,nopp,BARCOLOR);
    }
  fclose(stream);
  return 1;
}
/********************* display en edit persoon *****************/
int display_persoon(int pers)
{
int i,j,m,n;
char text[80];
char Text[2][10];
char cc;

while(TRUE)
{

prnt_pers_id(pers);

window(1,7,80,21);
n=0;
while(wie[pers]->dag[n++].RV!=0)
if(n>=MAX_DAGEN-2)
  delete_entry(pers,0);

textbackground(LIGHTGRAY);
textcolor(BLACK);
clrscr();
n=0;
gotoxy(1,1);
textcolor(RED);
cputs(" Entry        1e dag       Laatste dag     RVS   uren  dagen opgenomen\r\n");

window(1,8,80,21);
textbackground(LIGHTGRAY);
textcolor(BLACK);
clrscr();
gotoxy(1,1);
while(wie[pers]->dag[n].RV!=0)
  {
  if(n) puts("\r");
if(wie[pers]->dag[n].RV=='R')
  cprintf(" %3d          %-6s          %-6s       %c     %3d      %4.1f",++n,wie[pers]->dag[n].datumvrij,wie[pers]->dag[n].datumeindvrij,wie[pers]->dag[n].RV,wie[pers]->dag[n].urenopgenomen,(float)wie[pers]->dag[n].urenopgenomen/8);
else if(wie[pers]->dag[n].RV=='V')
  cprintf(" %3d          %-6s          %-6s        %c    %3d      %4.1f",++n,wie[pers]->dag[n].datumvrij,wie[pers]->dag[n].datumeindvrij,wie[pers]->dag[n].RV,wie[pers]->dag[n].urenopgenomen,(float)wie[pers]->dag[n].urenopgenomen/8);
else
  cprintf(" %3d          %-6s          %-6s         %c   %3d      %4.1f",++n,wie[pers]->dag[n].datumvrij,wie[pers]->dag[n].datumeindvrij,wie[pers]->dag[n].RV,wie[pers]->dag[n].urenopgenomen,(float)wie[pers]->dag[n].urenopgenomen/8);
  }
textbackground(BLACK);
textcolor(WHITE);
window(1,22,80,25);
clrscr();

normvideo();
gotoxy(1,1);
while(bioskey(1))
	 getch();
cputs("    @, R, V of S : .               Voer @ in om entry te wissen");
gotoxy(20,1);
cc=getche();
if(cc=='@'){  delete_entry(pers,999); continue; }
if(cc<64) { window(1,1,80,25); clrscr(); return 1;}
if(cc>96) cc-=32;

while (TRUE)
{
 gotoxy(1,2);
 cputs(" Eerste dag vrij : ddmmyy          Voer spatie in om te stoppen");
 gotoxy(20,2);
 gets(text);
 if(text[0]==32)  return 0;
 if(strlen(text)!=6) {sound(200); delay(100); nosound(); continue;}
 text[MAX_LEN_DATUM-1]=0;
 if(! strlen(text))  {sound(600); delay(100); nosound(); continue;}
 strcpy(Text[0],text);
 break;
}

while (TRUE)
{
 gotoxy(1,3);
 cputs("Laatste dag vrij : ddmmyy       ");
 gotoxy(20,3);
 gets(text);
 if(text[0]==32)  return 0;
 if(strlen(text)!=6) {sound(200); delay(100); nosound(); continue;}
 text[MAX_LEN_DATUM-1]=0;
 if(! strlen(text))  {sound(600); delay(100); nosound(); continue;}
 strcpy(Text[1],text);
 break;
}


while (TRUE)
{
 gotoxy(1,4);
 cputs(" Dagen opgenomen : ....     Als uren dan U???, waarin ??? aantal uren");
 gotoxy(20,4);
 gets(text);
 text[6]=0;
 if(text[0]==32) return 0;
 if(! strlen(text)) continue;
 break;
}

wie[pers]->dag[n].RV=cc;
strcpy(wie[pers]->dag[n].datumvrij,Text[0]);
strcpy(wie[pers]->dag[n].datumeindvrij,Text[1]);
if(text[0]=='u' || text[0]=='U')
     {text[0]='0';
      wie[pers]->dag[n].urenopgenomen=atoi(text);
     }
else wie[pers]->dag[n].urenopgenomen=atoi(text)*8;

wie[pers]->urenover-=wie[pers]->dag[n].urenopgenomen;

wie[pers]->dag[n+1].RV=0;
wie[pers]->dag[n+1].urenopgenomen=0;

}
}


/******************** persoon_editen ***********************/
int    persoon_editen(void)
{
char text[90];
int persoon,pers;

clrscr();
persoon=0;
  for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->vnaam[0]==0) break;
 

persoon=kiesnaam("** EDIT **      Druk escape om toe te voegen");


if(persoon==999)
 pers=rows;
  else pers=persoon;
  if(rows>=MAX_ROW-3) {lost=TRUE; return 0;}

prnt_pers_id(pers);
gotoxy(5,10);
cputs("Voer een SPATIE in een veld in om invoeren te verlaten");
while(TRUE)
{
 window(1,12,80,25);
 clrscr();
 gotoxy(1,1);
 cputs("  Voornaam :");
 gotoxy(1,2);       
 cputs("      Naam :");
 gotoxy(1,3);
 cputs("     Adres :");
 gotoxy(1,4);
 cputs("Woonplaats :");
 gotoxy(1,5);
 cputs("     Telnr :");
 gotoxy(1,6);
 cputs("Persoonsnr :");
 gotoxy(1,7);
 cputs("      Uren :");
 gotoxy(1,8);
 cputs("Deeltijd % :");
 gotoxy(1,9);
 cputs(" Geb datum :");
 gotoxy(1,10);
 cputs("   Afd. nr :");
  

 gotoxy(1,1);
 cputs("  Voornaam : .........         Type in: @, om persoon te wissen");
 gotoxy(14,1);
 gets(text);
 text[MAX_LEN_VNAAM-1]=0;
 if(text[0]==32) return 0;
 if(strcmp(text,"@")==0) { wissen(pers); return 0; }
 if(strlen(text))
   strcpy(wie[pers]->vnaam,text);
 if(wie[pers]->vnaam[0]==0) strcpy(wie[pers]->vnaam,"?"); 

 
 gotoxy(1,2);
 cputs("      Naam : .......................................");
 gotoxy(14,2);
 gets(text);
 if(text[0]==32) return 0;
 text[MAX_LEN_NAAM-1]=0;
 if(strlen(text))
   strcpy(wie[pers]->naam,text);
 if(wie[pers]->naam[0]==0) strcpy(wie[pers]->naam,"?"); 
 
 gotoxy(1,3);
 cputs("     Adres : ............................................................");
 gotoxy(14,3);
 gets(text);
 if(text[0]==32) return 0;
 text[MAX_LEN_ADRES-1]=0;
 if(strlen(text))
   strcpy(wie[pers]->adres,text);
 if(wie[pers]->adres[0]==0) strcpy(wie[pers]->adres,"?"); 

 gotoxy(1,4);
 cputs("Woonplaats : ...............................");
 gotoxy(14,4);
 gets(text);
 if(text[0]==32) return 0;
 text[MAX_LEN_PLAATS-1]=0;
 if(strlen(text))
   strcpy(wie[pers]->plaats,text);
 if(wie[pers]->plaats[0]==0) strcpy(wie[pers]->plaats,"?"); 

 gotoxy(1,5);
 cputs("     Telnr : .............");
 gotoxy(14,5);
 gets(text);
 if(text[0]==32) return 0;
 text[MAX_LEN_TELNR-1]=0;
 if(strlen(text))
    strcpy(wie[pers]->telnr,text);
 if(wie[pers]->telnr[0]==0) strcpy(wie[pers]->telnr,"?"); 

 gotoxy(1,6);
 cputs("Persoonsnr : .....");
 gotoxy(14,6);
 gets(text);
 if(text[0]==32) return 0;
 if(strlen(text))
  wie[pers]->persnr=atol(text);

if(stricmp(password,"eddie")==0)
 {
 gotoxy(1,7);
 cputs("      Uren : ....");
 gotoxy(14,7);
 gets(text);
 if(text[0]==32) return 0;
 if(strlen(text))
   wie[pers]->urenover=atoi(text);
 } 
 else {
 gotoxy(1,7);
 cputs("      Uren : xxxx");
      }
 gotoxy(1,8);
 cputs("Deeltijd % : ...   ");
 gotoxy(14,8);
 gets(text);
 if(text[0]==32) return 0;
 if(strlen(text))
	 wie[pers]->deeltijd=atoi(text);
 if(wie[pers]->deeltijd==0)  wie[pers]->deeltijd=100;

 while(TRUE)
 {
 gotoxy(1,9);
 cputs(" Geb datum : ddmmyy     ");
 gotoxy(14,9);
 gets(text);
 if(text[0]==32) return 0;
 if(strlen(text)!=6) {sound(200); delay(100); nosound(); continue;}
 if(strlen(text))
  strncpy(wie[pers]->gebdatum,text,MAX_LEN_DATUM-1);
 if(wie[pers]->gebdatum[0]==0) strcpy(wie[pers]->gebdatum,"?"); 
 break;
 }

 gotoxy(1,10);
 cputs("   Afd. nr : ......");
 gotoxy(14,10);
 gets(text);
 if(text[0]==32) return 0;
 if(strlen(text))
   wie[pers]->afdnr=atol(text);
 
 prnt_pers_id(pers);

 gotoxy(5,12);
 cputs(" OK? Return = OK ");
 if(getch()==13) break;

}
 gotoxy(5,15);
 cputs("Ben aan het sorteren");
 for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->vnaam[0]==0) break;

if(rows>2) csort(rows);
window(1,1,80,25);
clrscr();
return 0;
 }


/************* print persoons personalia ********************/
void prnt_pers_id(int pers)
{
window(1,1,80,25);
clrscr();
highvideo();
textcolor(GREEN);
gotoxy(1,1);
cprintf("      Naam : %s %s",wie[pers]->vnaam,wie[pers]->naam);
gotoxy(1,2);
cprintf("     Adres : %-60s",wie[pers]->adres);
gotoxy(1,3);
cprintf("Woonplaats : %-30s",wie[pers]->plaats);
gotoxy(1,4);
cprintf("     Telnr : %-13s",wie[pers]->telnr);
gotoxy(25,4);
cprintf("     Afdnr : %-d",wie[pers]->afdnr);
gotoxy(1,5);
cprintf("    Persnr : %-5d",wie[pers]->persnr);
gotoxy(25,5);
cprintf("Geb. datum : %-s",wie[pers]->gebdatum);
gotoxy(50,5);
cprintf("  Deeltijd : %d %",wie[pers]->deeltijd);
gotoxy(1,6);
cprintf(" Uren over : %-5d",wie[pers]->urenover);
gotoxy(25,6);
cprintf("Dagen over : %3.1f",(float)wie[pers]->urenover/8);
normvideo();

/*cputs("\r\n--------------------------------------------------------------------------------");*/
}

/**************  persoon wissen ******************************/
void wissen(int pers)
{
int n;
for (n=pers;n<MAX_ROW;n++)
	 memcpy(wie[n],wie[n+1],sizeof(struct vak));
}

/************** delete dag ************************/
void delete_entry(int pers,int dagnr)
{
 int n,entry,noofentries=0;
 char text[80];

 wie[pers]->dag[MAX_DAGEN-1].RV=0;

 if(dagnr==999)
   {
    gotoxy(1,3);
    cputs("Welke entry wissen : ..");
    gotoxy(22,3);
    gets(text);
    if(text[2]==0);
    if(strlen(text)==0) return;
    entry=atoi(text)-1;

    while(wie[pers]->dag[noofentries].RV!=0)
		  noofentries++;

    if(entry > noofentries) 
      { gotoxy(25,3);
	puts("Bestaat niet,  Druk een toets");
	   sound(50);
	   nosound();
	   sound(50);
	   delay(200);
	   nosound();
	getch();
	return;
       }
    wie[pers]->urenover+=wie[pers]->dag[entry].urenopgenomen;

    for (n=entry;n<MAX_DAGEN-2;n++)
	 memcpy(&wie[pers]->dag[n],&wie[pers]->dag[n+1],sizeof(struct fvak));
     
    gotoxy(1,4);
    highvideo();
    cputs("De afgeschreven uren van de gewiste dag zijn weer bij het totaal bijgeschreven");
    gotoxy(5,5);
    cputs("Druk een toets");
    normvideo();
    getch();
    return;
   }

for(n=dagnr;n<MAX_DAGEN-2;n++)
memcpy(&wie[pers]->dag[n],&wie[pers]->dag[n+1],sizeof(struct fvak));


}

/************************** OVERZICHT ************************/
void   overzicht(void)
{
int n;
int pers,persoon;
char text[80];
long afdeling;

if(!prntest()) return;

persoon=kiesnaam("**OVERZICHT**   Druk escape om selectie te maken @=Kort overzicht printen");
pers=persoon;

  for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->vnaam[0]==0) break;

if(persoon!=999)
 {
  prnt_pers_id(pers);
  gotoxy(5,15);
  cputs("Hier een overzicht van ?? RETURN=OK");
  if(getch()==13)
           {
           print_overzicht(persoon);
           return;
           }
 }
 clrscr();
 gotoxy(1,5);
 cputs("Geef afdelingscode of 0 voor overzicht van iedereen");
 gotoxy(1,7);
 cputs("Afdelingscode : ");
 gotoxy(17,7);
 afdeling=0;
 gets(text);
 if(strlen(text))
   afdeling=atol(text);
 else return;
 if(!prntest()) return;

 for(persoon=0;persoon<rows;persoon++)
    {
     gotoxy(2,2);
     highvideo();
     textcolor(GREEN);
     cprintf("      Naam : %s %s                        ",wie[persoon]->vnaam,wie[persoon]->naam);
     normvideo();
     if(afdeling>0 && wie[persoon]->afdnr!=afdeling) continue;
     gotoxy(10,10);
     cputs("Druk een toets om het printen te stoppen");
     cputs("\r\nGeduld, het kan even duren voor hij reageert");
     if(kbhit()){while(kbhit()) getch();  return;}
     print_overzicht(persoon);
    }
       
}

/******************* overzicht printen ***********************/
void print_overzicht(int pers)
{
int n;

struct date d;
getdate(&d);
fprintf(printer,"Printdatum : %d-%d-%d\n",d.da_day,d.da_mon,d.da_year);
fprintf(printer,"      Naam : %s %s\n",wie[pers]->vnaam,wie[pers]->naam);
fprintf(printer,"     Adres : %-60s\n",wie[pers]->adres);
fprintf(printer,"Woonplaats : %-30s\n",wie[pers]->plaats);
fprintf(printer,"     Telnr : %-13s\n",wie[pers]->telnr);
fprintf(printer,"     Afdnr : %-d\n",wie[pers]->afdnr);
fprintf(printer,"    Persnr : %-5d\n",wie[pers]->persnr);
fprintf(printer,"Geb. datum : %-s\n",wie[pers]->gebdatum);
fprintf(printer,"  Deeltijd : %d %\n",wie[pers]->deeltijd);
fprintf(printer," Uren over : %-5d\n",wie[pers]->urenover);
fprintf(printer,"Dagen over : %3.1f\n",(float)wie[pers]->urenover/8);
fprintf(printer,"----------------------------------------------------------------------\n");
fprintf(printer," Entry        1e dag       Laatste dag     RVS   uren  dagen opgenomen\r\n");

n=0;
while(wie[pers]->dag[n].RV!=0)
if(wie[pers]->dag[n].RV=='R')
  fprintf(printer," %3d          %-6s          %-6s       %c      %3d    %4.1f\n",++n,wie[pers]->dag[n].datumvrij,wie[pers]->dag[n].datumeindvrij,wie[pers]->dag[n].RV,wie[pers]->dag[n].urenopgenomen,(float)wie[pers]->dag[n].urenopgenomen/8);
else if(wie[pers]->dag[n].RV=='V')
  fprintf(printer," %3d          %-6s          %-6s        %c     %3d    %4.1f\n",++n,wie[pers]->dag[n].datumvrij,wie[pers]->dag[n].datumeindvrij,wie[pers]->dag[n].RV,wie[pers]->dag[n].urenopgenomen,(float)wie[pers]->dag[n].urenopgenomen/8);
else
  fprintf(printer," %3d          %-6s          %-6s         %c    %3d    %4.1f\n",++n,wie[pers]->dag[n].datumvrij,wie[pers]->dag[n].datumeindvrij,wie[pers]->dag[n].RV,wie[pers]->dag[n].urenopgenomen,(float)wie[pers]->dag[n].urenopgenomen/8);

fprintf(printer,"\f");
fflush(printer);
}


/************************** sorteren op naam ***********************/
void csort(int n)
{
   int l,j,ir,i,s;

   if(n>MAX_ROW-2) n=MAX_ROW;
   l=(n >> 1)+1;
   s=ir=n;
   for(i=n;i>=0;i--) memcpy(wie[i+1],wie[i],sizeof(struct vak ));
   for(;;)
      {
      if(l > 1)
	   memmove(wie[MAX_ROW-1],wie[--l],sizeof(struct vak));
      else {
	   memmove(wie[MAX_ROW-1],wie[ir],sizeof(struct vak));
	   memmove(wie[ir],wie[1],sizeof(struct vak));
	   if(--ir == 1)
	     {
	      memmove(wie[1],wie[MAX_ROW-1],sizeof(struct vak));
     for(i=0;i<=n+1;i++) memcpy(wie[i],wie[i+1],sizeof(struct vak));
	      return;
	     }
	   }
      i=l;
      j=(l << 1) ;
      while(j <= ir ) 
	{
	 if(j < ir && (strcmp(wie[j]->naam,wie[j+1]->naam)) < 0) ++j;
	 if((strcmp(wie[MAX_ROW-1]->naam,wie[j]->naam)) < 0) 
	 {
	 memmove(wie[i],wie[j],sizeof(struct vak));
	 j += (i=j);
	 }
	 else j=ir+1;
	}
      memmove(wie[i],wie[MAX_ROW-1],sizeof(struct vak));
s=s;
     }
}

void   maandoverzicht()
{

 struct date d;
 long secs_now;
 long secs_start;
 int m,n;
 long nop;
 char cnop[20];
 int persoon,pers;
 int maand,jaar;
 char dag1[34];
 char dag2[34];
 char dagt[68];
 char dags[68];
 char dag01[68];
 char dag02[68];
 char *str_now;
 char s[90],t[20];
 char uur[5],min[5],sec[5];
 int sda,sma,syr,eda,ema,eyr;
 char *wday[] = {"Z", "M", "D", "W", "D","V", "Z", "?"};
 char *wmaand[] = {"?","Januari  ", "Februari ", "Maart    ", "April    ", "Mei      ","Juni     ",
    "Juli     ", "Augustus  ","September  ","Oktober  ","November  ","December  ","Januari  "};
 struct tm time_check;
 int year, month, day;

 char mnd[27];
 mnd[1] =31;
 mnd[2] =28;
 mnd[3] =31;
 mnd[4] =30;
 mnd[5] =31;
 mnd[6] =30;
 mnd[7] =31;
 mnd[8] =31;
 mnd[9] =30;
 mnd[10]=31;
 mnd[11]=30;
 mnd[12]=31;
 mnd[13]=31;
 mnd[14]=28;
 mnd[15]=31;
 mnd[16]=30;
 mnd[17]=31;
 mnd[18]=30;
 mnd[19]=31;
 mnd[20]=31;
 mnd[21]=30;
 mnd[22]=31;
 mnd[23]=30;
 mnd[24]=31;
 mnd[25]=31;
 time(&secs_now);
 str_now=ctime(&secs_now);
 str_now[24]='\0';
 strcpy(dag1,"          1 1 1 1 1 2 2 2 2 2 3\0");
 strcpy(dag1,"         |---10---||---20---|33\0");
 strcpy(dag2,"1234567890123456789012345678901\0");
 clrscr();

 getdate(&d);
 maand=d.da_mon;
 jaar =d.da_year;
 n=1;

 while(n!=0)
 {
 if( (jaar/4)*4==jaar)       mnd[2] =29;  else mnd[2] =28;
 if( ((jaar+1)/4)*4==jaar+1) mnd[14]=29;  else mnd[14]=28;
 m=0;
   time_check.tm_year = jaar-1900;
   time_check.tm_mon  = maand-1;
   time_check.tm_hour = 0;
   time_check.tm_min  = 0;
   time_check.tm_sec  = 1;
   time_check.tm_isdst = -1;
  for(n=1;n<=mnd[maand];n++)
  {
/*  load the time_check structure with the data */
   time_check.tm_mday = n;

/*  call mktime to fill in the weekday field of the structure */
   if (mktime(&time_check) == -1)
      time_check.tm_wday = 7;
   dagt[m++]=wday[time_check.tm_wday][0];
}

 if(maand==12) { year=jaar+1; month=0;} else { year=jaar;month=maand;}
   time_check.tm_year = year-1900;
   time_check.tm_mon  = month;
 for(n=1;n<=mnd[maand+1];n++)
  {
/*  load the time_check structure with the data */
   time_check.tm_mday = n;

/*  call mktime to fill in the weekday field of the structure */
   if (mktime(&time_check) == -1)
      time_check.tm_wday = 7;
   dagt[m++]=wday[time_check.tm_wday][0];
}
 dagt[m++]=32;
 dagt[m++]=32;
 dagt[m++]=32;
 dagt[m]=0;
 gotoxy(70,3);
 cputs("         ");

 textcolor(LIGHTGREEN);
 gotoxy(15,3);
 cputs(dagt);  /* print de dag letters */
 textcolor(LIGHTRED);
 for(n=0;n<62;n++)
 {
  if(dagt[n]=='Z') {gotoxy(15+n,3); putch('Z'); }
 }
  strcpy(dags,dagt);
 textcolor(WHITE);

 strcpy(dag01,dag1);
 dag01[mnd[maand]]=0;
 strcpy(dagt,dag1);
 dagt[mnd[maand+1]]=0;
 strcat(dag01,dagt);
 strcat(dag01,"  ");
 gotoxy(70,1);
 cputs("         ");
 gotoxy(70,2);
 cputs("         ");

 strcpy(dag02,dag2);
 dag02[mnd[maand]]=0;
 strcpy(dagt, dag2 );
 dagt[mnd[maand+1]]=0;
 strcat(dag02,dagt);

 gotoxy(15,1);
 cputs(dag01);
 gotoxy(15,2);
 cputs(dag02);
 gotoxy(1,1);
 cprintf("%s %d",wmaand[maand],jaar);

 for(rows=0;rows<MAX_ROW;rows++)
      if(wie[rows]->naam[0]==0 && wie[rows]->vnaam[0]==0) break;
 
 for(pers=0;pers<rows;pers++)
  {
   gotoxy(1,pers+4);
    textcolor(YELLOW);
    cputs(wie[pers]->vnaam);
    textcolor(LIGHTGRAY);
    gotoxy(70,pers+4);
    cputs("         ");
    strset(dag02,'|');
    gotoxy(14,pers+4);
    putch(' ');
    gotoxy(15,pers+4);
    cputs(dag02);
 for(n=0;n<62;n++)
 {
  if(dags[n]=='Z') {gotoxy(15+n,pers+4); putch(' '); }
 }

    n=-1;
    while(wie[pers]->dag[++n].RV!=0)
    {
     nop=atol(wie[pers]->dag[n].datumvrij);
     sda=(int)(nop/10000L);
     nop-=(long)sda*10000L;
     sma=(int)(nop/100L);
     nop-=(long)sma*100L;
     syr=nop;

     nop=atol(wie[pers]->dag[n].datumeindvrij);
     eda=(int)(nop/10000L);
     nop-=(long)eda*10000L;
     ema=(int)(nop/100L);
     nop-=(long)ema*100L;
     eyr=nop;

     if ( (1900+syr<=jaar && 1900+eyr>=jaar)&&(sma<=maand+1 && ema>= maand ) )
      {
       if(eyr>syr) maand+=12;

            if(ema>maand+1)  nop=mnd[maand]+mnd[maand+1];
       else if(ema==maand+1) nop=mnd[maand]+eda;
       else                  nop=eda;

       if(sma<maand )       sda=1;
       if(sma==maand+1 )    sda=sda+mnd[maand];

/*       if(sma==maand && ema>sma ) nop=mnd[maand+1]+eda;
       if(sma==maand && eyr>syr ) nop=mnd[mmand+1]+eda;
*/
        for(m=sda;m<=nop;m++)
         {
          gotoxy(15+m-1,pers+4);
          textcolor(LIGHTGRAY);
          if(wie[pers]->dag[n].RV=='R') textcolor(GREEN);
          if(wie[pers]->dag[n].RV=='S') textcolor(BROWN);
          if(wie[pers]->dag[n].RV=='V') textcolor(LIGHTBLUE);
          if(wie[pers]->dag[n].RV=='Z') textcolor(LIGHTRED);
          putch(wie[pers]->dag[n].RV);
         }

      }
     }
   textcolor(CYAN);
   gotoxy(77,pers+4);
   itoa(wie[pers]->urenover/8,cnop,10);
   cputs(cnop);
   textcolor(WHITE);
   }

 n=getch();
 if(n==0) n=getch();
      if(n==TAB) maand++;
 else if(n==15)  maand--;
 else break;
 if(maand==13) { maand=1;  jaar+=1;}
 if(maand==0)  { maand=12; jaar-=1;}

 }
}

